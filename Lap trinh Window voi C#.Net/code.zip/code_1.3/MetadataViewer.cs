namespace MetadataViewer
{
    using System;
	using System.Reflection;

    

	//Create a sample class to list the methods of
	public class SimpleClass 
	{
		public void Hello( ) 
		{
			Console.WriteLine("Inside SimpleClass.Hello method");
		}

		public void Goodbye( ) 
		{
			Console.WriteLine("Inside SimpleClass.Goodbye method");
		}

	}



	//Write some code to examine the SimpleClass
	public class ClassExplorer 
	{
		public static void Main( ) 
		{

			Type ObjectType = typeof( MetadataViewer.SimpleClass );

			//List the Instance Methods of SimpleClass
			MethodInfo[] methods = ObjectType.GetMethods( BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public );

			for( int i = 0; i <= methods.GetUpperBound(0); i++)
			{
			 Console.WriteLine("{0} : {1}", i, methods[i] );
			}
						
			Console.Write("Enter method number to invoke: ");
			int idx = int.FromString( Console.ReadLine( ) );
			Invoke( ObjectType, methods[idx] );
		}

		
		public static void Invoke( Type T, MethodInfo mi ) 
		{
					//Create an instance of the object
			Object o = System.Activator.CreateInstance( T );
			object[] parameters = null;
			mi.Invoke(o, parameters );
		}
	}




}