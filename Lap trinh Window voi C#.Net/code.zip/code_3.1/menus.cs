using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;

//This application shows off som of the menu features
//Lines below have been added but then commented out
//please feel free to remove the comment slashes to
//see the effect of the commands.
public class menuapp : System.Windows.Forms.Form
{

    Label label;

    void ShowInfo(Object Sender,EventArgs e)
    {
        MenuItem item=(MenuItem)Sender;
        switch(item.Text)
        {
            case "&Open":
                label.Text = "Open a file from disk";
            break;
            case "&Save":
                label.Text = "Save a file onto disk";
            break;
            case "E&xit":
                label.Text = "Exit MenuApp";
            break;
        }
    }

    public  menuapp()
    {
        this.Text = "MenuApp";
        this.MaximizeBox = true;
        this.FormBorderStyle = FormBorderStyle.Sizable;

        this.label = new Label();
        label.Location = new Point(8,100);
        label.Size = new Size(200,25);

        this.Controls.Add(label);

        MainMenu menu = new MainMenu();

        // menu.RightToLeft = RightToLeft.Yes;

        MenuItem filemenu = new MenuItem();
        filemenu.Text = "&File";
        menu.MenuItems.Add(filemenu);

            MenuItem open = new MenuItem();
            open.Text = "&Open";
            open.Select += new EventHandler(ShowInfo);
            filemenu.MenuItems.Add(open);

            MenuItem save= new MenuItem();
            save.Text = "&Save";
            save.Select += new EventHandler(ShowInfo);
            filemenu.MenuItems.Add(save);
            //save.BarBreak=true;

            MenuItem exit= new MenuItem();
            exit.Text = "E&xit";
            exit.Select += new EventHandler(ShowInfo);
            filemenu.MenuItems.Add(exit);
            //exit.BarBreak=true;
            //exit.Break=true;
    
        this.Menu = menu;

        ContextMenu cmenu = new ContextMenu();
        cmenu.MenuItems.Add(new MenuItem("&First"));
        cmenu.MenuItems.Add(new MenuItem("&Second"));
        cmenu.MenuItems.Add(new MenuItem("-"));
        cmenu.MenuItems.Add(new MenuItem("&Third"));


        this.ContextMenu=cmenu;


    }

    static void Main()
    {
        Application.Run(new menuapp());
    }

}