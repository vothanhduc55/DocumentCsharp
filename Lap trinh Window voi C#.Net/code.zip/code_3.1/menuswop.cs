using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;

namespace Sams {

class menuswop : System.Windows.Forms.Form
{
    MainMenu m_menu;
    MenuItem m_editmenu,m_menumenu,m_switchitem,m_showsecond,m_merge;
    MenuItem m_playmenu;

    bool m_bswop;
    bool m_bshowsecond;
    bool m_bmerge;

    // private helper function for the BuildMenu function.
    void addmenuitem(MenuItem menu, string s)
    {
        MenuItem temp=new MenuItem(s);
        temp.Enabled= false;
        menu.MenuItems.Add(temp);
    }

    // This builds a menu structure from copies
    // of the originals using CloneMenu.
    void BuildMenu()
    {
        m_menu=new MainMenu();
        m_menu.MenuItems.Add(m_menumenu.CloneMenu());
        
        if(m_bmerge) // when we merge...
        {
            MenuItem temp=new MenuItem();

            if(!m_bswop)
            {
                addmenuitem(temp,"Edit");
                temp.MergeMenu(m_editmenu.CloneMenu());
            }
            else
            {
                addmenuitem(temp,"Play");
                temp.MergeMenu(m_playmenu.CloneMenu());
            }

            temp.MenuItems.Add(new MenuItem("-"));

            if(m_bshowsecond)
            {
                if(!m_bswop)
                {
                    addmenuitem(temp,"Play");
                    temp.MergeMenu(m_playmenu.CloneMenu());
                }
                else
                {
                    addmenuitem(temp,"Edit");
                    temp.MergeMenu(m_editmenu.CloneMenu());
                }
            }

            temp.Text = "&Merged";
            m_menu.MenuItems.Add(temp);

        }
        else // when we dont merge...
        {
            if(!m_bswop)
            {
                if(m_bshowsecond)
                {
                    m_menu.MenuItems.Add(m_editmenu.CloneMenu());
                }
                m_menu.MenuItems.Add(m_playmenu.CloneMenu());
            }
            else
            {
                if(m_bshowsecond)
                {
                    m_menu.MenuItems.Add(m_playmenu.CloneMenu());
                }
                m_menu.MenuItems.Add(m_editmenu.CloneMenu());
            }
        }

        this.Menu = m_menu;
    }

    //This method sets or resets the checks on menu items
    //note how the MenuItem collection is accessible as an array.
    void PopupMenuMenu(Object sender, EventArgs e)
    {
        m_menu.MenuItems[0].MenuItems[0].Checked = m_bswop;
        m_menu.MenuItems[0].MenuItems[1].Checked = m_bshowsecond;
        m_menu.MenuItems[0].MenuItems[2].Checked = m_bmerge;
    }

    // The event handler for the switch menu entry
    void OnSwitchMenu(Object sender, EventArgs e)
    {
        m_bswop = !m_bswop;
        BuildMenu();
    }

    //The event handler for the show menu entry
    void Onshowsecond(Object sender, EventArgs e)
    {
        m_bshowsecond = !m_bshowsecond;
        BuildMenu();
    }

    //The event handler for the merge menu entry
    void OnMerge(Object sender, EventArgs e)
    {
        m_bmerge = !m_bmerge;
        BuildMenu();
    }

    public menuswop()
    {
        // setup a main menu
        m_menumenu = new MenuItem("&Menu");
        m_menumenu.Popup += new EventHandler(PopupMenuMenu);
        
        //Create the switch item.
        m_switchitem=new MenuItem("&Switch");
        m_switchitem.Click+=new EventHandler(OnSwitchMenu);
        m_menumenu.MenuItems.Add(m_switchitem);

        m_showsecond = new MenuItem("&Show");
        m_showsecond.Click+= new EventHandler(Onshowsecond);
        m_menumenu.MenuItems.Add(m_showsecond);

        m_merge = new MenuItem("&Merge");
        m_merge.Click += new EventHandler(OnMerge);
        m_menumenu.MenuItems.Add(m_merge);

        // create a second menu
        m_editmenu=new MenuItem("&Edit");
        m_editmenu.MenuItems.Add(new MenuItem("Cut"));
        m_editmenu.MenuItems.Add(new MenuItem("Copy"));
        m_editmenu.MenuItems.Add(new MenuItem("Paste"));

        // and an alternative.
        m_playmenu=new MenuItem("&Play");        
        m_playmenu.MenuItems.Add(new MenuItem("Normal"));
        m_playmenu.MenuItems.Add(new MenuItem("Fast Forward"));
        m_playmenu.MenuItems.Add(new MenuItem("Reverse"));

        m_bshowsecond=true;

        //Now build the menu from its parts..
        BuildMenu();
                
    }

    public static void Main()
    {
        Application.Run(new menuswop());
    }
}

}// end of Sams namespace