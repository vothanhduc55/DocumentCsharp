using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;


public class SizeApp : System.Windows.Forms.Form
{

/*    public void OnFileOpen(Object sender, EventArgs e)
    {
        MessageBox.Show("You selected File-Open!");
    }

    bool m_bPopupChecked;
 
    public void OnPopupFilemenu(Object Sender, EventArgs e)
    {    
        // this handler illustrates the popup event and the MenuItem UI properties.
        m_bPopupChecked = !m_bPopupChecked;
        MenuItem item = (MenuItem)Sender;
        item.MenuItems[0].Checked = m_bPopupChecked;
        item.MenuItems[1].Enabled = m_bPopupChecked;
        item.MenuItems[2].Visible = m_bPopupChecked;
    }
*/
    public     SizeApp()
    {
        this.Text = "SizeApp";
        this.MaximizeBox = true;
        this.FormBorderStyle = FormBorderStyle.Sizable;

/*        MainMenu menu = new MainMenu();
        menu.RightToLeft = RightToLeft.Yes;
        MenuItem filemenu = new MenuItem();
        filemenu.Text = "&File";
        menu.MenuItems.Add(filemenu);

            MenuItem open = new MenuItem();
            open.Text = "&Open";
        
            filemenu.MenuItems.Add(open);

                open.Shortcut = Shortcut.CtrlO;
                open.ShowShortcut = true;
                open.Click += new EventHandler(OnFileOpen);
    
                MenuItem save= new MenuItem();
                save.Text = "Save";
                filemenu.MenuItems.Add(save);
    
                MenuItem exit= new MenuItem();
                exit.Text = "Exit";
                filemenu.MenuItems.Add(exit);
    
            MenuItem editmenu = new MenuItem();        
            editmenu.Text = "Edit";
    
            menu.MenuItems.Add(editmenu);
    
                MenuItem cut= new MenuItem();
                cut.Text = "Cut";
                editmenu.MenuItems.Add(cut);
    
                MenuItem copy = new MenuItem();
                copy.Text = "Copy";
                editmenu.MenuItems.Add(copy);
    
                MenuItem paste = new MenuItem();
                paste.Text = "Paste";
                editmenu.MenuItems.Add(paste);

            MenuItem dummymenu = new MenuItem();
            dummymenu.Text = "Separator";
            menu.MenuItems.Add(dummymenu);

                dummymenu.MenuItems.Add(new MenuItem("Above"));
                dummymenu.MenuItems.Add(new MenuItem("-"));
                dummymenu.MenuItems.Add(new MenuItem("Below"));

        filemenu.Popup += new EventHandler(OnPopupFilemenu);

        this.Menu = menu;
*/
    }

    static void Main()
    {
        Application.Run(new SizeApp());
    }

}