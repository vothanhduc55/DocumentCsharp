using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;


public class SizeApp : System.Windows.Forms.Form
{

    public     SizeApp()
    {
        this.Text = "SizeApp";
        this.MaximizeBox = true;
        this.FormBorderStyle = FormBorderStyle.Sizable;
    }

    static void Main()
    {
        Application.Run(new SizeApp());
    }

}
