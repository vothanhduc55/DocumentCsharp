// HWFButton.cs
namespace HelloWindowsFormsNamespace {
    
    using System;
    using System.Drawing;
    using System.ComponentModel;
    using System.Windows.Forms;
    using System.Runtime.InteropServices;

public class HelloWindowsForms : System.Windows.Forms.Form
{


    //Label 1 is the component that displays the text messace "Hello Windows Forms!"
    private System.Windows.Forms.Label label1;

    //Adding a button member allows us to place a button on the panel.
    private System.Windows.Forms.Button button1;
        
    //The constructor is where all initialization happens.
    //For forms created with the designer there is an InitializeComponent() method.
    public HelloWindowsForms() 
    {

        this.label1 = new System.Windows.Forms.Label();
    
        label1.Location = new System.Drawing.Point(8, 8);
        label1.Text = "Hello Windows Forms!";
        label1.Size = new System.Drawing.Size(408, 48);
        label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24f);
        label1.TabIndex = 0;
        label1.TextAlign = ContentAlignment.MiddleCenter;

    this.button1=new System.Windows.Forms.Button();

    button1.Location=new System.Drawing.Point(8,58);
    button1.Size = new System.Drawing.Size(408,25);
    button1.Text = "Click Me!";
    button1.TabIndex = 1;
    button1.Click += new EventHandler(OnButton1Clicked);

        this.Text = "Hello World";
        this.MaximizeBox = false;
        this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        this.MinimizeBox = false;
        this.ClientSize = new System.Drawing.Size(426, 85);

        this.Controls.Add(label1);
    this.Controls.Add(button1);
    }

    void OnButton1Clicked(Object sender,EventArgs e)
    {
    if(this.label1.Text == "Hello Windows Forms!")
        this.label1.Text = "You Clicked?";
    else
        this.label1.Text = "Hello Windows Forms!";
    }

    
    // This main function instantiates a new form and runs it.
    public static void Main(string[] args)
    {
            Application.Run(new HelloWindowsForms());
    }
}

} // end of namespace
