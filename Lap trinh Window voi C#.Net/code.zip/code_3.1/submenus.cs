using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;

//This application shows off some of the menu features
//Lines below have been added but then commented out
//please feel free to remove the comment slashes to
//see the effect of the commands.
public class submenuapp : System.Windows.Forms.Form
{

    public  submenuapp()
    {
        this.Text = "SubMenuApp";
        this.MaximizeBox = true;
        this.BorderStyle = FormBorderStyle.Sizable;

        MainMenu menu = new MainMenu();

        MenuItem filemenu = new MenuItem();
        filemenu.Text = "&File";
        menu.MenuItems.Add(filemenu);

            MenuItem open = new MenuItem();
            open.Text = "&Open";
            filemenu.MenuItems.Add(open);

            MenuItem print= new MenuItem();
            print.Text = "Print...";
            filemenu.MenuItems.Add(print);

                MenuItem temp= new MenuItem();
                temp.Text = "Pre&view";
                print.MenuItems.Add(temp);

                temp= new MenuItem();
                temp.Text = "To &File";
                print.MenuItems.Add(temp);

            MenuItem exit= new MenuItem();
            exit.Text = "E&xit";
            filemenu.MenuItems.Add(exit);
    
        this.Menu = menu;

        ContextMenu cmenu = new ContextMenu();
        cmenu.MenuItems.Add(new MenuItem("&First"));
        cmenu.MenuItems.Add(new MenuItem("&Second"));
        cmenu.MenuItems.Add(new MenuItem("-"));
        cmenu.MenuItems.Add(new MenuItem("&Third"));


        this.ContextMenu=cmenu;


    }

    static void Main()
    {
        Application.Run(new submenuapp());
    }

}