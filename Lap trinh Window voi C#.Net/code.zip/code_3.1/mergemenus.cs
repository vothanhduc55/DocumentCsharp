using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;

namespace Sams {
class menuorder : System.Windows.Forms.Form
{
    MainMenu m_menu;
    MenuItem m_workingmenu;
    MenuItem m_menuentry;

    // this event handler is called whenever an item is used
    void OnUsed(Object sender, EventArgs e)
    {
        for(int i=0;i<m_menuentry.MenuItems.Count;i++)
            m_menuentry.MenuItems[i].MergeOrder ++;

        MenuItem m=(MenuItem)sender;

        m.MergeOrder--;

        if(m.MergeOrder < 0)
            m.MergeOrder = 0;

    }

    // this event handler is also invoked. You could have
    // many event handlers attached to the Click sources
    void OnClicked(Object sender, EventArgs e)
    {
        MenuItem m=(MenuItem)sender;
        MessageBox.Show("You clicked "+m.Text);
    }

    //As a menu is popped up it is constructed on the fly.
    void OnPopup(Object sender, EventArgs e)
    {
        m_menu.MenuItems.Clear();
        m_workingmenu.MenuItems.Clear();
        m_workingmenu.MergeMenu(m_menuentry);
        m_menu.MenuItems.Add(m_workingmenu);
    }

    // Sets up the initial menu text and orders.
    public menuorder()
    {

        string[] s=new string[8]{"Cats","Dogs","Elephants","Geese","Mooses","Rats","Giunea-pigs","Horses"};

        m_menu = new MainMenu();
        m_menuentry = new MenuItem("&Menu");
        m_menuentry.Popup += new EventHandler(OnPopup);

        m_workingmenu = new MenuItem();
        
        for(int i=0;i<8;i++)
        {
            MenuItem temp = new MenuItem(s[i]);
            temp.MergeOrder=i;
            temp.Click+=new EventHandler(OnUsed);
            temp.Click+=new EventHandler(OnClicked);
            m_menuentry.MenuItems.Add(temp);
        }        
        
        m_workingmenu.MergeMenu(m_menuentry);
        m_menu.MenuItems.Add(m_workingmenu);
        this.Menu = m_menu;
    }

    // instantiates and runs the application.
    public static void Main()
    {
        Application.Run(new menuorder());
    }
}

}