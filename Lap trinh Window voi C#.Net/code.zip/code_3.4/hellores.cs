namespace Sams
{
	using System;
	using System.Drawing;
	using System.Collections;
	using System.ComponentModel;
	using System.Globalization;
	using System.Windows.Forms;
	using System.Data;
	using System.Resources;

	class hellores: Form
	{

		public hellores()
		{
			ResourceManager rm=new ResourceManager("firstresource",this.GetType().Assembly);

			this.Size = new Size(400,100);
			this.Text=rm.GetString("WindowText");

			Label l = new Label();
			l.Location = new Point(3,5);
			l.Size = new Size(394,90);
			l.Font = new Font("Tahoma",36F,FontStyle.Bold);
			l.Text=rm.GetString("LabelText");
			this.Controls.Add(l);

		}

		static void Main()
		{
			Application.Run(new hellores());
		}
	}

}