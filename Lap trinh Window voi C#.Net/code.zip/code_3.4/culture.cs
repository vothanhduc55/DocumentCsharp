namespace Sams
{
	using System;
	using System.Drawing;
	using System.Collections;
	using System.ComponentModel;
	using System.Globalization;
	using System.Windows.Forms;
	using System.Data;

class CultureInfoTest : Form
{

	public CultureInfoTest()
	{
		this.Size = new Size(300,200);

		Label l = new Label();
		l.Location = new Point(3,5);
		l.Size = new Size(294,190);

		InputLanguage inL = InputLanguage.CurrentInputLanguage;

		CultureInfo info = inL.Culture;

		l.Text = String.Format("Culture identifier = {0}\n"+
			              "Display name = {1}\n"+
						  "Calender = {2}\n",
						  info.ToString(),
						  info.DisplayName,
			              info.Calendar.ToString());
		this.Controls.Add(l);

	}
	static void Main()
	{
		Application.Run(new CultureInfoTest());
	}
}

}