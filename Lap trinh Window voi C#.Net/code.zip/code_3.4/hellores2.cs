namespace Sams
{
	using System;
	using System.Drawing;
	using System.Collections;
	using System.ComponentModel;
	using System.Globalization;
	using System.Windows.Forms;
	using System.Data;
	using System.Resources;
	using System.Threading;

	class hellores: Form
	{

		private Label l;
		private ResourceManager rm;


		public hellores(string culture)
		{
			Thread.CurrentThread.CurrentUICulture = new CultureInfo(culture);

			rm=new ResourceManager("firstresource",this.GetType().Assembly);

			this.Size = new Size(400,100);
			this.Text=rm.GetString("WindowText");

			l = new Label();
			l.Location = new Point(3,5);
			l.Size = new Size(394,90);
			l.Font = new Font("Tahoma",36F,FontStyle.Bold);
			l.Text=rm.GetString("LabelText");
			l.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Right);
			this.Controls.Add(l);

		}

		static void Main(string[] args)
		{
			string culture ="";
			if(args.Length == 1)
				culture = args[0];
			Application.Run(new hellores(culture));
		}
	}

}