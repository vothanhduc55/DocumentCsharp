Thanks for downloading the source files for the book C# and the .NET Framework

The C# source files for Part 3, Windows Forms, contained old .NET framework beta code that will prevent them from running on recent versions of the framework. The files in this archive have been updated to run with the latest version of the SDK.

To compile the files simply use the command line:

csc /t:winexe <source-filename>

For example:

csc /t:winexe gridbind.cs

Thank you and sorry for the inconvienience.

Bob Powell.