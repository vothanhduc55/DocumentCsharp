using System;

namespace SharedComponent
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class SharedServer
	{
		//Single method to return version information
		public string WhoAmI( ) {

			string me = "Hello from version 1.1";
			return me;
		}
			
	}
}
