using System;
using FileTwo;


namespace FileOne {


	public class ClassOne {

		public static void Main( ) {

			ClassTwo ct = new ClassTwo( );
			
			ct.SayHello( );
		}
	}
}

