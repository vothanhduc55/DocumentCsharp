using System;


namespace FileTwo {


	public class ClassTwo {

		public void SayHello( ) {
			Console.WriteLine( "Hello From FileTwo.ClassTwo" );
		}
	}
}