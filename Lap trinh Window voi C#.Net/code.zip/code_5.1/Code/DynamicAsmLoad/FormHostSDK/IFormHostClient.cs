///Simple Interface for forms
///
using System;

namespace FormHostSDK
{
	public interface IFormHostClient {
		string MenuText {
			get;
		}
	}
}
