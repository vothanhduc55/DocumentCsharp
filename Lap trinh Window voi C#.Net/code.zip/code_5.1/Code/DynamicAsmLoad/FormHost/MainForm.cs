using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Reflection;
using System.IO;
using FormHostSDK;

namespace FormHost
{
	/// <summary>
	/// Summary description for MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.MdiClient mdiClient1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem FileMenuItem;
		private System.Windows.Forms.MenuItem FormsMenuItem;
		private System.Windows.Forms.MenuItem ExitMenuItem;
		private Hashtable		forms = new Hashtable( );
		
		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			LoadForms( );
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mdiClient1 = new System.Windows.Forms.MdiClient();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.FileMenuItem = new System.Windows.Forms.MenuItem();
			this.FormsMenuItem = new System.Windows.Forms.MenuItem( );
			this.ExitMenuItem = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// mdiClient1
			// 
			this.mdiClient1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.mdiClient1.Name = "mdiClient1";
			this.mdiClient1.TabIndex = 0;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(
				new System.Windows.Forms.MenuItem[] {  this.FileMenuItem,
													   this.FormsMenuItem
													 }
				                              );
			// 
			// FormsMenuItem
			// 
			this.FormsMenuItem.Index = 1;
			this.FormsMenuItem.Text = "F&orms";

			//
			// FileMenuItem
			//
			this.FileMenuItem.Index = 0;
			this.FileMenuItem.Text  = "&File";
			this.FileMenuItem.MenuItems.Add( this.ExitMenuItem );

			// 
			// menuItemExit
			// 
			this.ExitMenuItem.Index = 0;
			this.ExitMenuItem.Text = "E&xit";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(576, 429);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.mdiClient1});
			this.IsMdiContainer = true;
			this.Menu = this.mainMenu1;
			this.Name = "MainForm";
			this.Text = "MainForm";
			this.ResumeLayout(false);

		}
		#endregion


		/// <summary>
		/// load any dynamic forms 
		/// </summary>
		protected void LoadForms( ) {
			string FormsDir = string.Format("{0}\\DynamicForms",Application.StartupPath);
			
			//Locate all Assemblies (DLL's only)
			string[] Files = Directory.GetFiles( FormsDir, "*.dll" );

			foreach( string strFile in Files ) {
				System.Reflection.Assembly curAsm = System.Reflection.Assembly.LoadFrom( strFile );

				//Look at the exposed types
				System.Type[] types = curAsm.GetTypes( );
					foreach( Type T in types ) {
						if( T.IsSubclassOf( typeof( Form ) ) ) {
						
							//Create an instance and add to main menu
							Form frm = (Form)curAsm.CreateInstance( T.FullName );
							this.forms.Add( ((IFormHostClient)frm).MenuText, T );

							MenuItem newItem = new MenuItem( ((IFormHostClient)frm).MenuText, new EventHandler( this.OnFormSelectMenu ) );
							FormsMenuItem.MenuItems.Add( newItem );
						}
					}
			}
		}

		/// <summary>
		/// Create an instance of the requested form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void OnFormSelectMenu( object sender, EventArgs e ) {
			MenuItem mi = (MenuItem)sender;
			if( this.forms.ContainsKey( mi.Text ) ) {
				Type T = (Type)this.forms[ mi.Text ];
				Form frmChild = (Form)Activator.CreateInstance( T );
				frmChild.MdiParent = this;
				frmChild.Show( );
			}
		}
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}
	}
}
