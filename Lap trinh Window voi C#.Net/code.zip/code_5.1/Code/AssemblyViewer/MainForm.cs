using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace AssemblyViewer
{
	/// <summary>
	/// Summary description for MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TreeView tvAsmTree;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.TextBox txtCurrentClass;
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem fileMenuItem;
		private System.Windows.Forms.MenuItem fileLoadMenuItem;
		private System.Windows.Forms.MenuItem fileExitMenuItem;
		private System.Windows.Forms.OpenFileDialog openFileDialog;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;


		private AssemblyViewer.ASMContent.AssemblyHierarchy	asmHierarchy	= null;


		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tvAsmTree = new System.Windows.Forms.TreeView();
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.fileMenuItem = new System.Windows.Forms.MenuItem();
			this.fileLoadMenuItem = new System.Windows.Forms.MenuItem();
			this.fileExitMenuItem = new System.Windows.Forms.MenuItem();
			this.txtCurrentClass = new System.Windows.Forms.TextBox();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.SuspendLayout();
			// 
			// tvAsmTree
			// 
			this.tvAsmTree.Dock = System.Windows.Forms.DockStyle.Left;
			this.tvAsmTree.ImageIndex = -1;
			this.tvAsmTree.Name = "tvAsmTree";
			this.tvAsmTree.SelectedImageIndex = -1;
			this.tvAsmTree.Size = new System.Drawing.Size(121, 421);
			this.tvAsmTree.TabIndex = 0;
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.fileMenuItem});
			// 
			// fileMenuItem
			// 
			this.fileMenuItem.Index = 0;
			this.fileMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.fileLoadMenuItem,
																						 this.fileExitMenuItem});
			this.fileMenuItem.Text = "&File";
			// 
			// fileLoadMenuItem
			// 
			this.fileLoadMenuItem.Index = 0;
			this.fileLoadMenuItem.Text = "&Load";
			this.fileLoadMenuItem.Click += new System.EventHandler(this.fileLoadMenuItem_Click);
			// 
			// fileExitMenuItem
			// 
			this.fileExitMenuItem.Index = 1;
			this.fileExitMenuItem.Text = "E&xit";
			// 
			// txtCurrentClass
			// 
			this.txtCurrentClass.AcceptsTab = true;
			this.txtCurrentClass.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtCurrentClass.Location = new System.Drawing.Point(124, 0);
			this.txtCurrentClass.Multiline = true;
			this.txtCurrentClass.Name = "txtCurrentClass";
			this.txtCurrentClass.ReadOnly = true;
			this.txtCurrentClass.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtCurrentClass.Size = new System.Drawing.Size(396, 421);
			this.txtCurrentClass.TabIndex = 2;
			this.txtCurrentClass.Text = "";
			// 
			// openFileDialog
			// 
			this.openFileDialog.Filter = "DLL\'s|*.dll|EXE\'s|*.exe";
			this.openFileDialog.Title = "Assembly Viewer";
			// 
			// splitter1
			// 
			this.splitter1.Location = new System.Drawing.Point(121, 0);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(3, 421);
			this.splitter1.TabIndex = 1;
			this.splitter1.TabStop = false;
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(520, 421);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.txtCurrentClass,
																		  this.splitter1,
																		  this.tvAsmTree});
			this.Menu = this.mainMenu;
			this.Name = "MainForm";
			this.Text = "Assembly Viewer";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void fileLoadMenuItem_Click(object sender, System.EventArgs e) {
			if( DialogResult.OK == this.openFileDialog.ShowDialog( ) ) {
				this.asmHierarchy = new AssemblyViewer.ASMContent.AssemblyHierarchy( );
				this.asmHierarchy.LoadAssembly( this.openFileDialog.FileName );
				PopulateTreeView( );
			}
		}

		private void PopulateTreeView( ) {
			this.tvAsmTree.Nodes.Clear( );

			//Create a rootnode
			System.Windows.Forms.TreeNode rootNode = new TreeNode( this.asmHierarchy.Name );

			//add only top level namespace nodes
			IDictionaryEnumerator dictEnum = this.asmHierarchy.Namespaces.GetEnumerator( );
			ArrayList namespaces = new ArrayList( );
			while( dictEnum.MoveNext( ) ) {
				DictionaryEntry de = (DictionaryEntry)dictEnum.Current;
				namespaces.Add( de.Key );
			}
			namespaces.Sort( );
			foreach( string s in namespaces ) {
				TreeNode tn = new TreeNode( s );
				//add dummy node
				TreeNode tnDummy = new TreeNode( );
				tn.Nodes.Add( tnDummy );
				rootNode.Nodes.Add( tn );
			}
			
			this.tvAsmTree.BeforeExpand += new TreeViewCancelEventHandler( this.OnBeforeExpand );
			this.tvAsmTree.AfterSelect += new TreeViewEventHandler( this.OnNodeSelect );
			this.tvAsmTree.ShowLines = true;
			this.tvAsmTree.ShowPlusMinus = true;
			this.tvAsmTree.ShowRootLines = true;
			this.tvAsmTree.Nodes.Add( rootNode );
			rootNode.Expand( );
			
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void OnBeforeExpand( object sender, TreeViewCancelEventArgs e ) {
			if( e.Node.Text.CompareTo( this.asmHierarchy.Name) == 0 ) 
				return;

			//Must be a sub node in the tree
			//get full name
			string nsPath =  e.Node.FullPath;
			int marker = nsPath.IndexOf( "\\" );
			nsPath = nsPath.Substring( marker + 1 );
			nsPath = nsPath.Replace( "\\", "." );
			PopulateTreeNode( nsPath, e.Node );

		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void OnNodeSelect( object sender, TreeViewEventArgs e ) {
			
			if( e.Node.Nodes.Count == 0 ) {
				//Must be a type, so render the code for it and display it
				string nsPath =  e.Node.FullPath;
				int marker = nsPath.IndexOf( "\\" );
				nsPath = nsPath.Substring( marker + 1 );
				nsPath = nsPath.Replace( "\\", "." );
				Type T = this.asmHierarchy.GetEntityType( nsPath );
				System.IO.MemoryStream ms = new System.IO.MemoryStream( );
				AssemblyViewer.ASMContent.TypeSourceEngine.GenerateCode( T, ms );
				ms.Position = 0;
				System.IO.StreamReader sr = new System.IO.StreamReader( ms );
				this.txtCurrentClass.Text = sr.ReadToEnd( );
			}
		}

		protected void PopulateTreeNode( string namespacePath, TreeNode tn ) {
			tn.Nodes.Clear( );

			string[] nspath = namespacePath.Split( '.' );
			AssemblyViewer.ASMContent.ASMNamespace ns =(AssemblyViewer.ASMContent.ASMNamespace)this.asmHierarchy.Namespaces[ nspath[ 0 ] ];

			for( int i = 1; i < nspath.Length; i++ )
				ns = (AssemblyViewer.ASMContent.ASMNamespace)ns.Namespaces[ nspath[ i ] ];

			//Now we have the proper namespaces and types.   Begin by creating Namespace entires first
			IDictionaryEnumerator NSEnum = ns.Namespaces.GetEnumerator( );
			ArrayList aryList = new ArrayList( );
			while( NSEnum.MoveNext( ) ) {
				DictionaryEntry de = (DictionaryEntry)NSEnum.Current;
				aryList.Add( de.Key );
			}
			aryList.Sort( );

			foreach( string s in aryList ) {
				TreeNode ltn = new TreeNode( s );
				TreeNode dummy = new TreeNode( );
				ltn.Nodes.Add( dummy );
				tn.Nodes.Add( ltn );
			}

			//Now add the Types
			NSEnum = ns.Types.GetEnumerator( );
			aryList.Clear( );
			while( NSEnum.MoveNext( ) ) {
				DictionaryEntry de = (DictionaryEntry)NSEnum.Current;
				aryList.Add( de.Key );
			}
			aryList.Sort( );
			foreach( string s in aryList ) {
				TreeNode ltn = new TreeNode( s );
				tn.Nodes.Add( ltn );
			}

		}
	}
}
