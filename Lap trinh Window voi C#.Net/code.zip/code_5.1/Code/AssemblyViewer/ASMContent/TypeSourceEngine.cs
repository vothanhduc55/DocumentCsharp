using System;
using System.Collections;
using System.Reflection;

namespace AssemblyViewer.ASMContent
{
	/// <summary>
	/// Summary description for TypeSourceEngine.
	/// </summary>
	public class TypeSourceEngine
	{
		public static BindingFlags BF = BindingFlags.Public | 
			                            BindingFlags.NonPublic  | 
			                            BindingFlags.Instance | 
			                            BindingFlags.Static |
									    BindingFlags.DeclaredOnly;


		/// <summary>
		/// Generate C# code from a given Type
		/// </summary>
		/// <param name="T">Type used for code generation</param>
		/// <param name="stream">Stream object to write to</param>
		public static void GenerateCode( Type T, System.IO.Stream stream ) {
			
			System.IO.StreamWriter sw = new System.IO.StreamWriter( stream );
				
			if( T.IsEnum )
				GenerateEnum( T, sw );
			else
				GenerateClassOrInterface( T, sw );
			
		}

		/// <summary>
		/// If the Type is a class or interface, generate the proper code
		/// </summary>
		/// <param name="T"></param>
		/// <param name="sw"></param>
		private static void GenerateClassOrInterface( Type T, System.IO.StreamWriter sw ) {
			ArrayList Fields;
			ArrayList Properties;
			ArrayList Methods;
			ArrayList Events;
			
			GenerateFields( T, out Fields );
			GenerateProperties( T, out Properties );
			GenerateEvents( T, out Events );
			GenerateMethods(T, out Methods );

			sw.Write( GenerateTypeStmt( T ) );
			sw.Write( "\r\n" );
			Inject( sw, Fields, "Fields" );
			Inject( sw, Properties, "Properties" );
			Inject( sw, Events, "Events" );
			Inject( sw, Methods, "Methods" );
			sw.Write("}");
			sw.Flush( );
		}

		/// <summary>
		/// Generate code for an Enum type
		/// </summary>
		/// <param name="T"></param>
		/// <param name="sw"></param>
		private static void GenerateEnum( Type T, System.IO.StreamWriter sw ) {
			ArrayList Fields;
			GenerateFields( T, out Fields );
			sw.Write( GenerateTypeStmt( T ) );
			sw.Write( "\r\n" );
			Inject( sw, Fields, "Fields" );
			sw.Write("}");
			sw.Flush( );
		}

		/// <summary>
		/// Creates a type declaration statement:
		/// (public | private) [abstract|sealed] [interface|class|struct] TypeName [: [Base Class], [Interfaces] ]
		/// </summary>
		/// <param name="T"></param>
		/// <returns></returns>
		private static string GenerateTypeStmt( Type T ) {
			string stmt = "";

			if( T.IsPublic )
				stmt = "public ";
			else if( T.IsNotPublic )
				stmt = "private ";
			
			if( T.IsAbstract )
				stmt += "abstract ";
			else if( T.IsEnum )
				stmt += "enum ";
			else if( T.IsInterface )
				stmt += "interface ";
			else if( T.IsSealed )
				stmt += "sealed ";

			if( T.IsClass )
				stmt += "class ";
			else if (T.IsInterface )
				stmt += "interface ";
			else 
				stmt += "struct ";

			bool bHasBase = false;
			stmt += string.Format( "{0} ", T.Name );
			if( T.BaseType != null ) {
				stmt += string.Format(": {0}", T.BaseType.Name);
				bHasBase = true;
			}
			
			System.Type[] Interfaces  = T.GetInterfaces( );
			if( Interfaces.Length != 0 ) {
				if( !bHasBase )
					stmt += ": ";
				foreach( Type tt in Interfaces ) {
					stmt += tt.Name;
					stmt += ", ";
				}
				stmt = stmt.Substring(0, stmt.Length - 1);
			}
			stmt += " {";
			return stmt;
		}

		/// <summary>
		/// Inject source into StreamWriter
		/// </summary>
		/// <param name="al"></param>
		/// <param name="EntryType"></param>
		private static void Inject( System.IO.StreamWriter sw, ArrayList al, string EntryType ) {
			sw.Write("\t///////////////////////////////////\r\n");
			sw.Write(string.Format("\t// {0}\r\n", EntryType));
			sw.Write("\t///////////////////////////////////\r\n");
			foreach( string s in al ) {
				sw.Write("\t");
				sw.Write( s );
				sw.Write( "\r\n" );
			}
			sw.Write("\r\n");
		}


		/// <summary>
		/// Generate Field declarations
		/// </summary>
		/// <param name="T"></param>
		/// <param name="fieldList"></param>
		private static void GenerateFields( Type T, out ArrayList fieldList ) {
			fieldList = new ArrayList( );
			FieldInfo[] fields = T.GetFields( BF );
			foreach( FieldInfo fi in fields ) {
				fieldList.Add( GenerateFieldStmt( fi ) );
			}
		}

		/// <summary>
		/// Generate the actual field stmt
		/// ie: private int someFieldMember;
		/// </summary>
		/// <param name="fi"></param>
		/// <returns></returns>
		private static string GenerateFieldStmt( FieldInfo fi ) {
			string stmt;

			if( fi.IsPublic )
				stmt = "public ";
			else if( fi.IsPrivate )
				stmt = "private ";
			else
				stmt = "protected ";

			if( fi.IsStatic )
				stmt += "static ";

			stmt += fi.FieldType.Name;
			stmt += " ";
			stmt += fi.Name;
			stmt += ";";
			return stmt;
		}
		
		private static void GenerateProperties( Type T, out ArrayList propertyList ) {
			PropertyInfo[] props = T.GetProperties(  );
			propertyList = new ArrayList( );
			foreach( PropertyInfo pi in props )
				propertyList.Add( GeneratePropStmt( pi ) );

		}

		private static string GeneratePropStmt( PropertyInfo pi ) {
			string stmt = "public ";
			stmt += pi.PropertyType.Name;
			stmt += " ";
			stmt += pi.Name;
			stmt += " { ";
			if( pi.CanRead )
				stmt += "get; ";
			if( pi.CanWrite )
				stmt += "set; ";
			stmt += " }; ";
			return stmt;
		}
		
		
		private static void GenerateMethods( Type T, out ArrayList methodList ) {
			MethodInfo[] Methods = T.GetMethods( BF );
			methodList = new ArrayList( );
			foreach( MethodInfo mi in Methods )
				methodList.Add( GenerateMethodStmt( mi ) );

		}

		private static string GenerateMethodStmt( MethodInfo mi ) {
			string stmt;

			if( mi.IsPublic )
				stmt = "public ";
			else if( mi.IsPrivate )
				stmt = "private ";
			else if( mi.IsFamily )
				stmt = "protected ";
			else
				stmt = "protected internal ";
			if( mi.IsVirtual )
				stmt += "virtual ";
			else if( mi.IsAbstract )
				stmt += "abstract ";

			stmt += string.Format("{0} {1}( ", mi.ReturnType.Name, mi.Name );
			ParameterInfo[] Params = mi.GetParameters( );
			if( Params.Length > 0 ) {
				int i;
				for( i = 0; i < Params.Length - 1; i++ )
					stmt += string.Format("{0}, ",GenerateParamStmt( Params[i] ) );
				stmt += string.Format("{0} ", GenerateParamStmt( Params[ i ] ) );
			}
			stmt += ");";
			return stmt;
		}

		private static string GenerateParamStmt( ParameterInfo pi ) {
			string stmt = "";
			if( pi.IsIn )
				stmt = "[in] ";
			else if( pi.IsOut )
				stmt = "[out] ";
			else if ( pi.IsRetval ) 
				stmt = "[ref] ";
			stmt += string.Format( "{0} {1}",pi.ParameterType.Name, pi.Name );
			return stmt;
		}

		private static void GenerateEvents( Type T, out ArrayList eventList ) {
			EventInfo[] Events = T.GetEvents( BF );
			eventList= new ArrayList( );
			foreach( EventInfo ei in Events )
				eventList.Add( GenerateEventStmt( ei ) );
		}

		private static string GenerateEventStmt( EventInfo ei ) {
			return string.Format("public {0} {1};", ei.EventHandlerType.Name, ei.Name );
		}

	}
}
