using System;
using System.Reflection;
using System.Collections;

namespace AssemblyViewer.ASMContent
{
	/// <summary>
	/// Summary description for AssemblyHierarchy.
	/// </summary>
	public class AssemblyHierarchy
	{
		private Assembly		currentAssembly	= null;
		private Hashtable		namespaces		= new Hashtable( );



		public string Name {
			get {
				return currentAssembly.FullName;
				}
		}
		
		public Hashtable Namespaces {
			get {
				return namespaces;
			}
		}

		
		public AssemblyHierarchy() {
			//Do Nothing
		}


		/// <summary>
		/// Load the given assembly and create a hierarchy of namespaces
		/// and types within each namespace
		/// </summary>
		/// <param name="assemblyFile"></param>
		/// <returns></returns>
		public bool LoadAssembly( string assemblyFile ) {
			bool bSuccess = true;
			try {
				currentAssembly = Assembly.LoadFrom( assemblyFile );

				Type[] Types = currentAssembly.GetTypes( );
				
				foreach( Type T in Types )
					AddType( T );

			} catch( Exception ) {

				currentAssembly = null;
				namespaces.Clear( );
				namespaces = null;
				bSuccess = false;
			}
			return bSuccess;
		}

		public Type GetEntityType( string nsPath ) {
			string[] ns = nsPath.Split( '.' );
			ASMNamespace nsBase = (ASMNamespace)this.namespaces[ ns[0] ];
			for( int i = 1; i < ns.Length - 1; i++ )
				nsBase = (ASMNamespace)nsBase.Namespaces[ ns[i] ];
			return (Type)nsBase.Types[ ns[ ns.Length - 1] ];
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="T"></param>
		protected void AddType( Type T ) {
			try {
				if( T.FullName.IndexOf( "<Private", 0 ) != -1 )
					return;
			
				string QualifiedName = T.FullName;
				string[] names = QualifiedName.Split( '.' );

				//The last name is the name of the type, all other entires represent
				//the namespace nesting
				ASMNamespace current = null;
				if( !this.namespaces.ContainsKey( names[0] ) ) {
					ASMNamespace newNamespace = new ASMNamespace( names[0] );
					this.namespaces.Add( names[0], newNamespace );
					System.Diagnostics.Debug.Assert( this.namespaces.ContainsKey( names[0] ) );
				}
			
				current = (ASMNamespace)this.namespaces[ names[0] ];

				for( int i = 1; i < names.Length - 1; i++ ) {
					if( !current.Namespaces.ContainsKey( names[i] ) ) {
						ASMNamespace newNamespace = new ASMNamespace( names[i] );
						current.Namespaces.Add( names[i], newNamespace );
					}
					current = (ASMNamespace)current.Namespaces[ names[i] ];
				}

				//Now that we have the containing namespace, add the type
				current.AddType( T );
			} catch( Exception e ) {
				string s = e.Message;
			}
		}

	}
}
