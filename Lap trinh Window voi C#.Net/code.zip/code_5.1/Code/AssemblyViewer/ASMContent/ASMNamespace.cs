using System;
using System.Reflection;
using System.Collections;


namespace AssemblyViewer.ASMContent
{
	
	/// <summary>
	/// Summary description for ASMNamespace.
	/// </summary>
	public class ASMNamespace
	{
		private string		name			= null;
		private Hashtable	asmNamespaces	= new Hashtable( );
		private Hashtable	asmTypes		= new Hashtable( );


		public string Name {
			get { return name; }
		}

		public Hashtable Namespaces {
			get {
				return asmNamespaces;
			}
		}

		public Hashtable Types {
			get {
				return asmTypes;
			}
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="name"></param>
		public ASMNamespace( string name )
		{
			this.name = name;
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="namespaceName"></param>
		public void AddNamespace( string namespaceName ) {
			if( !asmNamespaces.ContainsKey( namespaceName ) ) {
				ASMNamespace lNamespace = new ASMNamespace( namespaceName );
				asmNamespaces.Add( namespaceName, lNamespace );
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="T"></param>
		public void AddType( Type T ) {
			if( !asmTypes.ContainsKey( T.Name ) ) {
				asmTypes.Add( T.Name, T );
			}
		}
	}
}
