//File    :02_10.cs
//Author  :Richard L. Weeks
//Purpose :Demonstrate the use of the goto statment


using System;


public class GotoTest {

    public static void Main( ) {


         Console.WriteLine("about to goto label1");
         goto label1;
	
         Console.WriteLine("This will not print");

    label1:
         Console.WriteLine("label1 goto effective");
    }
}