//File      :part02_07.cs
//Author    :Richard L. Weeks
//Purpose   :conditional-operator



using System;


public class StatementTest {


	public static void Main( ) {

		Console.Write("Enter an number between 1 and 10: ");
		int i = Int32.FromString( Console.ReadLine( ) );


		//is the number in the proper range
		if( (i >= 1) && (i <= 10) ) {
			
			//is the number even or odd?
			string odd_even = (i % 2) == 0 ? "even" : "odd";

			Console.WriteLine( "The number {0} is {1}", i, odd_even );
				
		} else 
		   Console.WriteLine("You must enter a number between 1 and 10");
		
	}
}