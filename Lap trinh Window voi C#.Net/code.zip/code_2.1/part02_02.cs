//File		:part02_02.cs
//Author	:Richard L. Weeks
//Purpose	:Declare a simple struct

using System;

struct Fraction {

	public int numerator;
	public int denominator;

	public void Print( ) {
		Console.WriteLine( "{0}/{1}", numerator, denominator );
	}

}


public class StructTest {

	public static void Main( ) {

		Fraction f;
		f.numerator   = 5;
		f.denominator = 10;
		f.Print( );

		Fraction f2 = f;
		f.Print( );

		//modify struct instance f2
		f2.numerator = 1;

		f.Print( );
		f2.Print( );


	}
}