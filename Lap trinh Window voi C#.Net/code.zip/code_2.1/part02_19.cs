//File		:part02_19.cs
//

using System;


public struct Point {
	public int x;
	public int y;
}


public class StructTest {

	public static void Main( ) {

		Point p;

		p.x = 5;
		p.y = 10;

		Point p2 = p;


		PrintPoint( p );
		PrintPoint( p2 );
	}

	public static void PrintPoint( Point p ) {
		Console.WriteLine( "x = {0}, y = {1}", p.x, p.y );
	}
}