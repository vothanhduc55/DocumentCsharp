using System;



public class Newton {

	private double m_dblValue;
	private double m_dblResult;


	public Newton( ) {
		m_dblValue  = 1.0;
		m_dblResult = 0.0;
        }

	//Properties

	//Value is set/get
	public double Value {
		set { 
			if( value <= 0 ) {
			   Console.WriteLine("Value must be greater than Zero");
			   return;
			}
			m_dblValue = value;	//the rhs is value
		}

		get { return m_dblValue; }
	}

	//The result is get only.
	public double Result {
		get { return m_dblResult; }
	}

	//Find the Square Root of m_dblValue
	public void FindSqrt( ) {
		const double Eplison = 1.0e-9;
		double	     Guess   = 11;

		m_dblResult = ((m_dblValue / Guess) + Guess) / 2;

		while( Math.Abs( m_dblResult - Guess ) > Eplison ) {
			Guess  = m_dblResult;
			m_dblResult = ((m_dblValue / Guess) + Guess) / 2;
		}
	}
}




public class PropertyTest {

	public static void Main( ) {

		Newton n = new Newton( );

		//set the requested value
		n.Value = 100;

		//Find the Sqrt of 100
		n.FindSqrt( );

		//display the result
		Console.WriteLine("The Sqrt of {0} is {1}", n.Value, n.Result );
	}
}

		