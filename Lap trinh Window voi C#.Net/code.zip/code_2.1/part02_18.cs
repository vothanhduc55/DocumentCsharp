//File    :part02_18.cs
//Author  :Richard L. Weeks
//Purpose :Arrays with a Rank greater than 1


using System;


public class ArrayTest {


    public static void Main( ) {


        int[,] grid = new int[3,3] { {1,2,3}, {4,5,6}, {7,8,9} };

	
	//Display the contents of the grid
        for( int i = 0; i < 3; i++ ) {
            for( int j = 0; j < 3; j++ ) {
                Console.Write("{0,3}", grid[i,j] );
            }
            Console.WriteLine("");
        }
    }
}         