//File       :02_06.cs
//Date       :12.28.2000
//Author     :Richard L. Weeks
//Purpose    :Demonstrate Namespaces


using System;     



namespace Foo {

	public class Money {

		private double m_Amount;

		public Money( ) {
			Init( 0.0 );
		}

		public Money( double Amount ) {
			Init( Amount );
		}


		public void Print( ) {
			Console.WriteLine("Foo.Money.Print  {0}", m_Amount );
		}


		private void Init( double Amount ) {
			m_Amount = Amount;
		}
	}
}

namespace Bar {

	public class Money {

		private double m_Amount;

		public Money( ) {
			Init( 0.0 );
		}

		public Money( double Amount ) {
			Init( Amount );
		}


		public void Print( ) {
			Console.WriteLine("Bar.Money.Print  {0}", m_Amount );
		}


		private void Init( double Amount ) {
			m_Amount = Amount;
		}
	}
}


public class NamespaceTest {

	public static void Main( ) {

		Foo.Money fm = new Foo.Money(5.00);
		Bar.Money bm = new Bar.Money(5.00);


		fm.Print( );
		bm.Print( );

		
	}
}