using System;


public class MyMath {


	//instance method
	public long Factorial( long l ) {
		return l <= 0 ? 1 : l * Factorial( l - 1 );
	}


	//static method
	public static long SFactorial( long l ) {
		return l <= 0 ? 1 : l * SFactorial( l - 1 );
	}
}




public class Methods {

	public static void Main ( ) {

		//Use the static method
		Console.WriteLine("5 Factorial = {0}", MyMath.SFactorial( 5 ) );


		//Use the instance method
		MyMath m = new MyMath( );
		Console.WriteLine("5 Factorial = {0}", m.Factorial( 5 ) );

	}
}