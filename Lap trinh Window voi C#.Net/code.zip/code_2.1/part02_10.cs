//File     :02_12.cs
//Author   :Richard L. Weeks
//Purpose  :The switch statement


using System;


public class SwitchTest {


    public static void Main( ) {


        Console.WriteLine("Please make your selection");
	Console.WriteLine("1 Hamburger");
	Console.WriteLine("2 Cheese Burger");
	Console.WriteLine("3 Fish");

	int Selection = int.Parse( Console.ReadLine( ) );


	switch( Selection ) {

		case 1:
			Console.WriteLine("Hamburger");
			goto case 4;
			

		case 2:
			Console.WriteLine("Cheese Burger");
			goto case 4;

		case 3:
			Console.WriteLine("Fish");
			break;

		case 4:
			Console.WriteLine("Transfered to case 4");
			Console.WriteLine("Transfering to default case");
			goto default;

		default:
			Console.WriteLine("Unknown choice");
	}
    }
}