//File      :part02_06.cs
//Author    :Richard L. Weeks
//Purpose   :C# if-else statment



using System;


public class StatementTest {


	public static void Main( ) {

		Console.Write("Enter an number between 1 and 10: ");
		int i = Int32.FromString( Console.ReadLine( ) );


		//is the number in the proper range
		if( (i >= 1) && (i <= 10) ) {
			
			//is the number even or odd?
			if( (i % 2) == 0 )
				Console.WriteLine("The number {0} is even", i );
			else
				Console.WriteLine("The number {0} is odd", i );
				
		} else 
		   Console.WriteLine("You must enter a number between 1 and 10");
		
	}
}