//File    :part02_13.cs
//Author  :Richard L. Weeks
//Purpose :Make use of the while statement to 
//        :implement Newton's method for finding 
//        :the square root of a number.

using System;



public class Newton {

   public static void Main( ) {


	const double epsilon   = 1.0e-9;
	      double dGuess    = 11.0;

	//Prompt the user for a positive number and obtain their input
	Console.Write("Enter a positive number: ");
	double dValue = double.Parse( Console.ReadLine( ) );

	//Calculate the Initial result value
        double dResult = ((dValue / dGuess) + dGuess) / 2;

        Console.WriteLine( "Guess Value  = {0}", dGuess  );
        Console.WriteLine( "Result Value = {0}", dResult );

	//Continue to approximate the sqr until the delta is less than epsilon
        while( Math.Abs(dResult - dGuess) > epsilon ) {

	        dGuess = dResult;
		dResult = ((dValue / dGuess) + dGuess) / 2;

	        Console.WriteLine( "Guess Value  = {0}", dGuess  );
        	Console.WriteLine( "Result Value = {0}", dResult );
	}

	Console.WriteLine( "\n****\nThe approx sqrt of {0} is {1}\n****", dValue, dResult );
    }
}

  