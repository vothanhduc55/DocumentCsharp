//File    :PurchaseOrder.cs
//Author  :Richard L. Weeks
//Purpose :Demonstrate the basics of XML serialization
//
//Compilation instructions
// csc PurchaseOrder.cs /r:System.dll,System.Xml.dll,System.Xml.Serialization.dll


using System;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;
using System.IO;


////////////////////////////
//Define the Purchase Order
[XmlRoot("purchase-order")]
public class PurchaseOrder {

	//private data
	private ArrayList	m_Items;

	public PurchaseOrder( ) {
		m_Items = new ArrayList();
	}

	//Properties
	[XmlElement("item")]
        public Item[] Items {
		get { 
			Item[] items = new Item[ m_Items.Count ];
			m_Items.CopyTo( items );
			return items; 
		}
		set { 
			Item[] items = (Item[])value;
			m_Items.Clear();
			foreach( Item i in items )
			   m_Items.Add( i );
		}
	}

	//methods
        public void AddItem( Item item ) {
		m_Items.Add( item );
	}

	//indexer
	public Item this[string sku] {
		get {
			//locate the item by sku
			foreach( Item i in m_Items )
				if( i.sku == sku )
				return i;
			throw( new Exception("Item not found") );
		}
	}

	public void DisplayItems( ) {
		foreach( Item i in m_Items )
			Console.WriteLine( i );
	}

}

/////////////////////
//Define an item entity
//[XmlRoot("item")]
public class Item {

     //item data
     [XmlAttribute("sku")]   public string  sku;
     [XmlAttribute("desc")]  public string  desc;
     [XmlAttribute("price")] public double  price;
     [XmlAttribute("qty")]   public int     qty;

	
     //Default constructor required for XML serialization
     public Item( ) {  }

     public Item( string Sku, string Desc, double Price, int Qty ) {
	sku = Sku;
	desc = Desc;
        price = Price;
        qty = Qty;
        
     }

     public override string ToString( ) {
		object[] o = new object[] { sku, desc, price, qty };
		return string.Format("{0,-5} {1,-10} ${2,5:#,###.00} {3,3}", o);
     }
}




///
///Test the XML Serialization and Deserialization
//
public class POExample {


	public static void Main( ) {

		PurchaseOrder po = new PurchaseOrder( );

		po.AddItem( new Item("123","pencil",.15,100) );
		po.AddItem( new Item("321","copy paper", 7.50, 25) );
		po.AddItem( new Item("111","white out", 1.35, 10) );

		po.DisplayItems( );
		Console.WriteLine("Serialization in progress");
		//Serialize the Current Purchase Order
		XmlSerializer s = new XmlSerializer( typeof( PurchaseOrder ) );
		TextWriter w = new StreamWriter("po.xml");
		s.Serialize( w, po );
		w.Close();
		Console.WriteLine("Serialization complete\n\n");

		Console.WriteLine("Deserialization in progress");
		//Deserialize to a new PO
		PurchaseOrder po2 = new PurchaseOrder( );
		TextReader r = new StreamReader( "po.xml" );
		po2 = (PurchaseOrder)s.Deserialize( r );
		r.Close( );
		Console.WriteLine("Deserialization complete");
		po2.DisplayItems();
        }
	
}

