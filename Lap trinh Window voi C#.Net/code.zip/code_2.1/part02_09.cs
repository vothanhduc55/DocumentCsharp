//File     :part02_09.cs
//Author   :Richard L. Weeks
//Purpose  :The switch statement


using System;


public class SwitchTest {


    public static void Main( ) {


        Console.WriteLine("Please make your selection");
	Console.WriteLine("1 Hamburger");
	Console.WriteLine("2 Cheese Burger");
	Console.WriteLine("3 Fish");

	int Selection = int.Parse( Console.ReadLine( ) );


	switch( Selection ) {

		case 1:
			Console.WriteLine("Hamburger");
			break;

		case 2:
			Console.WriteLine("Cheese Burger");
			break;

		case 3:
			Console.WriteLine("Fish");
			break;

		default:
			Console.WriteLine("Unknown choice");
	}
    }
}