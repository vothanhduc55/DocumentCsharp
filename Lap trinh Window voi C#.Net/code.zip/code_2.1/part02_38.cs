/////////////////////////////////////////////////
//File    :fsm.cs
//Author  :Richard L. Weeks
//Purpose :Make use of XML Serialization to implement
//         a finite state machine
//
//
//

using System;
using System.Xml;
using System.Xml.Serialization;
using System.IO;


/////////////////////////////
//The FSM class
[XmlRoot("fsm")]
public class FSM {

      //data members
      private int m_StateCount;

      [XmlAttribute("state_count")]
      public int StateCount {
          get { return m_StateCount; }
          set {
		m_StateCount = value;
		States = new State[m_StateCount];
          }
      }

      [XmlElement("state")]
      public State[] States = null;


      public bool ProcessString( string s ) {

		State CurrentState = GetStartState( );
		Console.WriteLine("Start state is {0}",CurrentState.Name);
		//Process the token string
		for( int i = 0; i < s.Length; i++ ) {
		   string next_state = CurrentState.ProcessToken( string.Format("{0}",s[i]) );
		   if( next_state != "" ) 
			CurrentState = GetState( next_state );
		   else {
                        Console.WriteLine("No production from {0} with token {1}", CurrentState.Name, s[i]);
	                return false;
                   }
	           Console.WriteLine("Current State => {0}", CurrentState.Name );
                }
		
		return CurrentState.IsFinal;
      }

      private State GetState( string state_name ) {
		//Locate the state name
		for( int i = 0; i < States.Length; i++ )
			if( States[i].Name == state_name )
				return States[i];
		return null;
      }

      private State GetStartState( ) {
		for( int i = 0; i < States.Length; i++ )
			if( States[i].IsStart )
				return States[i];
		return null;
      }
}

/////////////////////////////
//State class
[XmlRoot("state")]
public class State {

	private string 		m_Name;
	private bool   		m_IsStart;
	private bool   		m_IsFinal;
	private int		m_ProductionCount;
	

	[XmlAttribute("name")]
	public string Name {
		get { return m_Name; }
		set { m_Name = value; }
	}

	[XmlAttribute("is_start")]
	public bool IsStart {
		get { return m_IsStart; }
		set { m_IsStart = value; }
	}

	[XmlAttribute("is_final")]
	public bool IsFinal {
		get { return m_IsFinal; }
		set { m_IsFinal = value; }
	}

	[XmlAttribute("production_count")]
	public int ProductionCount {
		get { return m_ProductionCount; }
		set {
			Productions = new Production[value];
			m_ProductionCount = value;
	        }
	}
	
	[XmlElement("production")]
	public Production[] Productions = null;

	
	public string ProcessToken( string token ) {
		//loop through the productions and return the name of the next state
		for( int i = 0; i < Productions.Length; i++ ) {
			Console.WriteLine("State {0} is evaluating token {1}", m_Name, token );
			Console.WriteLine("Testing Production {0} : {1}", Productions[i].token, Productions[i].state);
			if( Productions[i].token == token )
				return Productions[i].state;
                }
		return "";
	}

}

////////////////////////////
//Production struct
[XmlRoot("production")]
public struct Production {

	[XmlAttribute("token")]
	public string token;

	[XmlAttribute("state")]
	public string state;
}




public class FiniteStateMachine {

	public static void Main( ) {

		//Deserialize the FSM from the xml file
		XmlSerializer s = new XmlSerializer( typeof( FSM ) );
		TextReader tr = new StreamReader( "fsm.xml" );
		FSM fsm = (FSM)s.Deserialize( tr );
		tr.Close( );

		//Get the token string to process
		Console.Write("Enter token string to process: ");
		string tokens = Console.ReadLine( );
		string result = fsm.ProcessString( tokens ) ? "valid" : "invalid";

		Console.WriteLine("The token string {0} is {1}", tokens, result );

	}
}