using System;
using System.Collections;


public class QueueTest {

	public static void Main( ) {

		Queue myQueue = new Queue( );

		//Fill the queue
		for( int i = 0; i < 10; i++ )
			myQueue.Enqueue( i );

		//Empty the queue
		for( int i = 0; i < 10; i++ )
			Console.WriteLine( "{0}", myQueue.Dequeue( ) );


		//Fill the queue again
		for( int i = 0; i < 10; i++ )
			myQueue.Enqueue( i );

		foreach( int i in myQueue )
			Console.WriteLine( "{0}", i );		
	}
}