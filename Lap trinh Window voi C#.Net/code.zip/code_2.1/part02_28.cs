//File		:part02_28.cs
//Purpose	:Demonstrate basic inheritance
//

using System;

public class Dog {

	//Common attributes
	public string Name;
	public int    Weight;


	//Common methods
	public void Speak( ) { Console.WriteLine("ruff!"); }
	public void DrinkWater( ) { Console.WriteLine("Gulp"); }

}


//A specialized version of a Dog
public class GermanShepard : Dog {
	public void OnGuard( ) { Console.WriteLine("In Guard Mode"); }
}


public class JackRussell : Dog {
	public void Chew( ) { Console.WriteLine("I'm chewing your favorite shoes!"); }
}





public class Inherit {

	public static void Main( ) {
		
		GermanShepard Simon = new GermanShepard( );
		JackRussell Daisy   = new JackRussell( );

		//Both Simon and Daisy have a name and weight
		Simon.Name = "Simon"; Simon.Weight = 85;
		Daisy.Name = "Daisy"; Daisy.Weight = 25;

		//Both Simon and Daisy have the speak and DrinkWater methods
		Simon.Speak( ); Simon.DrinkWater( );
		Daisy.Speak( ); Daisy.DrinkWater( );


		//Only Simon has the OnGuard Method
		Simon.OnGuard( );

		//Only Diasy has the Chew method
		Daisy.Chew( );
	}
}

