using System;
using System.Collections;


public class StackTest {


	public static void Main( ) {

		Stack myStack = new Stack( );

		for( int i = 0; i < 10; i++ )
			myStack.Push(i);

		for( int i = 0; i < 10; i++ )
			Console.WriteLine( "{0}", myStack.Pop( ) );


		//Refill the stack and use an enumerator to list the elements
		for( int i = 0; i < 10; i++ )
			myStack.Push(i);

		foreach( int i in myStack )
			Console.WriteLine( "{0}", i );
	}
}		
