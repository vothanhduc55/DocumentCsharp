//File		:part02_30.cs
//Author	:Richard L. Weeks
//Purpose	:Interfaces

using System;

//Define the IAlarm interface
interface IAlarm {
	bool On { get; set; }
	void Snooze( );
}

//Define the IClock interface
interface IClock {
	void SetTime( );
}


//Define the IRadio interface
interface IRadio {
	void SetStation( double station_id );
}



//Create an alarm clock that implements IAlarm, IClock and IRadio
public class AlarmClock : IAlarm, IClock, IRadio {

	//Data members
	private bool	m_bOnOff;


	//The IAlarm interface implementation
	public bool On { get { return m_bOnOff; } set { m_bOnOff = value; } }
	public 	void Snooze( ) { Console.WriteLine("IAlarm.Snooze"); }

	//The IClock Interface
	public 	void SetTime( ) { Console.WriteLine("IClock.SetTime"); }

	//The IRadio interface
	public 	void SetStation( double station_id ) { Console.WriteLine("IRadio.SetStation( {0} )", station_id ); }
}



public class InterfaceTest {
	public static void Main( ) {

		AlarmClock a = new AlarmClock( );

		//Get the IAlarm Interface
		IAlarm ialarm = (IAlarm)a;
		ialarm.On = false;
		ialarm.Snooze( );

		//Get the IClock interface
		IClock iclock = (IClock)a;
		iclock.SetTime( );

		//Get the IRadio interface
		IRadio iradio = (IRadio)a;
		iradio.SetStation( 98.1 );
	}
}


