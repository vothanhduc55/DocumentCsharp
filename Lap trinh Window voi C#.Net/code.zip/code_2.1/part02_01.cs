//File		:part02_01.cs
//Author	:Richard L. Weeks
//Purpose	:Declare a simple struct


struct Fraction {

	public int numerator;
	public int denominator;

}


public class StructTest {

	public static void Main( ) {

		Fraction f;

		f.numerator   = 5;
		f.denominator = 10;

	}
}