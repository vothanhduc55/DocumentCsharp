//File		:part02_31.cs
//Author	:Richard L. Weeks
//Purpose	:Demonstrate the use of delegates


using System;


//Define a person struct
public struct Person {
	public string FName;
	public string LName;
}	



//Define a delegate
public delegate void OnNewHire( Person person );



//The HR Class
public class HR {

	//Implement the delegate to be called when a new person is hired
	public void OnNewHire( Person person ) {
		Console.WriteLine("HR is in the process of putting {0} to sleep", person.FName );
	}
}



//Create a department
public class Department {


	//Who to notify
	private OnNewHire	m_OnNewHireDelegate = null;


	//set the OnNewHire delegate
	public void AddOnNewHireDelegate( OnNewHire onh ) {
		m_OnNewHireDelegate = onh;
	}

	
	public void HirePerson( Person p ) {
		//do we need to notify someone?
		if( m_OnNewHireDelegate != null )
			m_OnNewHireDelegate( p );
	}
}




public class DelegateTest {

	public static void Main( ) {

		HR hr = new HR( );
		Department dept = new Department( );

		//Register the OnNewHire Delegate
		dept.AddOnNewHireDelegate( new OnNewHire( hr.OnNewHire ) );

		//Create a person
		Person me; me.FName = "Richard"; me.LName = "Weeks";

		//Hire ME!!!
		dept.HirePerson( me );
	}
}