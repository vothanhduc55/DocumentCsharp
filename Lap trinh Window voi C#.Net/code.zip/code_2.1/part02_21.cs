using System;


public struct Simple {

	public  int i;
	private string s;

	public void init( ) {
		i = 10;
		s = "Hello";
	}

	public void show( ) {

		Console.WriteLine("i = {0}", i);
		Console.WriteLine("s = {0}", s);
	}
	
}



public class T {

	public static void Main( ) {

		Simple simple = new Simple( );
	
		simple.init( );
		
	}
}

