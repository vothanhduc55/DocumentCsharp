//File      :part02_07.cs
//Date      :12.29.2000
//Author    :Richard L. Weeks
//Purpose   :C# if statement usage


using System;



public class Statements {


	public static void Main( ) {

		bool bSimple_1 = true;
		bool bSimple_2 = false;


		if( bSimple_1 ) 
			Console.WriteLine("You should see this");

		if( bSimple_2 )
			Console.WriteLine("You should not see this");

		//Complex
		if( bSimple_1 && !bSimple_2 )
			Console.WriteLine("Will you see this?");


		//Multi-statements
		if( bSimple_1 ) {
			Console.WriteLine("Statement 1");
			Console.WriteLine("Statement 2");	
		}
	}
}

