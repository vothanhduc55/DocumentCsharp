//File    :part02_17.cs
//Author  :Richard L. Weeks
//Purpose :Demonstrate C# arrays

using System;

public class ArrayTest {

    public static void Main( ) {

       //Declare a single dim array of int's
       int[] array_1 = new int[5];
      
       //Fill the array
       for( int i = array_1.GetLowerBound(0); i <= array_1.GetUpperBound(0); i++)
          array_1[i] = i+1;

       //Display the contents of the array
       for( int j = array_1.GetLowerBound(0); j <= array_1.GetUpperBound(0); j++)
          Console.WriteLine("array_1[{0}] = {1}", j, array_1[j]);

       Console.WriteLine("\n****** Phase II ******\n");

       //Declare an array and initialize the values
       int[] array_2 = new int[] { 25, 10, 4, 7, 15, 2, 1 };

       //Sort the array
       System.Array.Sort( array_2 );

       //Display the sorted values
       for( int k = array_2.GetLowerBound(0); k <= array_2.GetUpperBound(0); k++)
          Console.WriteLine("array_2[{0}] = {1}", k, array_2[k] );
      
      
    }
}