using System;


public class Dog {

   private string Name;


   //Constructor
   public Dog( string name ) {
	Name = name;
   }


   public void Speak( ) {
       Console.WriteLine( "Hello. My name is {0}", Name );
   }
}



public class Simple {


    public static void Main( ) {


		Dog spot = new Dog( "spot" );


		spot.Speak( );
    }
}