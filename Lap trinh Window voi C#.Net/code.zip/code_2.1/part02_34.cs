using System;
using System.Collections;



struct Person {
	public Person( string f, string l ) { FName = f; LName = l; }
	public string LName;
	public string FName;
}


public class HashtableTest {


	public static void Main( ) {

		Hashtable People = new Hashtable( );

		//Add some people
		People.Add( "Smith", new Person( "Jim", "Smith" ) );
		People.Add( "Jones", new Person( "Dawn", "Jones" ) );
		People.Add( "Powell", new Person( "Bob", "Powell" ) );

		//Locate Jim Smith
		Person p = (Person)People["Smith"];
		Console.WriteLine("{0} {1}", p.FName, p.LName );

	
	}
}
	