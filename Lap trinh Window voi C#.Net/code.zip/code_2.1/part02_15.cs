//File   :part02_15.cs
//Author :Richard L. Weeks
//Purpose:Using the foreach statement


using System;



public class ArrayListing {

    public static void Main( ) {

       int[] whole_numbers = {1,2,3,4,5,6,7,8,9,10};


       //Display each element in the whole_numbers array
       foreach( int value in whole_numbers )
          Console.WriteLine( "value = {0}", value );
    }
}