//File		:part02_36.cs
//Author	:Richard L. weeks
//Purpose	:The Conditional attribute
//
//Compile instructions:
// csc /define:DEBUG part02_36.cs
// csc part02_36.cs

using System;
using System.Diagnostics;	//The ConditionalAttribute lives here

public class Foo {

	[Conditional("DEBUG")]
	public void OnlyWhenDebugIsDefined( ) {
		Console.WriteLine("DEBUG is defined");
	}
}



public class AttributeTest {

	public static void Main( ) {

		Foo f = new Foo( );
		f.OnlyWhenDebugIsDefined( );
	}
}