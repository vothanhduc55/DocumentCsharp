//File		:part02_03.cs
//Author	:Richard L. Weeks
//Purpose	:Reference Types

using System;

//A class represents a reference type in C#
class Fraction {

	public int numerator;
	public int denominator;

	public void Print( ) {
		Console.WriteLine( "{0}/{1}", numerator, denominator );
	}

}


public class ReferenceTest {

	public static void Main( ) {

		Fraction f = new Fraction( );
		f.numerator   = 5;
		f.denominator = 10;
		f.Print( );

		
		Fraction f2 = f;	//f2 is a reference to f and not a copy!!!
		f.Print( );

		//modify instance f2. Note that f is also effected.
		f2.numerator = 1;

		f.Print( );
		f2.Print( );


	}
}