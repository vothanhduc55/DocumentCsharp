//File		:part02_16.cs
//Author	:Richard L. Weeks
//Purpose	:Demonstrate the 'is' operator


using System;

//Create two empty classes.  We only need their declaration for
//the purpose of demonstrating the is keyword

class Dog {
}

class Cat {
}



public class IsDemo {


	public static void Main( ) {


		Dog myDog = new Dog( );
		Cat myCat = new Cat( );
		int i = 10;

		WhatIsIt(myDog);
		WhatIsIt(myCat);
		WhatIsIt(i);
	}


	public static void WhatIsIt( object o ) {

		if( o is Dog )
			Console.WriteLine("It is a dog");
		else if( o is Cat )
			Console.WriteLine("It is a cat");
		else
			Console.WriteLine("I don't know what it is");
	}
}
			