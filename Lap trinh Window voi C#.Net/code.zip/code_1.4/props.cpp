#using <mscorlib.dll>

using namespace System;
using namespace System::IO;


__gc class PropClass
{
	int m_x;
	int m_y;
	int m_z;

public:
	PropClass() : m_y(19762), m_z(3860) 
	{
	}

	// read / write properties for a data member

	__property int get_x(){return m_x;}
	__property void set_x(int v){m_x=v;}
	
	// read only properties for a data member

	__property int get_y(){return m_y;}

	// write only properties for a data member

	__property void set_z(int v){m_z=v;}

	// properties that don't act on data at-all

	__property int get_bogus()
	{
		Console::WriteLine("Read the bogus property!");
		return 10;
	}
	__property void set_bogus(int v)
	{
		Console::WriteLine("Wrote {0} to the bogus property!",__box(v));
	}

	String* ToString()
	{
		StringWriter *w=new StringWriter();
		w->Write("PropClass; m_x = {0}, m_y = {1}, m_z = {2}",__box(m_x), __box(m_y), __box(m_z));
		return w->ToString();
	}
	
};

void main()
{
	PropClass *pP=new PropClass();

	Console::WriteLine("At Creation...{0}",pP);

	pP->x=50;

	Console::WriteLine("Wrote to x...{0}",pP);

	pP->z=100;

	Console::WriteLine("Wrote to z...{0}",pP);

	pP->bogus = 150;

	Console::WriteLine(pP);

	int x=pP->x;

	Console::WriteLine("Read x, Return ={0}, {1}",__box(x),pP);

	int y=pP->y;

	Console::WriteLine("Read y. Return ={0}, {1}",__box(y),pP);

	int z=pP->bogus;

	Console::WriteLine("Returned value = {0},  {1}",__box(z),pP);

}