#using <mscorlib.dll>
using namespace System;

__gc __interface IDoSomething
{
	String * SayHello();
};


__gc class CDoSomething : public IDoSomething
{
	String * IDoSomething :: SayHello()
	{
		return new String("Hello");
	}
};

void main()
{
	CDoSomething* pD=new CDoSomething();

	IDoSomething *pI=static_cast<IDoSomething*>(pD);

	String* s=pI->SayHello();
	Console::WriteLine(s);	
}