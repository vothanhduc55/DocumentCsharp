#using <mscorlib.dll>
using namespace System;

#include <stdio.h>


// first declare the delegate signatures.

__delegate void MyDelegate(int n);

__delegate(multicast) void MyMCDelegate();

__gc class AClass
{
public:
	static void StaticHandler(int n)
	{
		printf("I am a static handler and my parameter is %d\n",n);
	}

	void InstanceHandler(int n)
	{
		printf("I am an instance handler and my parameter is %d\n",n);
	}

	void MCHandlerA()
	{
		printf("I am multi-cast handler (a)\n");
	}		

	void MCHandlerB()
	{
		printf("I am multi-cast handler (b)\n");
	}		

	void MCHandlerC()
	{
		printf("I am multi-cast handler (c)\n");
	}		

	void MCHandlerD()
	{
		printf("I am multi-cast handler (d)\n");
	}		

};


void main()
{
	// instantiate the handler class..
	AClass* pC=new AClass();
	
	// Create the delgates
	MyDelegate* sh=new MyDelegate(pC,&AClass::StaticHandler);
	MyDelegate* ih=new MyDelegate(pC,&AClass::InstanceHandler);

	//Invoke the static...
	sh->Invoke(10);
	//and the instance handlers.
	ih->Invoke(100);

	//Now a multicast
		
	MyMCDelegate* mc=new MyMCDelegate(pC,AClass::MCHandlerA);
	mc=static_cast<MyMCDelegate*>(Delegate::Combine(mc,new MyMCDelegate(pC,&AClass::MCHandlerB)));
	mc=static_cast<MyMCDelegate*>(Delegate::Combine(mc,new MyMCDelegate(pC,&AClass::MCHandlerC)));
	mc=static_cast<MyMCDelegate*>(Delegate::Combine(mc,new MyMCDelegate(pC,&AClass::MCHandlerD)));

	mc->Invoke();
}