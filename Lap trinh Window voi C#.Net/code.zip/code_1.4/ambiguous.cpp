#using <mscorlib.dll>

using namespace System;


__gc __interface IFirst
{
	void TheMethod();
};

__gc __interface ISecond
{
	void TheMethod();
};

__gc class AClass : public IFirst, public ISecond
{
	void IFirst::TheMethod()
	{
		Console::WriteLine("Invoked IFirst::TheMethod");
	}

	void ISecond::TheMethod()
	{
		Console::WriteLine("Invoked ISecond::TheMethod");
	}
};



void main()
{
	AClass* c=new AClass();


	IFirst *pF=static_cast<IFirst*>(c);

	ISecond *pS=static_cast<ISecond*>(c);

	pF->TheMethod();

	pS->TheMethod();
}