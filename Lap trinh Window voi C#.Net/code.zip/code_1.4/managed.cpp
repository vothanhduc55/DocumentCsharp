#using <mscorlib.dll> // import the library
using namespace System;

__gc class MCPPDemo
{
public:

    void SayHello()
    {
        Console::WriteLine("Hello Managed C++");
    }

};

void main()
{
    MCPPDemo *pD=new MCPPDemo;

    pD->SayHello();
}
