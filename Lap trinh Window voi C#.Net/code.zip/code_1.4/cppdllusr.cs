using System;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;

using cppdll;

class dlltester
{

	[DllImport("straightdll.dll")]
	[MarshalAs(UnmanagedType.LPStr)]
	public static extern String DllFunction(int n);

	static void Main()
	{
		
		// First the method in the C++ dll "cppdll.dll" is invoked...
		AClass pC=new AClass();
		pC.FirstMethod(10);
		
		
		Console.WriteLine(DllFunction(10));
		
	}
}