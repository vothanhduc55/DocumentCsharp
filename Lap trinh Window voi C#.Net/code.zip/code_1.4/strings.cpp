#using <mscorlib.dll>
using namespace System;
void stringcompare(String *a, String *b)
{ 
Console::WriteLine("a=\"{0}\" b=\"{1}\" same string? {2}\n",a,b,a==b ? S"true":S"false");	
}
void main()
{
	String* a=S"Hello";
	String* b=S"Hello";
	StringCompare(a,b);
	a=a->Concat(a,S" World");
	StringCompare(a,b);
	a=a->Remove(5,6);
	sStringCompare(a,b);
}
