#using <mscorlib.dll>
using namespace System;

__value struct ManagedStruct
{
	int p;
	int q;
};

#pragma unmanaged

void timestwo(int* pToMultiply)
{
	*pToMultiply *= 2;
}

#pragma managed


void main()
{
	ManagedStruct* pStruct=new ManagedStruct;
	pStruct->p=1;
	pStruct->q=2;

	int __pin* pinnedp=&pStruct->p;
	int __pin* pinnedq=&pStruct->q; 

	timestwo(pinnedp);
	timestwo(pinnedq);

	Console::WriteLine("p={0}, q={1}",__box(pStruct->p), __box(pStruct->q));

}