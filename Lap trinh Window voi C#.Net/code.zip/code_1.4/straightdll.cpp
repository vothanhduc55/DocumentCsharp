// This is a straight C++ DLL that will be called using the p-invoke
// system interop services from .NET


#include <windows.h>
#include <stdio.h>
#include <string.h>

static char *buffer;



char* __stdcall DllFunction(int n)
{
	sprintf(buffer,"Hi From DllFunction! ");
	for(int x=n;x>=0;x--)
	{
		char temp[100];
		sprintf(temp,"%d%s",x,(x==0 ? "..." : ", "));
		strcat(buffer,temp);
	}	
	return &buffer[0];	
}

BOOL __stdcall DllMain(HINSTANCE hInst, DWORD dwReason, LPVOID resvd)
{
	switch(dwReason)
	{
		case DLL_PROCESS_ATTACH:
			buffer = (char *)malloc(1000);
			memset(buffer,0,1000);
			printf("Straightdll loaded\n");
			return TRUE;
		case DLL_PROCESS_DETACH:
			free(buffer);
			printf("Straightdll unloaded\n");
			return TRUE;
		default:
			return FALSE;
	}
}