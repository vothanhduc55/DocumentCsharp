#using <mscorlib.dll>
#using <mydll.dll>

using namespace System;
using namespace mydll;

void main(void)
{
	myclass *pM=new myclass();

	pM->MyMethod();
}