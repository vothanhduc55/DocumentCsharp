#using <mscorlib.dll>

using namespace System;
using namespace System::Text;
using namespace System::IO;

// This is a managed C++ DLL that uses .Net framework classes
// compile with...
// cl /CLR /LD cppdll.cpp

namespace cppdll {

//Demonstrates calling a class method....
public __gc class AClass
{
public:
	void FirstMethod(int n)
	{
		String* pS=S"Hi from Firstmethod  ";

		StringBuilder* pB=new StringBuilder(pS);

		StringWriter* pW=new StringWriter(pB);

		for(int x=n;x>=0;x--)
		{
			pW->Write(__box(x));
			if(x)
				pW->Write(S", ");
			else
				pW->Write(S"...");
		}
		pS=pW->ToString();
		Console::WriteLine(pS);	
	}	
};

}