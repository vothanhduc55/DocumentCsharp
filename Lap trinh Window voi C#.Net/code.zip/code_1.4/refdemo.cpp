#using <mscorlib.dll>
using namespace System;
using namespace System::Collections;

__value struct simple
{
	int i;
	float f;
};

__gc class refdemo
{
	ArrayList* l;

public:
	
	refdemo(){l=new ArrayList;}

	void Add(Object* o)
	{
		l->Add(o);
	}

	void create(int n,Object **pO)
	{
		simple s;
		s.i=n;
		s.f=n*3.1415926;
		*pO =__box(s);
	}

	void init()
	{
		for(int x=0;x<10;x++)
		{
			Object *pO;
			create(x,&pO);
			Add(pO);
		}
	}

	void show()
	{
		for(int x=0; x<l->get_Count(); x++)
		{
			try
			{
				simple* pS=__try_cast<simple*>(l->get_Item(x));
				Console::WriteLine("{0} * PI = {1}",__box(pS->i), __box(pS->f));
			}
			catch(System::InvalidCastException *)
			{
				Console::WriteLine("Bad __try_cast...");
			}
		} 
	}

};

void main()
{
	refdemo *pD=new refdemo;
	pD->init(); // create the list of values
	pD->show(); // iterate the list and display the contents.
}
