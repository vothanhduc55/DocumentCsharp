using System;

namespace mydll {

public class myclass
{
	public void MyMethod()
	{
		Console.WriteLine("MyMethod invoked!!!");
	}
}


}