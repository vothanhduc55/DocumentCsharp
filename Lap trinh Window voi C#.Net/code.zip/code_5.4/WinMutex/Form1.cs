using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;

namespace WinMutex
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		
		private System.ComponentModel.IContainer components;

		private Mutex m = new Mutex( false, "WinMutex" );
		private bool bHaveMutex = false;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			Thread T = new Thread( new ThreadStart( ThreadProc ) );
			T.Start( );
			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		public override void Dispose()
		{
			if (components != null) 
			{
				components.Dispose();
			}
			base.Dispose();
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Name = "MainForm";
			this.Text = "WinMutex";

		}
		#endregion

		protected override void OnPaint( PaintEventArgs e ) {
			
			if( this.bHaveMutex )
				DrawCircle( System.Drawing.Color.Green );
			else
				DrawCircle( System.Drawing.Color.Red );
		}

		protected void DrawCircle( System.Drawing.Color color ) {
			Brush b = new SolidBrush( color );
			
			
			System.Drawing.Graphics g = this.CreateGraphics( );
			int x = this.Size.Width / 2;
			int y = this.Size.Height / 2;
			
			g.FillEllipse( b, 0, 0, this.ClientSize.Width, this.ClientSize.Height );

			b.Dispose( );
			g.Dispose( );
			
		}


		protected void ThreadProc( ) {

			while( true ) {
				m.WaitOne( );
				bHaveMutex = true;
				Invalidate( );
				Update( );
				Thread.Sleep( 1000 );
				m.ReleaseMutex( );
				bHaveMutex = false;
				Invalidate( );
				Update( );
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		
	}
}
