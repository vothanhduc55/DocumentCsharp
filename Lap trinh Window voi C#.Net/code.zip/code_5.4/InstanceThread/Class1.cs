using System;
using System.Threading;

namespace InstanceThread
{
	class Bank
	{

		private string bankName = "First Bank";

		public void WorkerThread( ) 
		{
			//Access instance member bankName
			Console.WriteLine("Bank Name = {0}", this.bankName );
		}

		public void Run( ) 
		{
			Thread WT = new Thread( new ThreadStart( this.WorkerThread ) );
			WT.Start( );
		}


		static void Main(string[] args)
		{
			Bank b = new Bank( );
			b.Run( );
		}
	}
}
