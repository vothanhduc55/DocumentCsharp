using System;
using System.Threading;

namespace BasicWorkerThread
{
	
	class Class1
	{

		static void WorkerThread( ) 
		{
			Console.WriteLine("Hello from WorkerThread");
		}

		static void Main(string[] args)	{

			//Create the Worker Thread
			System.Threading.Thread WT = new Thread( new ThreadStart( WorkerThread ) );

			//Start the Thread
			WT.Start( );

			//end the application
			Console.WriteLine("Press enter to exit");
			Console.ReadLine( );
		}
	}
}
