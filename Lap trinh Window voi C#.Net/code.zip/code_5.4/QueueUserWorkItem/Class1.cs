using System;
using System.Threading;


//The InsClaim represents
//a work item for a particular
//thread
public struct InsClaim {
	public string ClaimId;
	public double Amount;
}


public class App {

	public void ProcessInsuranceClaim( object state ) {
		//unbox the InsClaim passed in
		InsClaim theClaim = (InsClaim)state;

		//Process the claim and sleep to simulate work
		Console.WriteLine("Processing Claim {0} for ${1} amount", theClaim.ClaimId, theClaim.Amount );
		Thread.Sleep( 5000 );
		Console.WriteLine("Claim {0} processed", theClaim.ClaimId);
	}


	public static void Main( ) {
		App app = new App( );
	
		//Create 100 insurance claims
		Random r = new Random( );
		for( int i = 0; i < 100; i++ ) {
			InsClaim claim;
			claim.ClaimId = string.Format("INS{0}", i);
			claim.Amount = r.NextDouble( ) * 5000;
			ThreadPool.QueueUserWorkItem( new WaitCallback( app.ProcessInsuranceClaim ), claim );
			System.Threading.ThreadStart
		}
			
		//allow threads in pool to run
		Console.ReadLine( );
	}
}
