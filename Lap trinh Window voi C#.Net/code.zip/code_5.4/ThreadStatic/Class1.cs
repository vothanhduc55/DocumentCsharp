using System;
using System.Threading;



public class Task {
 
	[ThreadStatic] static int m_nId = 10;

	public string	m_strThreadName;
	
	public void Run( string ThreadName ) {
		this.m_strThreadName = ThreadName;
		Thread T = new Thread( new ThreadStart( threadProc ) );
		T.Start( );
	}

	public void threadProc( ) {

		Console.WriteLine( "Thread {0} is running", m_strThreadName );

		//loop and increment the m_nId static field
		for(int i = 0; i < 10; i++ )
			Console.WriteLine("Thread {0} : m_nId = {1}", this.m_strThreadName, m_nId++ );
	}
}


public class ThreadApp {

	public static void Main( ) {

		//Create 2 worker Tasks
		Task t1 = new Task( );
		Task t2 = new Task( );

		t1.Run( "Worker 1" );
		t2.Run( "Worker 2" );
		
		//Execute on the Main thread
		Task t3 = new Task( );
		t3.m_strThreadName = "Main Thread";
		t3.threadProc( );
	}
}