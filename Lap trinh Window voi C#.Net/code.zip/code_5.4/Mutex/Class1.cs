using System;
using System.Threading;



class Application {


	public static void Main( string[] args ) {

		string mutexName = args[0];

		Mutex m = new Mutex( false, mutexName );

		//Acquire the Mutex
		for( ;; ) {
			m.WaitOne( );
			Console.WriteLine("Have Mutex. Press Enter to release");
			Console.ReadLine( );
			Console.WriteLine("Releasing");
			m.ReleaseMutex( );
		}
	}
}
		
