using System;
using System.Threading;



public class JoinTest {


	public static void ThreadProc( ) {

		Console.WriteLine("Thread Active");

		Thread.Sleep( 30 * 1000 );

		Console.WriteLine("Thread Exiting");
	}


	public static void Main() {
		Thread T = new Thread( new ThreadStart( ThreadProc ) );
		T.Start( );
		T.Join( );
		Console.WriteLine("After Join");
	}
}