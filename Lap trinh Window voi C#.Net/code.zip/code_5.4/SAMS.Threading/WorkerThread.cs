using System;
using System.Threading;

namespace SAMS.Threading
{


	/// <summary>
	/// Encapsulate a worker thread and data
	/// </summary>
	public abstract class WorkerThread {

		private object	ThreadData;
		private Thread	thisThread;


		//Properties
		public object Data {
			get { return ThreadData; }
			set { ThreadData = value; }
		}

		public object IsAlive {
			get { return thisThread == null ? false : thisThread.IsAlive; }
		}

		/// <summary>
		/// Constructors
		/// </summary>

		public WorkerThread( object data ) {
			this.ThreadData = data;
		}

		public WorkerThread( ) {
			ThreadData = null;
		}

		/// <summary>
		/// Public Methods
		/// </summary>
		
		/// <summary>
		/// Start the worker thread
		/// </summary>
		public void Start( ) {
			thisThread = new Thread( new ThreadStart( this.Run ) );
			thisThread.Start();
		}

		/// <summary>
		/// Stop the current thread.  Abort causes
		/// a ThreadAbortException to be raised within
		/// the thread
		/// </summary>
		public void Stop( ) {
			thisThread.Abort( );
			while( thisThread.IsAlive ) ;
			thisThread = null;
		}

		/// <summary>
		/// To be implemented by derived threads
		/// </summary>
		protected abstract void Run( );
	}
}
