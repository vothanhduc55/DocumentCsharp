using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;


namespace Sams {


class ColorStretcher : System.Windows.Forms.Form
{

	void OnFull(Object sender, EventArgs e)
	{
		ColorDialog dlg=new ColorDialog();
		dlg.FullOpen = true;

		dlg.ShowDialog();
	}

	void OnNoCustom(Object sender, EventArgs e)
	{
		ColorDialog dlg=new ColorDialog();
		dlg.AllowFullOpen = false;

		dlg.ShowDialog();
	}

	void OnNormal(Object sender, EventArgs e)
	{
		ColorDialog dlg=new ColorDialog();
        dlg.Color = Color.PaleGoldenrod;
		dlg.ShowDialog();
	}

	void OnWithColours(Object sender, EventArgs e)
	{
		ColorDialog dlg=new ColorDialog();
		dlg.FullOpen = true;
		// this statement defines the first five of the
		// custom color settings as ints the data is 
		// 0xAARRGGBB where AA is alpha, RR is red, 
		// GG is green and BB is blue expressed as the 
		// hexadecimal byte equivalent
		dlg.CustomColors = new int[5]{0x00ff8040, 0x00c256fe,
						   0x00aa2005, 0x0004f002, 0x002194b5};

		dlg.ShowDialog();
	}

	ColorStretcher()
	{
		// first a menu for the choices

		MainMenu m=new MainMenu();
		MenuItem top,temp;

		top=new MenuItem("ColorDialog");
		m.MenuItems.Add(top);

		temp=new MenuItem("Full");
		temp.Click+=new EventHandler(OnFull);
		top.MenuItems.Add(temp);

		temp=new MenuItem("No custom");
		temp.Click+=new EventHandler(OnNoCustom);
		top.MenuItems.Add(temp);

		temp=new MenuItem("With Colours");
		temp.Click+=new EventHandler(OnWithColours);
		top.MenuItems.Add(temp);

		temp=new MenuItem("Normal");
		temp.Click+=new EventHandler(OnNormal);
		top.MenuItems.Add(temp);

		this.Menu = m;

	}

	public static void Main()
	{
		Application.Run(new ColorStretcher());
	}
		
}


}