namespace Sams
{
    using System;
    using System.Drawing;
	using System.Drawing.Printing;
    using System.Collections;
    using System.ComponentModel;
    using System.Windows.Forms;


    /// <summary>
    ///    the ppView is a simple control window that uses a common draw
    ///    method for both painting on screen and printing or print preview
    /// </summary>
    public class ppView : System.Windows.Forms.Panel
	{
		private ArrayList points;

		Point mousePoint;


		void OnClick(Object sender, MouseEventArgs e)
		{
			if(points == null)
			{
				points=new ArrayList();
			}

			points.Add(mousePoint);
			Invalidate();
		}

		void OnMouseMove(Object sender,MouseEventArgs e)
		{
			mousePoint = new Point(e.X,e.Y);
		}
		
		public ppView()
        {
			this.MouseDown+=new MouseEventHandler(OnClick);
			this.MouseMove+=new MouseEventHandler(OnMouseMove);
			this.BackColor=Color.White;
        }

		private void DrawSmiley(Point pt, Graphics g)
		{
			g.FillEllipse(Brushes.Black,pt.X-52,pt.Y-52,104,104);
			g.FillEllipse(Brushes.Yellow,pt.X-50,pt.Y-50,100,100);
			g.FillEllipse(Brushes.Black,pt.X-30,pt.Y-10,60,40);
			g.FillEllipse(Brushes.Yellow,pt.X-35,pt.Y-10,70,35);
			g.FillEllipse(Brushes.Black,pt.X-25,pt.Y-15,10,10);
			g.FillEllipse(Brushes.Black,pt.X+10,pt.Y-15,10,10);
		}

		private void DoDraw(Graphics g)
		{
			if(points == null)
			{
				return;
			}
			foreach(Point p in points)
			{
				DrawSmiley(p,g);
			}
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			if(points == null)
			{
				return;
			}
			DoDraw(e.Graphics);
		}

		public void OnPrintPage(Object sender,PrintPageEventArgs e)
		{
			if(points == null)
			{
				return;
			}
			DoDraw(e.Graphics);
		}
    }


    /// <summary>
    ///    This is the application that hosts the MainApps.
    /// </summary>
    public class MDIChildForm : System.Windows.Forms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private ppView vw;

		// Accessor for private data
		public ppView View {
			get
			{
				return vw;
			}
		}

		public MDIChildForm()
        {


            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

			vw=new ppView();
			vw.Location = new Point(3,3);
			vw.Size = new Size(this.Size.Width-6,this.Size.Height-6);
			vw.Anchor=AnchorStyles.Left|
				      AnchorStyles.Top|
				      AnchorStyles.Right|
				      AnchorStyles.Bottom;

			this.Controls.Add(vw);

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.Text = "MDIChildForm";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.ClientSize = new System.Drawing.Size (328, 277);
		}
    }

    /// <summary>
    ///    Summary description for MainApp.
    /// </summary>
    public class MainApp : System.Windows.Forms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.Windows.Forms.MenuItem FileExit;
		private System.Windows.Forms.MenuItem FilePrintPreview;
		private System.Windows.Forms.MenuItem FilePrint;
		private System.Windows.Forms.MenuItem FileNew;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MainMenu mainMenu1;

        public MainApp()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.mainMenu1 = new System.Windows.Forms.MainMenu ();
			this.FilePrintPreview = new System.Windows.Forms.MenuItem ();
			this.FileExit = new System.Windows.Forms.MenuItem ();
			this.menuItem1 = new System.Windows.Forms.MenuItem ();
			this.FileNew = new System.Windows.Forms.MenuItem ();
			this.FilePrint = new System.Windows.Forms.MenuItem ();
			mainMenu1.MenuItems.AddRange(
				new System.Windows.Forms.MenuItem[1] {this.menuItem1});
			FilePrintPreview.Text = "P&review...";
			FilePrintPreview.Index = 2;
			FilePrintPreview.Click += 
				new System.EventHandler (this.FilePrintPreview_Click);
			FileExit.Text = "&Exit";
			FileExit.Index = 3;
			FileExit.Click += new System.EventHandler (this.FileExit_Click);
			menuItem1.Text = "&File";
			menuItem1.Index = 0;
			menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[4]
                {this.FileNew, 
				 this.FilePrint, 
				 this.FilePrintPreview, 
				 this.FileExit});
			FileNew.Text = "&New";
			FileNew.Index = 0;
			FileNew.Click += new System.EventHandler (this.FileNew_Click);
			FilePrint.Text = "&Print...";
			FilePrint.Index = 1;
			FilePrint.Click += new System.EventHandler (this.FilePrint_Click);
			this.Text = "MainApp";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.IsMdiContainer = true;
			this.Menu = this.mainMenu1;
			this.ClientSize = new System.Drawing.Size (368, 289);
		}

		protected void FileExit_Click (object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		protected void FilePrintPreview_Click(object sender,System.EventArgs e)
		{
			PrintPreviewDialog d=new PrintPreviewDialog();
			PrintDocument doc = new PrintDocument();

			MDIChildForm f = (MDIChildForm)this.ActiveMdiChild;
			ppView vw = f.View;
			doc.PrintPage += new PrintPageEventHandler(vw.OnPrintPage);

			d.Document=doc;

			d.ShowDialog();

			doc.PrintPage -= new PrintPageEventHandler(vw.OnPrintPage);
		}

		protected void FilePrint_Click (object sender, System.EventArgs e)
		{
			PrintDialog dlg = new PrintDialog();
			PrintDocument doc = new PrintDocument();

			MDIChildForm f = (MDIChildForm)this.ActiveMdiChild;
			ppView vw = f.View;
			doc.PrintPage += new PrintPageEventHandler(vw.OnPrintPage);

			dlg.Document=doc;

			dlg.ShowDialog();

			doc.PrintPage -= new PrintPageEventHandler(vw.OnPrintPage);

		}

		protected void FileNew_Click (object sender, System.EventArgs e)
		{
			MDIChildForm f = new MDIChildForm();
			f.MdiParent=this;
			f.Show();
		}

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args) 
        {
            Application.Run(new MainApp());
        }
    }
}
