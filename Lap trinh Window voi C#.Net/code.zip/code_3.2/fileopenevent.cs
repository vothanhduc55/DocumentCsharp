using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;


namespace Sams
{

class fileopenapp : System.Windows.Forms.Form
{

	MainMenu m_menu;
	MenuItem m_filemenu;

	OpenFileDialog openfiledlg1;

	void OnOpenFile(Object sender, EventArgs e)
	{
		openfiledlg1.Filter = "C# files (*.cs)|"+
			"*.cs|Bitmap files (*.bmp)|*.bmp";
		openfiledlg1.FilterIndex = 1;
		openfiledlg1.ShowDialog();
	}

	void OnExit(Object sender, EventArgs e)
	{
		Dispose();
	}

	fileopenapp()
	{
		m_menu = new MainMenu();
		m_filemenu=new MenuItem("&File");
		m_menu.MenuItems.Add(m_filemenu);
		MenuItem t;

		t=new MenuItem("&Open");
		t.Click += new EventHandler(OnOpenFile);
		m_filemenu.MenuItems.Add(t);

		t=new MenuItem("-");
		m_filemenu.MenuItems.Add(t);

		t=new MenuItem("E&xit");
		t.Click += new EventHandler(OnExit);
		m_filemenu.MenuItems.Add(t);	

		this.Menu = m_menu;	

		openfiledlg1 = new OpenFileDialog();
		openfiledlg1.FileOk += new CancelEventHandler(OnFileOpenOK);
	}

	void OnFileOpenOK(Object sender, CancelEventArgs e)
	{
		//MessageBox.Show("You selected the file "+openfiledlg1.FileName);
		// remember to add "using System.IO;" to the top of this file.
		OpenFileDialog dlg = (OpenFileDialog)sender;

		Stream FileStream;
		if((FileStream = dlg.OpenFile())!=null)
		{
			//perform the read from FileStream here...
			FileStream.Close(); //and tidy up...
		}
	}

	public static void Main()
	{
		Application.Run(new fileopenapp());
	}
}

}// end of Sams namespace