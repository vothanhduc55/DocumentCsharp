using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;

namespace Sams {

class SimpleDialog : Form
{
	public SimpleDialog()
	{
		// Create two buttons.
		Button OkButton=new Button();
		OkButton.Text = "Ok";
		OkButton.DialogResult = DialogResult.OK;
		OkButton.Location = new Point(8,20);
		OkButton.Size = new Size(50,24);
		this.Controls.Add(OkButton);

		Button CancelButton=new Button();
		CancelButton.Text = "Cancel";
		CancelButton.DialogResult = DialogResult.Cancel;
		CancelButton.Location = new Point(64,20);
		CancelButton.Size = new Size(50,24);
		this.Controls.Add(CancelButton);

		this.Text="Dialog";
		this.Size = new Size(130,90);
		this.FormBorderStyle = FormBorderStyle.FixedDialog;
		this.StartPosition = FormStartPosition.CenterParent;
		this.ControlBox = false;
	}
}


class AnApp : Form
{
	void OnTest(Object sender, EventArgs e)
	{
		SimpleDialog dlg = new SimpleDialog();
		dlg.Owner = this;

		if(dlg.ShowDialog() == DialogResult.OK)
			MessageBox.Show("You clicked Ok");
		else
			MessageBox.Show("You clicked Cancel");

	}

	public AnApp()
	{
		this.Menu = new MainMenu();
		this.Menu.MenuItems.Add(new MenuItem("Dialog"));
		this.Menu.MenuItems[0].MenuItems.Add(new MenuItem("Test"));
		this.Menu.MenuItems[0].MenuItems[0].Click += new EventHandler(OnTest);
	}

	static void Main()
	{
		Application.Run(new AnApp());
	}
}


}
