using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Collections;

class ADialog : Form
{

	private Button ok,can;

	public bool Modeless
	{
		set 
		{ 
			if(value)
			{
				ok.Click += new EventHandler(OnCloseModeless);
				can.Click += new EventHandler(OnCloseModeless);
			}
		}
	}

	void OnCloseModeless(Object sender, EventArgs e)
	{
		this.Close();
	}

	public ADialog()
	{
		this.Location = new Point(100,100);
		this.Size=new Size(200,100);
		this.FormBorderStyle = FormBorderStyle.FixedDialog;		

		ok = new Button();
		ok.Text = "OK";
		ok.DialogResult = DialogResult.OK;
		ok.Location = new Point(20,10);
		ok.Size = new Size(80,25);
		this.Controls.Add(ok);

		can = new Button();
		can.Text = "Cancel";
		can.DialogResult = DialogResult.OK;
		can.Location = new Point(110,10);
		can.Size = new Size(80,25);
		this.Controls.Add(can);
	}
}


class AnApp : Form
{
	void OnModeless(Object sender, EventArgs e)
	{
		ADialog dlg = new ADialog();
		dlg.Text = "Modeless";
		dlg.Modeless = true;
		dlg.Show();
	}


	void OnModal(Object sender, EventArgs e)
	{
		ADialog dlg = new ADialog();
		dlg.Text = "Modal";
		dlg.ShowDialog();
	}
	
	public AnApp()
	{
		this.Size=new Size(400,100);
		this.FormBorderStyle = FormBorderStyle.FixedDialog;		
		this.Text = "Dialog Mode Tester";

		Button modal = new Button();
		modal.Text = "New Modal dialog";
		modal.Location = new Point(10,10);
		modal.Size = new Size(180,25);
		modal.Click += new EventHandler(OnModal);
		this.Controls.Add(modal);

		Button modeless = new Button();
		modeless.Text = "New Modeless dialog";
		modeless.Location = new Point(210,10);
		modeless.Size = new Size(180,25);
		modeless.Click += new EventHandler(OnModeless);
		this.Controls.Add(modeless);
	}

	static void Main()
	{
	Application.Run( new AnApp());
	}
}