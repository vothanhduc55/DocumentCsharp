using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Text;

namespace Sams {

class DialogTest : System.Windows.Forms.Form
{

	private Button okButton;
	private Button cancelButton;
	private CheckBox checkbox;
	private GroupBox radiogroup;
	private RadioButton radio1,radio2,radio3;

	public int Radio;

	public bool Check {
		get { return checkbox.Checked; }
		set { checkbox.Checked = value;}
		}

	void OnRadio(Object sender,EventArgs e)
	{
		int n=0;
		foreach(Object o in radiogroup.Controls)
		{
			if(o is RadioButton)
			{
				RadioButton r=(RadioButton)o;
				if(r.Checked)
					Radio=n;
				n++;
			}
		}
	}

	public DialogTest()
	{

		Size = new Size(400,300);
		FormBorderStyle = FormBorderStyle.FixedDialog;
		Text = "Dialog test";

		//place the buttons on the form
		okButton = new Button();		
		okButton.DialogResult = DialogResult.OK;
		okButton.Location = new Point(20,230);
		okButton.Size = new Size(80,25);
		okButton.Text = "OK";
		Controls.Add(okButton);

		cancelButton = new Button();
		cancelButton.Location = new Point(300,230);
		cancelButton.Size = new Size(80,25);
		cancelButton.Text = "Cancel";
		cancelButton.DialogResult = DialogResult.Cancel;
		Controls.Add(cancelButton);

		//place the check box
		checkbox = new CheckBox();
		checkbox.Location = new Point(20,30);
		checkbox.Size = new Size(300,25);
		checkbox.Text = "CheckBox";
		Controls.Add(checkbox);

		//place the radiobuttons
		//they need to go into a a group box or a panel...
		radiogroup = new GroupBox();
		radiogroup.Text = "Radio Buttons";
		radiogroup.Location = new Point(10,60);
		radiogroup.Size = new Size(380,110);
		Controls.Add(radiogroup);

		radio1 = new RadioButton();
		radio1.Location = new Point(10,15); 
		// remember this is relative to the group box...
		radio1.Size = new Size(360,25);
		radio1.Click += new EventHandler(OnRadio);
		radio1.Text = "Radio Button #1";
		radiogroup.Controls.Add(radio1);


		radio2 = new RadioButton();
		radio2.Location = new Point(10,40); 
		// remember this is relative to the group box...
		radio2.Size = new Size(360,25);
		radio2.Click += new EventHandler(OnRadio);
		radio2.Text = "Radio Button #2";
		radiogroup.Controls.Add(radio2);


		radio3 = new RadioButton();
		radio3.Location = new Point(10,70); 
		// remember this is relative to the group box...
		radio3.Size = new Size(360,25);
		radio3.Click += new EventHandler(OnRadio);
		radio3.Text = "Radio Button #3";
		radiogroup.Controls.Add(radio3);

	}

}

class dtApp : System.Windows.Forms.Form
{

	void OnExit(Object sender, EventArgs e)
	{
		Application.Exit();
	}

	void OnDialogTest(Object sender, EventArgs e)
	{
		DialogTest dlg = new DialogTest();

		DialogResult r=dlg.ShowDialog();

		
		StringWriter sw=new StringWriter(new StringBuilder());

		sw.WriteLine("Dialog return value = {0}"+
                     "\nRadio Buttons = {1}\nCheck box = {2}",
					 r,dlg.Radio,dlg.Check);
		
		MessageBox.Show(sw.ToString());

	}

	public dtApp()
	{
		MainMenu mm=new MainMenu();
		mm.MenuItems.Add(new MenuItem("&Dialog"));
		mm.MenuItems[0].MenuItems.Add(new MenuItem("&Test",
			new EventHandler(OnDialogTest)));
		mm.MenuItems[0].MenuItems.Add(new MenuItem("-"));
		mm.MenuItems[0].MenuItems.Add(new MenuItem("E&xit",
			new EventHandler(OnExit)));
		Menu = mm;
	}

	static void Main()
	{
		Application.Run(new dtApp());
	}
}

}
