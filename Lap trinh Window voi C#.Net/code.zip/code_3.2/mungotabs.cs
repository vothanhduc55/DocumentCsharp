namespace Sams
{
	using System;
	using System.ComponentModel;
	using System.Drawing;
	using System.Windows.Forms;
	using System.Text;


	/// <summary>
	///    The MungoTabApp is to show off many of the capabilities and
	///    ease of use of the Windows Forms system. The application 
	///    is contructed as a form with a tab control along the bottom.
	///    Each page in the tab control shows off a different aspect of
	///    Windows Forms usage
	/// </summary>
	public class MungoTabApp : Form
	{

		// basic parts
		private Timer timer1;
		private MainMenu mainMenu1;
		private TabControl MainTabControl;
		private TabPage WelcomeTabPage;
		private TabPage SimpleTabPage;
		private TabPage DynamicTabPage;
		private TabPage ListBoxTabPage;
		private TabPage MouseTabPage;
		private TabPage TreeTabPage;

       
		//Welcome page.
		private RichTextBox WelcomeTextBox;
    
		//Controls for the Simple Controls page
		private Label label1;
		private Label label2;
		private LinkLabel linkLabel1;
		private TextBox ClearTextBox;
		private TextBox PasswordTextBox;
		private GroupBox groupBox1;
		private RadioButton radioButton1;
		private RadioButton radioButton2;
		private Panel panel1;
		private RadioButton radioButton3;
		private RadioButton radioButton4;
		private Button button1;
		private CheckBox checkBox1;
		private CheckBox checkBox2;

		// the listbox page
		private ListBox listBox1;
		private CheckedListBox checkedListBox1;
		private Label label3;
		private Label label4;
		private Label PickAWord;
		private ComboBox comboBox1;
		private ListView listView1;
		private DateTimePicker dateTimePicker1;
		private Label label6;
		private Label label7;
		private MonthCalendar monthCalendar1;
		private Label label10;
		private TrackBar trackBar1;
		private ProgressBar progressBar1;
		private Label label8;
		private DomainUpDown domainUpDown1;
		private NumericUpDown numericUpDown1;
		private Label label9;	
		private Label label11;

    
		//Mouse movement and dynamic placement
		private Button ClickMeButton;
    		
		// Dynamic controls
		private CheckBox ShowDynamic;
		private CheckBox UseAlternates;
		private CheckBox HideChecks;
		private GroupBox DynGroup;
		private RadioButton DynRadioButtn1;
		private RadioButton DynRadioButtn2;
		private RadioButton DynRadioButtn3;
		private RadioButton DynRadioButtn4;
		private ListBox EventList1;
		private ListBox EventList2;
		private Button ClearEvents1;
		private Button ClearEvents2;
		//TreeView tab
		private TreeView treeView1;
		private ListBox tvlistBox;
		private Button button4;
		private Button button5;


		private bool ShowingRadioGroup;

		private void InitWelcome()
		{
			WelcomeTextBox=new RichTextBox();
			WelcomeTabPage = new TabPage();
			WelcomeTabPage.Text = "Welcome";
			WelcomeTabPage.Size = new System.Drawing.Size(576, 422);
			WelcomeTabPage.TabIndex = 0;
			WelcomeTextBox.Text = "Welcome to the Mungo Tab App.\n"+
				"This Windows Forms demonstration" + 
				" application accompanies the Sams C# and the .NET framework"+ 
				" book by Bob Powell and Richard Weeks.\n\nThis tab hosts a"+ 
				" RichTextBox. You can edit this text if you wish."+ 
				"\n\nThe tabs in this form will show you"+ 
				" some of the more complex controls that you can use in your "+ 
				"Windows Forms application.\n\nPlease examine the source code"+ 
				" for this application carefully.\n\nBob Powell.\n";
			WelcomeTextBox.Size = new System.Drawing.Size(576, 424);
			WelcomeTextBox.TabIndex = 0;
			WelcomeTextBox.Anchor = AnchorStyles.Top |
				AnchorStyles.Left |
				AnchorStyles.Right |
				AnchorStyles.Bottom;
			WelcomeTextBox.Visible = true;
			WelcomeTabPage.Controls.Add(WelcomeTextBox);
			MainTabControl.Controls.Add(WelcomeTabPage);
		}

		// Handlers for the simple page

		private void OnClickedSimple1(Object sender, EventArgs e)
		{
			// This is one of two handlers that may be attached to the button
			string message = "You clicked the big button";
			if(this.checkBox1.Checked)
			{
				message = "And the password is...."+this.PasswordTextBox.Text;
			}

			MessageBox.Show(message);
		}

		private void OnCheckColorEdit(Object sender,EventArgs e)
		{
			// this handler add or removes a second click handler to the button.

			if(this.checkBox2.Checked)
			{
				this.button1.Click += new EventHandler(OnColorEdit);
			}
			else
			{
				this.button1.Click -= new EventHandler(OnColorEdit);			
			}
		}

		private void OnColorEdit(Object sender, EventArgs e)
		{
			// This second handler is added to the click event of the button
			// when the checkbox is checked.
			ColorDialog dlg = new ColorDialog();
			if(dlg.ShowDialog() == DialogResult.OK)
			{
				this.panel1.BackColor=dlg.Color;
			}
		}

		//This handler is invoked by clicking the link label
		//it will take you to a web site.
		private void LinkClick(Object sender, EventArgs e)
		{
			this.linkLabel1.LinkVisited=true;
			if(this.ClearTextBox.Text=="This is an editable text box")
			{
				System.Diagnostics.Process.Start("IExplore.exe",
					"http://www.bobpowell.net/");
			}
			else
			{
				try
				{
					System.Diagnostics.Process.Start(ClearTextBox.Text);
				}
				catch(Exception)
				{
					MessageBox.Show("Cannot start process "+ClearTextBox.Text);
				}
			}
			this.linkLabel1.Text = "Been there, Done that!";
		}

		//This handler is invoked each time the text in the clear text box
		// is modified. It transfers the text to the link button.
		// but only if the link has been visited.
		private new void TextChanged(Object sender, EventArgs e)
		{
			if(linkLabel1.LinkVisited )
			{
				linkLabel1.Text = ClearTextBox.Text;
			}

		}

		// initializes the simple page.
		private void InitSimple()
		{
			SimpleTabPage = new TabPage();
			SimpleTabPage.Size = new System.Drawing.Size(576, 422);
			SimpleTabPage.TabIndex = 1;
			SimpleTabPage.Text = "Simple controls";
		
			button1 = new Button();
			button1.Location = new System.Drawing.Point(32, 240);
			button1.Size = new System.Drawing.Size(520, 32);
			button1.TabIndex = 7;
			button1.Text = "Buttons can be clicked...";
			button1.Click+=new EventHandler(OnClickedSimple1);
			checkBox1 = new CheckBox();
			checkBox1.Location = new System.Drawing.Point(32, 288);
			checkBox1.Size = new System.Drawing.Size(520, 16);
			checkBox1.TabIndex = 8;
			checkBox1.Text = 
				"Checking this box will make the button "+
				"above say whats in the password box"; 
			checkBox2 = new CheckBox();
			checkBox2.Location = new System.Drawing.Point(32, 327);
			checkBox2.Size = new System.Drawing.Size(520, 16);
			checkBox2.TabIndex = 9;
			checkBox2.Text = "Checking this box will make the button" + 
				" above edit the colour of the text panel";
			checkBox2.Click += new EventHandler(OnCheckColorEdit);

			ClearTextBox = new TextBox();
			ClearTextBox.Location = new System.Drawing.Point(344, 8);
			ClearTextBox.Size = new System.Drawing.Size(216, 20);
			ClearTextBox.TabIndex = 2;
			ClearTextBox.Text = "This is an editable text box";

			domainUpDown1 = new DomainUpDown();
			domainUpDown1.AccessibleName = "DomainUpDown";
			domainUpDown1.AccessibleRole = AccessibleRole.ComboBox;
			domainUpDown1.Location = new System.Drawing.Point(128, 368);
			domainUpDown1.Size = new System.Drawing.Size(144, 20);
			domainUpDown1.TabIndex = 10;
			domainUpDown1.Text = "domainUpDown1";
			domainUpDown1.Items.AddRange(new object []{"England",
														  "Africa",
														  "Mongolia",
														  "Japan"});

			groupBox1 = new GroupBox();
			groupBox1.Location = new System.Drawing.Point(8, 80);
			groupBox1.Size = new System.Drawing.Size(560, 80);
			groupBox1.TabIndex = 5;
			groupBox1.TabStop = false;
			groupBox1.Text = "A GroupBox";

			label1 = new Label();
			label1.Location = new System.Drawing.Point(8, 8);
			label1.Size = new System.Drawing.Size(144, 24);
			label1.TabIndex = 0;
			label1.Text = "This is a label control";

			label2 = new Label();
			label2.Location = new System.Drawing.Point(8, 41);
			label2.Size = new System.Drawing.Size(328, 24);
			label2.TabIndex = 4;
			label2.Text = "The edit box to the right has a password character";

			label9 = new Label();
			label9.Location = new System.Drawing.Point(16, 368);
			label9.Size = new System.Drawing.Size(104, 24);
			label9.TabIndex = 12;
			label9.Text = "DomainUpDown";

			label10 = new Label();
			label10.Location = new System.Drawing.Point(276, 370);
			label10.Size = new System.Drawing.Size(104, 24);
			label10.TabIndex = 13;
			label10.Text = "NumericUpDown";

			linkLabel1 = new LinkLabel();
			linkLabel1.Location = new System.Drawing.Point(152, 8);
			linkLabel1.Size = new System.Drawing.Size(176, 24);
			linkLabel1.TabIndex = 1;
			linkLabel1.TabStop = true;
			linkLabel1.Text = "Link labels are like hypertext links";
			linkLabel1.Click += new EventHandler(LinkClick);

			numericUpDown1 = new NumericUpDown();
			numericUpDown1.BeginInit();
			numericUpDown1.EndInit();
			numericUpDown1.Location = new System.Drawing.Point(392, 368);
			numericUpDown1.Size = new System.Drawing.Size(176, 20);
			numericUpDown1.TabIndex = 11;

			panel1 = new Panel();
			panel1.BackColor = 
				(System.Drawing.Color)System.Drawing.Color.FromArgb((byte)255,
				(byte)255,
				(byte)128);
			panel1.BorderStyle = (BorderStyle)FormBorderStyle.Fixed3D;
			panel1.Location = new System.Drawing.Point(8, 168);
			panel1.Size = new System.Drawing.Size(560, 64);
			panel1.TabIndex = 6;

			radioButton1 = new RadioButton();
			radioButton1.Location = new System.Drawing.Point(16, 24);
			radioButton1.Size = new System.Drawing.Size(504, 16);
			radioButton1.TabIndex = 0;
			radioButton1.Text = "RadioButtons";

			radioButton2 = new RadioButton();
			radioButton2.Location = new System.Drawing.Point(16, 48);
			radioButton2.Size = new System.Drawing.Size(504, 16);
			radioButton2.TabIndex = 1;
			radioButton2.Text = "In a groupBox are used to isolate";

			radioButton3 = new RadioButton();
			radioButton3.Location = new System.Drawing.Point(16, 8);
			radioButton3.Size = new System.Drawing.Size(536, 16);
			radioButton3.TabIndex = 0;
			radioButton3.Text = "Other radio buttons";

			radioButton4 = new RadioButton();
			radioButton4.Location = new System.Drawing.Point(16, 32);
			radioButton4.Size = new System.Drawing.Size(536, 16);
			radioButton4.TabIndex = 1;
			radioButton4.Text = "in other GroupBoxes, or in this case, Panels.";

			panel1.Controls.Add(radioButton3);
			panel1.Controls.Add(radioButton4);

			groupBox1.Controls.Add(radioButton1);
			groupBox1.Controls.Add(radioButton2);

			PasswordTextBox = new TextBox();
			PasswordTextBox.Location = new System.Drawing.Point(344, 40);
			PasswordTextBox.PasswordChar = '*';
			PasswordTextBox.Size = new System.Drawing.Size(216, 20);
			PasswordTextBox.TabIndex = 3;
			PasswordTextBox.Text = "Password";

			ClearTextBox.TextChanged += new EventHandler(TextChanged); 

			SimpleTabPage.Controls.Add(button1);
			SimpleTabPage.Controls.Add(checkBox1);
			SimpleTabPage.Controls.Add(checkBox2);
			SimpleTabPage.Controls.Add(ClearTextBox);
			SimpleTabPage.Controls.Add(domainUpDown1);
			SimpleTabPage.Controls.Add(groupBox1);
			SimpleTabPage.Controls.Add(label1);
			SimpleTabPage.Controls.Add(label10);
			SimpleTabPage.Controls.Add(label2);
			SimpleTabPage.Controls.Add(label9);
			SimpleTabPage.Controls.Add(linkLabel1);
			SimpleTabPage.Controls.Add(numericUpDown1);
			SimpleTabPage.Controls.Add(panel1);
			SimpleTabPage.Controls.Add(PasswordTextBox);
		}

		// List box tab event handlers.
		// This handler transfers the value of the trackbar to the progress bar.
		private void OnTrack(Object sender, EventArgs e)
		{
			TrackBar b=(TrackBar)sender;
			this.progressBar1.Value = b.Value;
		}

		// This handler constructs a sentence from the checked items in the list
		// and displays it in a label to the right of the control.
		private void CheckedListHandler(Object sender,ItemCheckEventArgs e)
		{
			StringBuilder sb=new StringBuilder();
			int ni=-1;
			if(e.NewValue==CheckState.Checked)
				ni=e.Index;
			for(int i=0;i<checkedListBox1.Items.Count;i++)
			{
				if(i==ni || (i!=e.Index && checkedListBox1.GetItemChecked(i)))
					sb.Append(checkedListBox1.Items[i].ToString()+" ");
			}
			PickAWord.Text = sb.ToString();
		}

		// this handler gets the items from the list box and changes thier case
		// as the mouse passes over them.
		private void ListBoxMouseOver(Object sender, MouseEventArgs e)
		{
			string s;
			int i=0;
			// first we reset the case of all the strings
			foreach(object o in listBox1.Items)
			{
				s=(string)o;
				listBox1.Items[i++]=s.ToLower();
			}
			i = listBox1.IndexFromPoint(e.X,e.Y);
			if(i>-1)
			{
				s=(string)listBox1.Items[i];
				listBox1.Items[i]=s.ToUpper();
			}
		}

		// Right clicking the combo box invokes this handler
		// it sorts the contents of the dropdown.
		private void SortComboboxHandler(Object sender, EventArgs e)
		{
			this.comboBox1.Sorted=true;
		}

		// List box tab initialization.
		private void InitLists()
		{
			ListBoxTabPage = new TabPage();
			ListBoxTabPage.Size = new System.Drawing.Size(576, 422);
			ListBoxTabPage.TabIndex = 2;
			ListBoxTabPage.Text = "List boxes";

			checkedListBox1 = new CheckedListBox();
			checkedListBox1.Items.AddRange(new object[] {"The",
						"These","All","Words","Men","Are","Can","Be",
						"Might","Not","Be","Made","As","Happy","Equal",
						"Stupid","Lost"});
			checkedListBox1.Location = new System.Drawing.Point(216, 8);
			checkedListBox1.Size = new System.Drawing.Size(192, 94);
			checkedListBox1.TabIndex = 1;
			checkedListBox1.CheckOnClick=true;
			checkedListBox1.ItemCheck += 
				new ItemCheckEventHandler(CheckedListHandler);

			comboBox1 = new ComboBox();
			comboBox1.Items.AddRange(new object[] {"A",
						"Little","aardvark","Never","Hurt",
						"Anyone","5 ","9 ","7 ","1","0 ",
						"2","4","3","6","8"});
			comboBox1.Location = new System.Drawing.Point(8, 144);
			comboBox1.Size = new System.Drawing.Size(184, 21);
			comboBox1.TabIndex = 5;
			comboBox1.Text = "Context menu sorts";
			ContextMenu m=new ContextMenu();
			MenuItem t=new MenuItem("Sort",new EventHandler(SortComboboxHandler));
			m.MenuItems.Add(t);
			comboBox1.ContextMenu = m;

			dateTimePicker1 = new DateTimePicker();
			dateTimePicker1.Location = new System.Drawing.Point(216, 272);
			dateTimePicker1.Size = new System.Drawing.Size(344, 20);
			dateTimePicker1.TabIndex = 7;

			label3 = new Label();
			label3.Location = new System.Drawing.Point(8, 112);
			label3.Size = new System.Drawing.Size(184, 16);
			label3.TabIndex = 2;
			label3.Text = "A Simple list box";
			label4 = new Label();
			label4.Location = new System.Drawing.Point(224, 112);
			label4.Size = new System.Drawing.Size(184, 16);
			label4.TabIndex = 3;
			label4.Text = "A Checked list box";
			label6 = new Label();
			label6.Location = new System.Drawing.Point(216, 248);
			label6.Size = new System.Drawing.Size(184, 16);
			label6.TabIndex = 8;
			label6.Text = "A list view";
			label7 = new Label();
			label7.Location = new System.Drawing.Point(214, 303);
			label7.Size = new System.Drawing.Size(184, 16);
			label7.TabIndex = 9;
			label7.Text = "A DateTimePicker";
			label8 = new Label();
			label8.Location = new System.Drawing.Point(7, 341);
			label8.Size = new System.Drawing.Size(184, 16);
			label8.TabIndex = 11;
			label8.Text = "The MonthCalender control";

			label11 = new Label();
			label11.Location = new System.Drawing.Point(7, 384);
			label11.Size = new System.Drawing.Size(184, 16);
			label11.TabIndex = 14;
			label11.Text = "Trackbar and progress bar (Right)";

			listBox1 = new ListBox();
			listBox1.Items.AddRange( new object[] {"Fish",
						"Chips","Vinegar","Marmite","Cream Crackers",
						"Marmalade","Stilton","Mushy Peas",
						"Sherbert Lemons","Wellie boots","Spanners"});
			listBox1.Location = new System.Drawing.Point(8, 8);
			listBox1.Size = new System.Drawing.Size(184, 95);
			listBox1.TabIndex = 0;
			listBox1.MouseMove += new MouseEventHandler(ListBoxMouseOver);

			listView1 = new ListView();
			listView1.ForeColor = System.Drawing.SystemColors.WindowText;
			listView1.Items.Add(new ListViewItem("knives"));
			listView1.Items.Add(new ListViewItem("forks"));
			listView1.Items.Add(new ListViewItem("spoons"));
			listView1.Items.Add(new ListViewItem("dogs"));
			listView1.Items.Add(new ListViewItem("fish"));
			listView1.Location = new System.Drawing.Point(216, 136);
			listView1.Size = new System.Drawing.Size(352, 96);
			listView1.TabIndex = 6;

			monthCalendar1 = new MonthCalendar();
			monthCalendar1.Location = new System.Drawing.Point(8, 184);
			monthCalendar1.TabIndex = 10;
			monthCalendar1.TabStop = true;

			progressBar1 = new ProgressBar();
			progressBar1.Location = new System.Drawing.Point(216, 344);
			progressBar1.Size = new System.Drawing.Size(336, 24);
			progressBar1.TabIndex = 13;
		
			PickAWord = new Label();
			PickAWord.Location = new System.Drawing.Point(416, 8);
			PickAWord.Size = new System.Drawing.Size(152, 96);
			PickAWord.TabIndex = 4;
		
			trackBar1 = new TrackBar();
			trackBar1.BeginInit();
			trackBar1.Location = new System.Drawing.Point(272, 376);
			trackBar1.Maximum = 100;
			trackBar1.Size = new System.Drawing.Size(184, 42);
			trackBar1.TabIndex = 12;
			trackBar1.ValueChanged += new EventHandler(OnTrack);
			trackBar1.EndInit();



			ListBoxTabPage.Controls.Add(checkedListBox1);
			ListBoxTabPage.Controls.Add(comboBox1);
			ListBoxTabPage.Controls.Add(dateTimePicker1);
			ListBoxTabPage.Controls.Add(label11);
			ListBoxTabPage.Controls.Add(label3);
			ListBoxTabPage.Controls.Add(label4);
			ListBoxTabPage.Controls.Add(label6);
			ListBoxTabPage.Controls.Add(label7);
			ListBoxTabPage.Controls.Add(label8);
			ListBoxTabPage.Controls.Add(listBox1);
			ListBoxTabPage.Controls.Add(listView1);
			ListBoxTabPage.Controls.Add(monthCalendar1);
			ListBoxTabPage.Controls.Add(PickAWord);
			ListBoxTabPage.Controls.Add(progressBar1);
			ListBoxTabPage.Controls.Add(trackBar1);
		}

		// This is the first of two possible events fired by the 
		// dynamic radio buttons. It adds to a list box.
		private void RadioEvent1(Object sender, EventArgs e)
		{
			RadioButton r = (RadioButton)sender;
			this.EventList1.Items.Add("Event #1 from: "+r.Text);
		}

		// This is the second of two possible events fired by the 
		// dynamic radio buttons. It adds to a list box.
		private void RadioEvent2(Object sender, EventArgs e)
		{
			RadioButton r = (RadioButton)sender;
			this.EventList2.Items.Add("Event #2 from: "+r.Text);	
		}

		// This handler clears the first list box out
		private void Clear1(Object sender,EventArgs e)
		{
			this.EventList1.Items.Clear();
		}

		// This handler clears the second list box out
		private void Clear2(Object sender,EventArgs e)
		{
			this.EventList2.Items.Clear();
		}

		// This routine removes all events from all radio buttons
		// in the dynamic page.
		private void RemoveEvents()
		{
			DynRadioButtn4.Click -= new EventHandler(RadioEvent1);
			DynRadioButtn3.Click -= new EventHandler(RadioEvent1);
			DynRadioButtn2.Click -= new EventHandler(RadioEvent1);
			DynRadioButtn1.Click -= new EventHandler(RadioEvent1);
			DynRadioButtn4.Click -= new EventHandler(RadioEvent2);
			DynRadioButtn3.Click -= new EventHandler(RadioEvent2);
			DynRadioButtn2.Click -= new EventHandler(RadioEvent2);
			DynRadioButtn1.Click -= new EventHandler(RadioEvent2);				
		}

		// This method add the correct event handler alternative
		// to the radiobuttons on the dynamic page
		private void AddEvents()
		{

			if(!this.UseAlternates.Checked )
			{
				DynRadioButtn4.Click += new EventHandler(RadioEvent1);
				DynRadioButtn3.Click += new EventHandler(RadioEvent1);
				DynRadioButtn2.Click += new EventHandler(RadioEvent1);
				DynRadioButtn1.Click += new EventHandler(RadioEvent1);
			}
			else
			{
				DynRadioButtn4.Click += new EventHandler(RadioEvent2);
				DynRadioButtn3.Click += new EventHandler(RadioEvent2);
				DynRadioButtn2.Click += new EventHandler(RadioEvent2);
				DynRadioButtn1.Click += new EventHandler(RadioEvent2);
			}
		}

		// This event handler swops the dynamic radio button event handlers
		public void OnUseAlternates(Object sender, EventArgs e)
		{
			if(ShowingRadioGroup)
			{
				RemoveEvents();
				AddEvents();
			}
		}

		// This method removes the whole dynamic radiobutton
		// panel, clears the event list and destroys the items
		public void RemoveRadio()
		{
			if(ShowingRadioGroup)
			{
				DynGroup.Controls.Remove(DynRadioButtn4);
				DynGroup.Controls.Remove(DynRadioButtn3);
				DynGroup.Controls.Remove(DynRadioButtn2);
				DynGroup.Controls.Remove(DynRadioButtn1);
				DynamicTabPage.Controls.Remove(DynGroup);

				RemoveEvents();
				DynamicTabPage.Controls.Remove(DynGroup);

				DynRadioButtn4.Dispose();
				DynRadioButtn3.Dispose();
				DynRadioButtn2.Dispose();
				DynRadioButtn1.Dispose();
				DynGroup.Dispose();

				ShowingRadioGroup = false;

			}
		}
		
		//This method adds the dynamic radio button group and
		//wires up the event handlers.
		private void AddRadio()
		{
			if(!ShowingRadioGroup)
			{
				DynGroup = new GroupBox();
				DynGroup.Location = new System.Drawing.Point(240, 16);
				DynGroup.Size = new System.Drawing.Size(312, 120);
				DynGroup.TabIndex = 3;
				DynGroup.TabStop = false;
				DynGroup.Text = "Dynamic radiobuttons";
			
				DynRadioButtn1 = new RadioButton();
				DynRadioButtn1.Location = new System.Drawing.Point(8, 24);
				DynRadioButtn1.Size = new System.Drawing.Size(296, 16);
				DynRadioButtn1.TabIndex = 0;
				DynRadioButtn1.Text = "Choice 1";
			
				DynRadioButtn2 = new RadioButton();
				DynRadioButtn2.Location = new System.Drawing.Point(8, 41);
				DynRadioButtn2.Size = new System.Drawing.Size(296, 16);
				DynRadioButtn2.TabIndex = 1;
				DynRadioButtn2.Text = "Choice 2";
			
				DynRadioButtn3 = new RadioButton();
				DynRadioButtn3.Location = new System.Drawing.Point(8, 64);
				DynRadioButtn3.Size = new System.Drawing.Size(296, 16);
				DynRadioButtn3.TabIndex = 2;
				DynRadioButtn3.Text = "Choice 3";
			
				DynRadioButtn4 = new RadioButton();
				DynRadioButtn4.Location = new System.Drawing.Point(8, 88);
				DynRadioButtn4.Size = new System.Drawing.Size(296, 16);
				DynRadioButtn4.TabIndex = 3;
				DynRadioButtn4.Text = "Choice 4";

				AddEvents();

				DynGroup.Controls.Add(DynRadioButtn4);
				DynGroup.Controls.Add(DynRadioButtn3);
				DynGroup.Controls.Add(DynRadioButtn2);
				DynGroup.Controls.Add(DynRadioButtn1);
				DynamicTabPage.Controls.Add(DynGroup);

				ShowingRadioGroup = true;
			}
		}

		//This event handler uses helper methods to manage the presence of the 
		//dynamic radiobutton group and the handlers that they use
		private void ShowDynamicEvent(Object sender, EventArgs e)
		{
			CheckBox b=(CheckBox) sender;

			if(b.Checked)
			{
				AddRadio();
			}
			else
			{
				RemoveRadio();
			}
		
		}

		// This event handler adds or removes the dynamic check buttons and 
		// repositions the control to make it look neat and tidy.
		private void AddChecks(Object sender, EventArgs e)
		{
			CheckBox c=(CheckBox)sender;

			if(this.HideChecks.Checked)
			{
				RemoveRadio();
				c.Location = new Point(8,16);
				DynamicTabPage.Controls.Remove(UseAlternates);
				DynamicTabPage.Controls.Remove(ShowDynamic);
				ShowDynamic.Click -= new EventHandler(ShowDynamicEvent);
				UseAlternates.Dispose();
				ShowDynamic.Dispose();
			}
			else
			{
				c.Location = new Point(8,64);

				ShowDynamic = new CheckBox();
				ShowDynamic.Location = new System.Drawing.Point(8, 16);
				ShowDynamic.Size = new System.Drawing.Size(168, 16);
				ShowDynamic.TabIndex = 0;
				ShowDynamic.Text = "Show dynamic RadioRuttons";
				ShowDynamic.Click += new EventHandler(ShowDynamicEvent);

				UseAlternates = new CheckBox();
				UseAlternates.Location = new System.Drawing.Point(8, 40);
				UseAlternates.Size = new System.Drawing.Size(168, 16);
				UseAlternates.TabIndex = 1;
				UseAlternates.Text = "Use alternate handlers";
				UseAlternates.Click += new EventHandler(OnUseAlternates);

				DynamicTabPage.Controls.Add(UseAlternates);
				DynamicTabPage.Controls.Add(ShowDynamic);
			}
		}

		// This method initializes the dynamic buttons tab
		private void InitDynamic()
		{
		
			DynamicTabPage = new TabPage();
			DynamicTabPage.Size = new System.Drawing.Size(576, 422);
			DynamicTabPage.TabIndex = 3;
			DynamicTabPage.Text = "Dynamic controls";

			ClearEvents1 = new Button();
			ClearEvents1.Location = new System.Drawing.Point(48, 328);
			ClearEvents1.Size = new System.Drawing.Size(128, 24);
			ClearEvents1.TabIndex = 6;
			ClearEvents1.Text = "Clear the events";
			ClearEvents1.Click += new EventHandler(Clear1);
		
			ClearEvents2 = new Button();
			ClearEvents2.Location = new System.Drawing.Point(340, 330);
			ClearEvents2.Size = new System.Drawing.Size(128, 24);
			ClearEvents2.TabIndex = 7;
			ClearEvents2.Text = "Clear the events";
			ClearEvents2.Click += new EventHandler(Clear2);

			EventList1 = new ListBox();
			EventList1.Location = new System.Drawing.Point(16, 176);
			EventList1.Size = new System.Drawing.Size(200, 121);
			EventList1.TabIndex = 4;
			EventList2 = new ListBox();
			EventList2.Location = new System.Drawing.Point(308, 180);
			EventList2.Size = new System.Drawing.Size(200, 121);
			EventList2.TabIndex = 5;

			HideChecks = new CheckBox();
			HideChecks.Location = new System.Drawing.Point(8, 64);
			HideChecks.Size = new System.Drawing.Size(168, 16);
			HideChecks.TabIndex = 2;
			HideChecks.Text = "Hide checkboxes";
			HideChecks.Click += new EventHandler(AddChecks);
			AddChecks(HideChecks,new EventArgs());

			DynamicTabPage.Controls.Add(ClearEvents1);
			DynamicTabPage.Controls.Add(ClearEvents2);
			DynamicTabPage.Controls.Add(EventList2);
			DynamicTabPage.Controls.Add(EventList1);
			DynamicTabPage.Controls.Add(HideChecks);
		}

		//
		// Handlers for the mouse tab
		//


		// This handler moves the button to the opposite side of the tab-page
		// from the mouse cursor
		private void OnMouseMoved(Object sender, MouseEventArgs e)
		{
			Point center = 
				new Point(MouseTabPage.Width/2,MouseTabPage.Height/2);
			ClickMeButton.Location = 
				new Point(center.X-(ClickMeButton.Size.Width/2)-(e.X-center.X),
				center.Y-(ClickMeButton.Size.Height/2)-(e.Y-center.Y));
		}

		//This handler shows when the button is caught and clicked.
		private void OnClickedClickme(Object sender, EventArgs e)
		{
			MessageBox.Show("Caught me!!");
		}

		// This method initializes the mouse page.
		private void InitMouse()
		{
			MouseTabPage = new TabPage();
			MouseTabPage.Controls.Add(ClickMeButton);
			MouseTabPage.Size = new System.Drawing.Size(576, 422);
			MouseTabPage.TabIndex = 4;
			MouseTabPage.Text = "Mouse interaction";

			ClickMeButton = new Button();
			ClickMeButton.Location = new System.Drawing.Point(200, 128);
			ClickMeButton.Size = new System.Drawing.Size(184, 112);
			ClickMeButton.TabIndex = 0;
			ClickMeButton.Text = "Click me!";
			ClickMeButton.Click += new EventHandler(OnClickedClickme);
		
			MouseTabPage.Controls.Add(ClickMeButton);

			MouseTabPage.MouseMove += new MouseEventHandler(OnMouseMoved);
		}

		//Handlers for the tree tab....


		//The overloaded list function shows the treee view events in a list

		private void List(string s, TreeNode n)
		{
			string o=s+" "+n.Text;
			tvlistBox.Items.Add(o);
		}

		private void List(string s, string l, TreeNode n)
		{
			string o=s+" (new = "+l+") current = "+n.Text;
			tvlistBox.Items.Add(o);
		}

		// These handlers simply reflect the event type and a little bit of 
		// node data to the list box on the right of the treeView1 control.
		private void OnAfterCheck(Object sender,TreeViewEventArgs e)
		{
			List("AfterCheck", e.Node);
		}

		private void OnAfterCollapse(Object sender,TreeViewEventArgs e)
		{
			List("AfterCollapse", e.Node);
		}

		private void OnAfterExpand(Object sender,TreeViewEventArgs e)
		{
			List("AfterExpand", e.Node);
		}

		private void OnAfterSelect(Object sender,TreeViewEventArgs e)
		{
			List("AfterSelect", e.Node);		
		}
		private void OnBeforeCheck(Object sender,TreeViewCancelEventArgs e)
		{
			List("AfterCollapse", e.Node);		
		}
		private void OnBeforeCollapse(Object sender,TreeViewCancelEventArgs e)
		{
			List("BeforeCollapse", e.Node);		
		}
		private void OnBeforeExpand(Object sender,TreeViewCancelEventArgs e)
		{
			List("BeforeExpand", e.Node);		
		}
		private void OnBeforeLabelEdit(Object sender,NodeLabelEditEventArgs e)
		{
			List("BeforeEdit", e.Label, e.Node);	
		}

		private void OnAfterLabelEdit(Object sender,NodeLabelEditEventArgs e)
		{
			List("AfterEdit", e.Label, e.Node);	
		}


		private void OnBeforeSelect(Object sender,TreeViewCancelEventArgs e)
		{
			List("BeforeSelect", e.Node);		
		}

		private void OnAddRoot(Object sender, EventArgs e)
		{
			button5.Enabled=true;

			if(treeView1.Nodes.Count==0)
			{
				treeView1.Nodes.Add(new TreeNode("Root node"));
			}
			else
			{
				treeView1.Nodes.Add(new TreeNode("Sibling node")); 
			}
		}

		private void OnAddChild(Object sender, EventArgs e)
		{
			if(treeView1.SelectedNode==null)
				return;
			treeView1.SelectedNode.Nodes.Add(new TreeNode("Child")); 
		}

		//Initializes the tree control.
		private void InitTree()
		{
			TreeTabPage = new TabPage();
			TreeTabPage.Text = "TreeView";
			TreeTabPage.Size = new System.Drawing.Size(576, 422);
			TreeTabPage.TabIndex = 5;

			treeView1 = new TreeView();
			treeView1.Anchor = AnchorStyles.Left | 
				AnchorStyles.Top | 
				AnchorStyles.Right | 
				AnchorStyles.Bottom;
			treeView1.Size = new System.Drawing.Size(264, 360);
			treeView1.TabIndex = 0;
			treeView1.ShowLines=true;
			treeView1.ShowPlusMinus=true;
			treeView1.ShowRootLines=true;
			treeView1.LabelEdit=true;

			treeView1.AfterCheck += 
				new  TreeViewEventHandler(OnAfterCheck);
			treeView1.AfterCollapse += 
				new  TreeViewEventHandler(OnAfterCollapse);
			treeView1.AfterExpand += 
				new  TreeViewEventHandler(OnAfterExpand);
			treeView1.AfterSelect += 
				new  TreeViewEventHandler(OnAfterSelect);
			treeView1.AfterLabelEdit += 
				new  NodeLabelEditEventHandler(OnAfterLabelEdit);
			treeView1.BeforeCheck += 
				new  TreeViewCancelEventHandler(OnBeforeCheck);
			treeView1.BeforeCollapse += 
				new  TreeViewCancelEventHandler(OnBeforeCollapse);
			treeView1.BeforeExpand += 
				new  TreeViewCancelEventHandler(OnBeforeExpand);
			treeView1.BeforeSelect += 
				new  TreeViewCancelEventHandler(OnBeforeSelect);
			treeView1.BeforeLabelEdit += 
				new  NodeLabelEditEventHandler(OnBeforeLabelEdit);

		
			tvlistBox = new ListBox();
			tvlistBox.Location = new System.Drawing.Point(272, 0);
			tvlistBox.Size = new System.Drawing.Size(304, 424);
			tvlistBox.ForeColor = System.Drawing.SystemColors.WindowText;
			tvlistBox.TabIndex = 1;
		
		
			button4 = new Button();
			button4.Location = new System.Drawing.Point(16, 376);
			button4.Size = new System.Drawing.Size(96, 24);
			button4.TabIndex = 2;
			button4.Text = "Add Root";
			button4.Click += new EventHandler(OnAddRoot);

			button5 = new Button();
			button5.Location = new System.Drawing.Point(138, 376);
			button5.Size = new System.Drawing.Size(96, 24);
			button5.TabIndex = 3;
			button5.Text = "Add Child";
			button5.Click += new EventHandler(OnAddChild);
			button5.Enabled=false;

			TreeTabPage.Controls.Add(button4);
			TreeTabPage.Controls.Add(button5);
			TreeTabPage.Controls.Add(tvlistBox);
			TreeTabPage.Controls.Add(treeView1);	
		}

		

		public MungoTabApp()
		{
			//		components = new System.ComponentModel.Container();
			AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			ClientSize = new System.Drawing.Size(600, 477);

			MainTabControl = new TabControl();

			MainTabControl.Location = new System.Drawing.Point(8, 8);
			MainTabControl.SelectedIndex = 0;
			MainTabControl.Size = new System.Drawing.Size(584, 448);
			MainTabControl.TabIndex = 0;

			InitWelcome();
			InitSimple();
			InitLists();
			InitDynamic();
			InitMouse();
			InitTree();

			mainMenu1 = new MainMenu();
			Menu = mainMenu1;
			Text = "Mungo Tab App";
			timer1 = new Timer();

			MainTabControl.Controls.Add(SimpleTabPage);
			MainTabControl.Controls.Add(ListBoxTabPage);
			MainTabControl.Controls.Add(DynamicTabPage);
			MainTabControl.Controls.Add(MouseTabPage);
			MainTabControl.Controls.Add(TreeTabPage);

			Controls.Add(MainTabControl);

		}

		public static int Main(string[] args)
		{
			Application.Run(new MungoTabApp());
			return 0;
		}
	}
}
