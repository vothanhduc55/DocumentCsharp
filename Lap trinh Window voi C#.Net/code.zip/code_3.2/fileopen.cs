using System;
using System.Drawing;
using System.Windows.Forms;


namespace Sams
{

class fileopenapp : System.Windows.Forms.Form
{

	MainMenu m_menu;
	MenuItem m_filemenu;

	void OnOpenFile(Object sender, EventArgs e)
	{
		OpenFileDialog dlg=new OpenFileDialog();

		if(dlg.ShowDialog() == DialogResult.OK)
		{
			MessageBox.Show("You selected the file "+dlg.FileName);
		}
	}

	void OnExit(Object sender, EventArgs e)
	{
		Dispose();
	}

	fileopenapp()
	{
		m_menu = new MainMenu();
		m_filemenu=new MenuItem("&File");
		m_menu.MenuItems.Add(m_filemenu);
		MenuItem t;

		t=new MenuItem("&Open");
		t.Click += new EventHandler(OnOpenFile);
		m_filemenu.MenuItems.Add(t);

		t=new MenuItem("-");
		m_filemenu.MenuItems.Add(t);

		t=new MenuItem("E&xit");
		t.Click += new EventHandler(OnExit);
		m_filemenu.MenuItems.Add(t);	

		this.Menu = m_menu;	
	}

	public static void Main()
	{
		Application.Run(new fileopenapp());
	}
}

}// end of Sams namespace