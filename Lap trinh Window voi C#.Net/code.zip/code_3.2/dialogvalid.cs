 using System;
 using System.ComponentModel;
 using System.Drawing;
 using System.Windows.Forms;
 using System.IO;
 using System.Text;
 
 namespace Sams {
 
 class DialogValid : System.Windows.Forms.Form
 {
 
 	private Button okButton;
 	private Button cancelButton;
 	private NumericUpDown num;

 	public decimal Num {
 		get { return num.Value; }
 		set { num.Value = value;	}
 		}
 
	void OnValidating(Object sender, CancelEventArgs e)
 	{
 		MessageBox.Show("NumericUpDown is validating");
 	} 
 
 	void OnValid(Object sender,EventArgs e)
 	{
 		MessageBox.Show("NumericUpDown is valid");
 	} 
 
 	public DialogValid()
 	{
 
 		Size = new Size(400,100);
 		FormBorderStyle = FormBorderStyle.FixedDialog;
 		Text = "Dialog test";
 
 		//place the buttons on the form
 		okButton = new Button();		
 		okButton.DialogResult = DialogResult.OK;
 		okButton.Location = new Point(20,28);
 		okButton.Size = new Size(80,25);
 		okButton.Text = "OK";
 		Controls.Add(okButton);
 
 		cancelButton = new Button();
 		cancelButton.Location = new Point(300,28);
 		cancelButton.Size = new Size(80,25);
 		cancelButton.Text = "Cancel";
 		cancelButton.DialogResult = DialogResult.Cancel;
 		Controls.Add(cancelButton);
 
 		// place a label on the form.
 		Label l = new Label();
 		l.Text = "NumericUpDown";
 		l.Location = new Point(20,5);
 		l.Size = new Size(120,25);
 		Controls.Add(l);
 
 		// finally the numeric control;
 		num = new NumericUpDown();
 		num.Location = new Point(140,5);
 		num.Size = new Size(80,25);
 		num.Minimum = (decimal)10.0;
 		num.Maximum = (decimal)100.0;
 		num.Value = (decimal)10.0;
 		
 		//here we add event handlers to show the validating process.
 		num.Validating+=new CancelEventHandler(OnValidating);
 		num.Validated+=new EventHandler(OnValid);
 
 		Controls.Add(num);
 
 	}
 
 }
 
 class ddApp : System.Windows.Forms.Form
 {
 
 	void OnExit(Object sender, EventArgs e)
 	{
 		Application.Exit();
 	}
 
 	void OnDialogTest(Object sender, EventArgs e)
 	{
 		DialogValid dlg = new DialogValid();
 
 		DialogResult r=dlg.ShowDialog();
 
 		
 		StringWriter sw=new StringWriter(new StringBuilder());
 
 		sw.WriteLine("Dialog return value = {0}"+
        "\nNumericUpDown = {1}",r,dlg.Num);
 		
 		MessageBox.Show(sw.ToString());
 
 	}
 
 	public ddApp()
 	{
 		MainMenu mm=new MainMenu();
 		mm.MenuItems.Add(new MenuItem("&Dialog"));
 		mm.MenuItems[0].MenuItems.Add(new MenuItem("&Test",
			new EventHandler(OnDialogTest)));
 		mm.MenuItems[0].MenuItems.Add(new MenuItem("-"));
 		mm.MenuItems[0].MenuItems.Add(new MenuItem("E&xit",
			new EventHandler(OnExit)));
 		Menu = mm;
 	}
 
 	static void Main()
 	{
 		Application.Run(new ddApp());
 	}
 }
 
 } 
