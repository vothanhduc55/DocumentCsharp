using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;


namespace Sams {

class FontPicker : System.Windows.Forms.Form
{

	Button b;
	Label l;

	void OnApply(Object sender,System.EventArgs e)
	{
		FontDialog dlg = (FontDialog)sender;
		l.Font=dlg.Font;
	}

	void OnClickedb(Object sender,EventArgs e)
	{
		// Create a new Font Dialog
		FontDialog dlg=new FontDialog();
		
		//Initialize it with the existing font in the label
		dlg.Font = l.Font;

		//Set the property to allow an "Apply button on the form"
		dlg.ShowApply = true;

		//attach an OnApply event handler
		dlg.Apply += new EventHandler(OnApply);

		if(dlg.ShowDialog() != DialogResult.Cancel)
		{
			l.Font = dlg.Font;
		}
	}

	public FontPicker()
	{
		this.Size=new Size(416,320);

		l=new Label();
		l.Location = new Point(8,8);
		l.Size = new Size(400,200);
		l.Text = "0 1 2 3 4 5 6 7 8 9 \nabcdefghijklmnopqrstuvwxyz"+
		"\nABCDEFGHIJKLMNOPQRSTUVWXYZ";
		l.Font = new Font("Microsoft Sans Serif", 18f);
		this.Controls.Add(l);

		b=new Button();
		b.Text = "Choose Font";
		b.Click += new EventHandler(OnClickedb);
		b.Location = new Point(8,250);
		b.Size = new Size(400,32);
		this.Controls.Add(b);

	}


	static void Main()
	{
		Application.Run(new FontPicker());
	}
}

}