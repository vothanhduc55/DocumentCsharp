vti_encoding:SR|utf8-nl
vti_author:SR|MERLIN-VS7\\Richard Weeks
vti_modifiedby:SR|MERLIN-VS7\\Richard Weeks
vti_timecreated:TR|20 Feb 2001 15:09:52 -0000
vti_timelastmodified:TR|20 Feb 2001 15:09:52 -0000
vti_cacheddtm:TX|20 Feb 2001 15:09:52 -0000
vti_filesize:IR|1365
vti_extenderversion:SR|4.0.2.4426
vti_backlinkinfo:VX|
