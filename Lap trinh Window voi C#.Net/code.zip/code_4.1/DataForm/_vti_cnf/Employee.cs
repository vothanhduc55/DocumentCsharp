vti_encoding:SR|utf8-nl
vti_author:SR|MERLIN-VS7\\Richard Weeks
vti_modifiedby:SR|MERLIN-VS7\\Richard Weeks
vti_timecreated:TR|20 Feb 2001 17:34:01 -0000
vti_timelastmodified:TR|20 Feb 2001 19:30:45 -0000
vti_filesize:IR|1099
vti_extenderversion:SR|4.0.2.4426
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|20 Feb 2001 18:46:53 -0000
vti_cacheddtm:TX|20 Feb 2001 19:30:45 -0000
