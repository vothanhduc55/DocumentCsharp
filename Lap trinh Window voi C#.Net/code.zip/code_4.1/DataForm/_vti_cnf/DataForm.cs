vti_encoding:SR|utf8-nl
vti_author:SR|MERLIN-VS7\\Richard Weeks
vti_timecreated:TR|20 Feb 2001 16:53:33 -0000
vti_timelastmodified:TR|20 Feb 2001 22:57:34 -0000
vti_filesize:IR|2756
vti_extenderversion:SR|4.0.2.4426
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|20 Feb 2001 21:38:58 -0000
vti_cacheddtm:TX|20 Feb 2001 21:42:25 -0000
