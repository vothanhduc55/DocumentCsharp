namespace DataForm
{
    using System;

    /// <summary>
    ///    Summary description for Employee.
    ///    NOTE:  Since the employee class will be used in conjuction with DataBinding, public properties
    ///    are required.  DataBinding makes use of the System.Reflection API to access the get/set Properties.
    /// </summary>
    public class Employee
    {
        private string	_FirstName;
		private string	_LastName;
		private string	_SSN;
		private string	_Dept;
		private string	_JobTitle;
		private double	_Salary;


		public string FirstName {
			get { return _FirstName; }
			set { _FirstName = value; }
		}
		public string LastName {
			get { return _LastName; }
			set { _LastName = value; }
		}
		public string SSN {
			get { return _SSN; }
			set { _SSN = value; }
		}
		public string Dept {
			get { return _Dept; }
			set { _Dept = value; }
		}
		public string JobTitle {
			get { return _JobTitle; }
			set{ _JobTitle = value; }
		}
		public double Salary {
			get { return _Salary; }
			set { _Salary = value; }
		}
    }
}
