namespace DataForm
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Web;
    using System.Web.SessionState;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using System.Web.UI.HtmlControls;

    /// <summary>
    ///    Summary description for EmployeeForm.
    /// </summary>
    public class EmployeeForm : System.Web.UI.Page
    {
		protected System.Web.UI.WebControls.Repeater EmployeeRepeater;
		protected System.Web.UI.WebControls.Button AddEmployee;
		protected System.Web.UI.WebControls.TextBox Salary;
		protected System.Web.UI.WebControls.TextBox JobTitle;
		protected System.Web.UI.WebControls.TextBox Dept;
		protected System.Web.UI.WebControls.TextBox SSN;
		protected System.Web.UI.WebControls.TextBox LastName;
		protected System.Web.UI.WebControls.TextBox FirstName;
		protected System.Web.UI.WebControls.Label SalaryLabel;
		protected System.Web.UI.WebControls.Label JobTitleLabel;
		protected System.Web.UI.WebControls.Label DepartmentLabel;
		protected System.Web.UI.WebControls.Label SSNLabel;
		protected System.Web.UI.WebControls.Label LastNameLabel;
		protected System.Web.UI.WebControls.Label FirstNameLabel;
		protected System.Web.UI.WebControls.Label InfoLabel;
	
	public EmployeeForm()
	{
	    Page.Init += new System.EventHandler(Page_Init);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
				//Create an array list to hold the employees
                ArrayList Employees = new ArrayList( );
				this.Session["employees"] = Employees;
				
            } else {
				//Create a new employee and add them to the list
				Employee emp = new Employee( );
				emp.FirstName = FirstName.Text;
				emp.LastName  = LastName.Text;
				emp.SSN		= SSN.Text;
				emp.Dept		= Dept.Text;
				emp.JobTitle	= JobTitle.Text;
				emp.Salary	= Double.FromString( Salary.Text );
				((ArrayList)this.Session["employees"]).Add( emp );
				EmployeeRepeater.DataSource = (ArrayList)this.Session["employees"];
				EmployeeRepeater.DataBind( );
			}
		}
        protected void Page_Init(object sender, EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP+ Windows Form Designer.
            //
            InitializeComponent();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.Load += new System.EventHandler (this.Page_Load);
		}
    }
}
