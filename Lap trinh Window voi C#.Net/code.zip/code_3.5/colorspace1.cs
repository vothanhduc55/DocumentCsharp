using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ImageAlpha
{
	class Form1 : Form
	{

		Button b;
		TrackBar tr,tg,tb;
		Image i;

		void OnPaint(object Sender,PaintEventArgs e)
		{
			SolidBrush b=new SolidBrush(Color.Red);
			Rectangle r=this.ClientRectangle;
			GraphicsPath pth=new GraphicsPath();
			if(i!=null)
			{
				ColorMatrix m=new ColorMatrix();
				m.Matrix00=(float)(1.0/256*tr.Value);
				m.Matrix11=(float)(1.0/256*tg.Value);
				m.Matrix22=(float)(1.0/256*tb.Value);
				ImageAttributes ia=new ImageAttributes();
				ia.SetColorMatrix(m);
				e.Graphics.DrawImage(i,this.ClientRectangle,0,
					0,i.Width,i.Height,GraphicsUnit.Pixel,ia);
			}
		}

		void OnClickB(object sender, EventArgs e)
		{
			OpenFileDialog dlg=new OpenFileDialog();
			dlg.Filter="Bitmap files(*.bmp)|*.bmp";
			if(dlg.ShowDialog()==DialogResult.OK)
			{
				i=Image.FromFile(dlg.FileName);
				Invalidate();
			}
		}

		void OnTrack(object sender, EventArgs e)
		{
			Invalidate();
		}
			
		void OnSize(object sender, EventArgs e)
		{
			Invalidate();
		}

		public Form1()
		{
			this.Paint+=new PaintEventHandler(OnPaint);
			this.SizeChanged+=new EventHandler(OnSize);

			b=new Button();

			b.Click+=new EventHandler(OnClickB);

			b.Location=new Point(5,5);
			b.Size=new Size(60,22);
			b.Text="Image...";

			this.Controls.Add(b);

			tr=new TrackBar();
			tr.Location=new Point(100,5);
			tr.Size=new Size(200,22);
			tr.Maximum=255;
			tr.Minimum=0;
			tr.ValueChanged+=new EventHandler(OnTrack);


			this.Controls.Add(tr);

			tg=new TrackBar();
			tg.Location=new Point(100,55);
			tg.Size=new Size(200,22);
			tg.Maximum=255;
			tg.Minimum=0;
			tg.ValueChanged+=new EventHandler(OnTrack);


			this.Controls.Add(tg);
			
			tb=new TrackBar();
			tb.Location=new Point(100,105);
			tb.Size=new Size(200,22);
			tb.Maximum=255;
			tb.Minimum=0;
			tb.ValueChanged+=new EventHandler(OnTrack);


			this.Controls.Add(tb);
		}

		static void Main() 
		{
			Application.Run(new Form1());
		}
	}
}
