using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Curves
{
	/// <summary>
	/// This simple object bounces points
	/// around a rectangular area.
	/// </summary>
	class Bouncer
	{
		int dirx;
		int diry;
		public int X;
		public int Y;

		Size size;

		public Bouncer()
		{
			dirx=diry=1;
		}

		public void Move()
		{
			X+=dirx;
			Y+=diry;

			if(X<=0 || X>=size.Width)
				dirx*=-1;

			if(Y<=0 || Y>=size.Height)
				diry*=-1;
		}

		public Point Position
		{
			get{return new Point(X,Y);}
			set{X=value.X; Y=value.Y;}
		}

		public Size Size
		{
			get{ return size;}
			set{size = value;}
		}
	}

	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class BezierCurves : System.Windows.Forms.Form
	{

		Timer bounce,paint;
		TrackBar trk;

		Bouncer[] bouncers;

		void OnTickBounce(object sender, EventArgs e)
		{
			foreach(Bouncer b in bouncers)
				b.Move();
		}

		void OnTickPaint(object sender, EventArgs e)
		{
			Invalidate();
		}

		public void OnPaint(object sender, PaintEventArgs e)
		{
			Pen p=new Pen(Color.Red,10);
			p.StartCap=LineCap.DiamondAnchor;
			p.EndCap=LineCap.ArrowAnchor;
			SolidBrush br=new SolidBrush(Color.Blue);
			//Draw the curve
			e.Graphics.DrawBezier(p,new Point(550,300),bouncers[0].Position,bouncers[1].Position,new Point(50,300));
			//now draw the nodes in the curve.
			foreach(Bouncer b in bouncers)
				e.Graphics.FillEllipse(br,b.X-5,b.Y-5,10,10);
			//and show the relation between the bouncing node and the bezier end point
			p=new Pen(Color.Black,1);
			p.DashStyle=DashStyle.DashDotDot;
			e.Graphics.DrawLine(p,bouncers[0].Position,new Point(550,300));
			e.Graphics.DrawLine(p,bouncers[1].Position,new Point(50,300));
		}

		public BezierCurves()
		{
			this.Paint+=new PaintEventHandler(OnPaint);
			// A timer to manage the bouncing
			bounce=new Timer();
			bounce.Interval=5;
			bounce.Tick+=new EventHandler(OnTickBounce);
			// A timer to manage the painting refresh
			paint=new Timer();
			paint.Interval=100;
			paint.Tick+=new EventHandler(OnTickPaint);
			// Random number generator for initial positions
			Random r=new Random();
			// the form initial size
			this.Size=new Size(800,600);
			//iniialize an array of bouncing points
			bouncers = new Bouncer[2];
			for(int i=0;i<2;i++)
			{
				bouncers[i]=new Bouncer();
				bouncers[i].Position=new Point(r.Next(800),r.Next(600));
				bouncers[i].Size=new Size(800,600);
			}
			// turn on the timers
			bounce.Enabled=true;
			paint.Enabled=true;
		}

		static void Main() 
		{
			Application.Run(new BezierCurves());
		}
	}
}
