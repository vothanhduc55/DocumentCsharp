using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

class drawstar : System.Windows.Forms.Form
{
	Button button1;

	bool EndCap;

	public void OnPaint(object sender, PaintEventArgs e)
	{
		Pen pen=new Pen(Color.Black,(float)20.0);
		if(EndCap)
		{
			pen.StartCap=LineCap.Round;
			pen.EndCap=LineCap.Round;
		}

		float r36 = (float)(36.0 * 3.1415926 / 180);
		Point Center=new Point(this.ClientRectangle.Width/2,
			                   this.ClientRectangle.Height/2);
		float Pointsize = (float)0.8*Math.Min(Center.X,Center.Y);
		for(int i=0; i<10; i++)
		{
			float d1=(i & 1)==1 ? Pointsize / 2 : Pointsize;
			float d2=(i & 1)==0 ? Pointsize / 2 : Pointsize;
			e.Graphics.DrawLine(pen,
				new Point((int)(d1*Math.Cos(r36*i))+Center.X,
				          (int)(d1*Math.Sin(r36*i))+Center.Y),
				new Point((int)(d2*Math.Cos(r36*(i+1)))+Center.X,
				          (int)(d2*Math.Sin(r36*(i+1))+Center.Y)));
		}									
	}

	public void OnSizeChanged(object sender, EventArgs e)
	{
		Invalidate();
	}

	public void OnClickedButton1(object sender, EventArgs e)
	{
		EndCap = !EndCap;
		Invalidate();
	}

	public drawstar()
	{
		this.Paint+=new PaintEventHandler(OnPaint);
		this.Text="Star"; 
		this.SizeChanged+=new EventHandler(OnSizeChanged);

		button1 = new Button();
		button1.Location=new Point(5,5);
		button1.Size=new Size(50,20);
		button1.Text = "Caps";
		button1.Click+=new EventHandler(OnClickedButton1);
		this.Controls.Add(button1);

	}
    
	static void Main()
	{
		Application.Run(new drawstar());
	}
};
