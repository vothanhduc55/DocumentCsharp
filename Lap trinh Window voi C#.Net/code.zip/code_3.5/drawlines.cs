using System;
using System.Drawing;
using System.Windows.Forms;

class drawlines : System.Windows.Forms.Form
{
	Timer t;
	bool BackgroundDirty;

	public void TickEventHandler(object sender, EventArgs e)
	{
		Invalidate();
	}

	public void OnPaint(object sender, PaintEventArgs e)
	{
		// the current graphics object for
		// this window is in the PaintEventArgs

		Random r=new Random();

		Color c=Color.FromArgb(r.Next(255),r.Next(255),r.Next(255));
		Pen p=new Pen(c,(float)r.NextDouble()*10);
		e.Graphics.DrawLine(p,r.Next(this.ClientSize.Width),
								r.Next(this.ClientSize.Height),
								r.Next(this.ClientSize.Width),
								r.Next(this.ClientSize.Height));
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
		// When we resize or on the first time run
		// we'll paint the background, otherwise
		// it will be left so the lines build up
		if(BackgroundDirty)
		{
			BackgroundDirty = false;
			// We could call base.OnPaintBackground(e);
			// but that doesn't show off rectangle filling
			e.Graphics.FillRectangle(new SolidBrush(this.BackColor),
				                     this.ClientRectangle);
			
		}

	}

	public void OnSized(object sender, EventArgs e)
	{
		BackgroundDirty=true;
		Invalidate();
	}

	public drawlines()
	{
		t=new Timer();
		t.Interval=300;
		t.Tick+=new System.EventHandler(TickEventHandler);
		t.Enabled=true;
		this.Paint+=new PaintEventHandler(OnPaint);
		this.SizeChanged+=new EventHandler(OnSized);
		this.Text="Lines and lines and lines"; 
		BackgroundDirty = true;
	}
    
	static void Main()
	{
		Application.Run(new drawlines());
	}
};
