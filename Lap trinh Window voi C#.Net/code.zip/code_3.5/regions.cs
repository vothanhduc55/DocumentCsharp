using System;
using System.Drawing;
using System.Drawing.Drawing2D;	
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace regions
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class RegionsTest : System.Windows.Forms.Form
	{
		void PaintRegions(Graphics g,CombineMode m,Point offset,string text)
		{
			Region ra,rb;
			GraphicsPath p=new GraphicsPath();
			p.AddRectangle(new Rectangle(60,60,120,120));
			ra=new Region(p);
			p=new GraphicsPath();
			p.AddEllipse(0,0,120,120);
			rb=new Region(p);
			ra.Translate(offset.X,offset.Y );
			rb.Translate(offset.X,offset.Y);
			g.SetClip(ra,CombineMode.Replace);
			g.SetClip(rb,m);
			SolidBrush brush=new SolidBrush(Color.Black);
			g.FillRectangle(brush,this.ClientRectangle);
			g.ResetClip();
			g.DrawString(text,
				new Font("Ariel",(float)16),
				brush,(float)offset.X+60,(float)offset.Y+220);
		}

		void OnPaint(object sender, PaintEventArgs e)
		{
			// A union of two regions...
			PaintRegions(e.Graphics,CombineMode.Union,
				new Point(0,0),"Union");
			// the intersection of two regions
			PaintRegions(e.Graphics,CombineMode.Intersect,
				new Point(250,0),"Intersect");
			// Region exclusive or
			PaintRegions(e.Graphics,CombineMode.Xor,
				new Point(500,0),"Xor");
			// The complement of the two regions
			PaintRegions(e.Graphics,CombineMode.Complement,
				new Point(0,250),"Complement");
			// Exclusion.
			PaintRegions(e.Graphics,CombineMode.Exclude,
				new Point(250,250),"Exclude");
		}

		public RegionsTest()
		{
			this.Paint+=new PaintEventHandler(OnPaint);
			this.Size = new Size(800,800);
		}

		static void Main() 
		{
			Application.Run(new RegionsTest());
		}
	}
}
