using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ImageAlpha
{
	class Form1 : Form
	{

		Button b;
		TrackBar t;
		Image i;

		void OnPaint(object Sender,PaintEventArgs e)
		{
			SolidBrush b=new SolidBrush(Color.Red);
			Rectangle r=this.ClientRectangle;
			GraphicsPath pth=new GraphicsPath();
			for(int c=1;c<10;c++)
			{
				r.Inflate(-(this.ClientRectangle.Width/20),
					-(this.ClientRectangle.Height/20));
				pth.AddRectangle(r);
			}
			e.Graphics.FillPath(b,pth);

			if(i!=null)
			{
				ColorMatrix m=new ColorMatrix();
				m.Matrix33=(float)(1.0/256*t.Value);
				ImageAttributes ia=new ImageAttributes();
				ia.SetColorMatrix(m);
				e.Graphics.DrawImage(i,this.ClientRectangle,0,0,i.Width,i.Height,GraphicsUnit.Pixel,ia);
			}
		}

		void OnClickB(object sender, EventArgs e)
		{
			OpenFileDialog dlg=new OpenFileDialog();
			dlg.Filter="Bitmap files(*.bmp)|*.bmp";
			if(dlg.ShowDialog()==DialogResult.OK)
			{
				i=Image.FromFile(dlg.FileName);
				Invalidate();
			}
		}

		void OnTrack(object sender, EventArgs e)
		{
			Invalidate();
		}
			
		void OnSize(object sender, EventArgs e)
		{
			Invalidate();
		}

		public Form1()
		{
			this.Paint+=new PaintEventHandler(OnPaint);
			this.SizeChanged+=new EventHandler(OnSize);

			b=new Button();

			b.Click+=new EventHandler(OnClickB);

			b.Location=new Point(5,5);
			b.Size=new Size(60,22);
			b.Text="Image...";

			this.Controls.Add(b);

			t=new TrackBar();
			t.Location=new Point(100,5);
			t.Size=new Size(200,22);
			t.Maximum=255;
			t.Minimum=0;
			t.ValueChanged+=new EventHandler(OnTrack);

			this.Controls.Add(t);
		}

		static void Main() 
		{
			Application.Run(new Form1());
		}
	}
}
