using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Alphablending
{
	public class Alphablending : System.Windows.Forms.Form
	{

		void OnPaint(object sender, PaintEventArgs e)
		{
			SolidBrush b=new SolidBrush(Color.Red);
			Rectangle r=this.ClientRectangle;
			GraphicsPath pth=new GraphicsPath();
			for(int c=1;c<10;c++)
			{
				r.Inflate(-(this.ClientRectangle.Width/20),
					-(this.ClientRectangle.Height/20));
				pth.AddRectangle(r);
			}
			e.Graphics.FillPath(b,pth);
			Random rnd=new Random();
			for(int y=0;y<5;y++)
			{
				for(int x=0;x<5;x++)
				{
					b.Color=Color.FromArgb((int)((((5*x)+y)*10.63)),
						(byte)rnd.Next(255),
						(byte)rnd.Next(255),
						(byte)rnd.Next(255));
					e.Graphics.FillEllipse(b,this.ClientRectangle.Width/5*x,
						this.ClientRectangle.Height/5*y,
						this.ClientRectangle.Width/5,
						this.ClientRectangle.Height/5);
				}
			}
		}

		void OnSize(object sender, EventArgs e)
		{
			Invalidate();
		}

		public Alphablending()
		{
			this.Paint+=new PaintEventHandler(OnPaint);
			this.SizeChanged+=new EventHandler(OnSize);
			this.BackColor=Color.White;
		}


		static void Main() 
		{
			Application.Run(new Alphablending());
		}
	}
}
