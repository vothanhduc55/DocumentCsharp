using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Curves
{
	/// <summary>
	/// This simple object bounces points
	/// around a rectangular area.
	/// </summary>
	class Bouncer
	{
		int dirx;
		int diry;
		int X;
		int Y;

		Size size;

		public Bouncer()
		{
			dirx=diry=1;
		}

		public void Move()
		{
			X+=dirx;
			Y+=diry;

			if(X<=0 || X>=size.Width)
				dirx*=-1;

			if(Y<=0 || Y>=size.Height)
				diry*=-1;
		}

		public Point Position
		{
			get{return new Point(X,Y);}
			set{X=value.X; Y=value.Y;}
		}

		public Size Size
		{
			get{ return size;}
			set{size = value;}
		}
	}

	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Curves : System.Windows.Forms.Form
	{

		Timer bounce,paint;
		TrackBar trk;

		Bouncer[] bouncers;

		void OnTickBounce(object sender, EventArgs e)
		{
			foreach(Bouncer b in bouncers)
				b.Move();
		}

		void OnTickPaint(object sender, EventArgs e)
		{
			Invalidate();
		}

		public void OnPaint(object sender, PaintEventArgs e)
		{
			Pen p=new Pen(Color.Red,10);
			SolidBrush br=new SolidBrush(Color.Blue);
			Point[] points = new Point[bouncers.Length];
			int i=0;
			// need to translate our bouncers to an array of points
			foreach(Bouncer b in bouncers)
				points[i++]=b.Position;
			//Draw the curve
			e.Graphics.DrawCurve(p,points,0,points.Length-1,(float)trk.Value);
			//now draw the nodes in the curve.
			foreach(Point pn in points)
				e.Graphics.FillEllipse(br,pn.X-5,pn.Y-5,10,10);
		}

		public Curves()
		{
			this.Paint+=new PaintEventHandler(OnPaint);
			// A timer to manage the bouncing
			bounce=new Timer();
			bounce.Interval=5;
			bounce.Tick+=new EventHandler(OnTickBounce);
			// A timer to manage the painting refresh
			paint=new Timer();
			paint.Interval=100;
			paint.Tick+=new EventHandler(OnTickPaint);
			// Random number generator for initial positions
			Random r=new Random();
			// the form initial size
			this.Size=new Size(800,600);
			//iniialize an array of bouncing points
			bouncers = new Bouncer[6];
			for(int i=0;i<6;i++)
			{
				bouncers[i]=new Bouncer();
				bouncers[i].Position=new Point(r.Next(800),r.Next(600));
				bouncers[i].Size=new Size(800,600);
			}
			// turn on the timers
			bounce.Enabled=true;
			paint.Enabled=true;
			//create a trackbar for the line tension
			trk = new TrackBar();
			trk.Location=new Point(5,25);
			trk.Size=new Size(100,20);
			trk.Minimum=1;
			trk.Maximum=10;
			trk.Value=2;
			this.Controls.Add(trk);
			//and label it nicely for the user
			Label lb=new Label();
			lb.Location=new Point(5,5);
			lb.Size=new Size(100,20);
			lb.Text="Curve tension";		
			this.Controls.Add(lb);			
		}

		static void Main() 
		{
			Application.Run(new Curves());
		}
	}
}
