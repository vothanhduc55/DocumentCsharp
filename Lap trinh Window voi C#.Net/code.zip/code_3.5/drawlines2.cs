using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

class drawlines : System.Windows.Forms.Form
{
	Timer t;
	bool BackgroundDirty;

	public void TickEventHandler(object sender, EventArgs e)
	{
		Invalidate();
	}

	public void OnPaint(object sender, PaintEventArgs e)
	{
		// the current graphics object for
		// this window is in the PaintEventArgs

		Random r=new Random();

		Color cA=Color.FromArgb(r.Next(255),r.Next(255),r.Next(255));
		Color cB=Color.FromArgb(r.Next(255),r.Next(255),r.Next(255));
		Point pA=new Point(r.Next(this.ClientSize.Width),
						   r.Next(this.ClientSize.Height));
		Point pB=new Point(r.Next(this.ClientSize.Width),
						   r.Next(this.ClientSize.Height));
		LinearGradientBrush brush = new LinearGradientBrush(pA,pB,cA,cB);
		Pen p=new Pen(brush,(float)r.NextDouble()*10);
		e.Graphics.DrawLine(p,pA,pB);
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
		// When we resize or on the first time run
		// we'll paint the background, otherwise
		// it will be left so the lines build up
		if(BackgroundDirty)
		{
			BackgroundDirty = false;
			LinearGradientBrush gb=
				new LinearGradientBrush(this.ClientRectangle,
                                        Color.Navy,
				                        Color.Aquamarine,
				                        90);
			e.Graphics.FillRectangle(gb,this.ClientRectangle);		
		}

	}

	public void OnSized(object sender, EventArgs e)
	{
		BackgroundDirty=true;
		Invalidate();
	}

	public drawlines()
	{
		t=new Timer();
		t.Interval=300;
		t.Tick+=new System.EventHandler(TickEventHandler);
		t.Enabled=true;
		this.Paint+=new PaintEventHandler(OnPaint);
		this.SizeChanged+=new EventHandler(OnSized);
		this.Text="Lines and lines and lines"; 
		BackgroundDirty = true;
	}
    
	static void Main()
	{
		Application.Run(new drawlines());
	}
};
