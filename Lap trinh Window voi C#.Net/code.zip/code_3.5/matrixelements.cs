using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;

namespace matrixelements
{
	public class MatrixElements : System.Windows.Forms.Form
	{
		void DumpMatrix(Graphics g, Matrix m, Point p)
		{
			StringBuilder sb=new StringBuilder();
			sb.AppendFormat("{0},{1},0\n{2},{3},0\n{4},{5},1",
				m.Elements[0],m.Elements[1],m.Elements[2],
				m.Elements[3],m.Elements[4],m.Elements[5]);
			GraphicsState s=g.Save();
			g.ResetTransform();
			g.DrawString(sb.ToString(),new Font("Ariel",(float)16),
				new SolidBrush(Color.Black),p,StringFormat.GenericDefault);
			g.Restore(s);
		}

		void OnSize(object sender,EventArgs e)
		{
			Invalidate();
		}

		void OnPaint(object sender, PaintEventArgs e)
		{
			GraphicsState gs;
			Matrix m=new Matrix();

			//position and draw the axes by translating the whole window
			// so that the origin is in the center of the screen
			e.Graphics.TranslateTransform((float)this.ClientRectangle.Width/2,
				(float)this.ClientRectangle.Height/2);
			e.Graphics.DrawLine(new Pen(Color.Black,(float)1),0,-1000,0,1000);
			e.Graphics.DrawLine(new Pen(Color.Black,(float)1),-100,0,1000,0);

			//Draw an ordinary square about the origin.
			e.Graphics.DrawRectangle(new Pen(Color.Black,(float)3),
				-50,-50,100,100);
			DumpMatrix(e.Graphics,m,new Point(0,0));

			m.Rotate(30,MatrixOrder.Append);
			DumpMatrix(e.Graphics,m,new Point(0,100));
   
			gs=e.Graphics.Save();
			e.Graphics.MultiplyTransform(m);
			e.Graphics.DrawRectangle(new Pen(Color.Red,3),
				-50,-50,100,100);
			e.Graphics.Restore(gs);

			m.Scale(1,3,MatrixOrder.Append);
			DumpMatrix(e.Graphics,m,new Point(0,200));
   
			gs=e.Graphics.Save();
			e.Graphics.MultiplyTransform(m);
			e.Graphics.DrawRectangle(new Pen(Color.Green,3),
				-50,-50,100,100);
			e.Graphics.Restore(gs);
   
			m.Translate(100,130,MatrixOrder.Append);
			DumpMatrix(e.Graphics,m,new Point(0,300));

			gs=e.Graphics.Save();
			e.Graphics.MultiplyTransform(m);
			e.Graphics.DrawRectangle(new Pen(Color.Blue,3),
				-50,-50,100,100);
			e.Graphics.Restore(gs);  
		}

		public MatrixElements()
		{
			this.Paint+=new PaintEventHandler(OnPaint);
			this.SizeChanged+=new EventHandler(OnSize);
		}

		static void Main() 
		{
			Application.Run(new MatrixElements());
		}
	}
}
