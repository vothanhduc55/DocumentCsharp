namespace EmployeeBrowser
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Data.ADO;

	using System.Drawing;
    using System.Web;
    using System.Web.SessionState;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using System.Web.UI.HtmlControls;
	
	

	using Stingray.Data;

    /// <summary>
    ///    Summary description for default.
    /// </summary>
    public class EmployeeSearch : System.Web.UI.Page
    {
		protected System.Web.UI.WebControls.Button btnGO;
		protected System.Web.UI.WebControls.TextBox txtMaxPerRow;
		protected System.Web.UI.WebControls.TextBox txtLastName;
		protected System.Web.UI.WebControls.TextBox txtFirstName;
		protected System.Web.UI.WebControls.DropDownList lbDepartments;
		protected ArrayList									DepartmentList;

		protected System.Collections.Hashtable				htDeptMapping;
		
		
		public EmployeeSearch()
		{
			Page.Init += new System.EventHandler(Page_Init);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
			if( !this.IsPostBack ) {
					htDeptMapping = new Hashtable( );
					LoadData( );
				
					this.Session.Add( "SEARCH_HT_MAPPING", htDeptMapping );
					lbDepartments.DataSource = DepartmentList;
					lbDepartments.DataBind( );
				} else {
					 htDeptMapping = (Hashtable)this.Session["SEARCH_HT_MAPPING"];
				}
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP+ Windows Form Designer.
            //
            InitializeComponent();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.Load += new System.EventHandler (this.Page_Load);
		}

		protected void OnSearch_Click( object sender, EventArgs e ) {
				//Get the Selected params
			if(this.htDeptMapping == null) {
				this.Navigate( "EmployeeListing.aspx?MaxPerPage=5" );
			} else {
			
				int		DeptId		= (int)this.htDeptMapping[lbDepartments.SelectedItem.Text];
				string	FirstName	= this.txtFirstName.Text;
				string	LastName	= this.txtLastName.Text;
				
				int MaxPerRow		= 5;
				if( txtMaxPerRow.Text != "" ) {
					MaxPerRow	= this.txtMaxPerRow.Text.ToInt32( );
				}
				
				
				//build the request URL
				string request;
				
				if( DeptId != 0) {
					object[] args = { DeptId, FirstName, LastName, MaxPerRow };
					request = string.Format("DeptId={0}&FirstName={1}&LastName={2}&MaxPerPage={3}", args);
				} else {
					object[] args = { FirstName, LastName, MaxPerRow };
					request = string.Format("FirstName={0}&LastName={1}&MaxPerPage={2}", args);
				}
				this.Navigate( string.Format("EmployeeListing.aspx?{0}", request) );
			}
		}

		/// <summary>
		/// 
		/// </summary>
		protected void LoadData( ) {
			ADOConnection dbCon = DBAccess.AquireConnection( );
			ADODataSetCommand cmd = new ADODataSetCommand( "SELECT * FROM DEPARTMENT", dbCon );
			DataSet dsResult = new DataSet( );
			cmd.FillDataSet( dsResult, "DEPARTMENT" );
			
			DepartmentList = new ArrayList( );
			DepartmentList.Add( "All Departments" );
			htDeptMapping.Add( "All Departments", 0 );

			foreach( DataRow row in dsResult.Tables["DEPARTMENT"].Rows ) {
				Department d = new Department( );
				d.FromDataRow( row );
				DepartmentList.Add( d.Name );
				htDeptMapping.Add( d.Name, d.Id );
			}
			dbCon.Close( );
			dbCon.Dispose( );
			dsResult.Dispose( );
		}
    }
}
