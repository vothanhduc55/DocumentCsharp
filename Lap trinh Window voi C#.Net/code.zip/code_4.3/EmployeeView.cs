namespace Stingray.Pagelets
{

	using System;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Collections;
	using System.ComponentModel;
	

	public class EmployeeView : UserControl {
		public System.Web.UI.WebControls.Button	m_btnEdit;
		
		private string	m_Id;
		private string	m_FirstName;
		private string	m_LastName;
		private Guid	m_PicId;

		public string EmployeeId {
			get { return m_Id;  }
			set { m_Id = value; }
		}

		public string FirstName {
			get{ return m_FirstName; }
			set { m_FirstName = value; }
		}

		public string LastName {
			get { return m_LastName; }
			set { m_LastName = value; }
		}

		public Guid PictureId {
			get { return m_PicId; }
			set { m_PicId = new Guid( value.ToString( ) ); }
		}

		public string FullName {
			get { return string.Format("{0}, {1}", m_LastName, m_FirstName ); }
		}

		public string ImageName {
			get { return string.Format("{0}.jpg",m_PicId.ToString( )); }
		}
		
		//Handle The edit click
		protected void OnEdit_Click( object sender, EventArgs e ) {
			System.Web.UI.WebControls.Button b = (System.Web.UI.WebControls.Button)sender;
			string EmpId = b.CommandArgument;
			this.Navigate( string.Format("EmployeeEdit.aspx?EmpId={0}",EmpId));
		}
	}

}