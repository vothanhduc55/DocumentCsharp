namespace Stingray.Pagelets
{
   	using System;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Collections;
	using System.ComponentModel;
	

	public class HeaderControl : UserControl {
    
		private	string			m_Text;
		private string			m_ImageURL;
		protected System.Web.UI.WebControls.Image	ImageCtrl;
		protected System.Web.UI.WebControls.Label	HeaderText;
		
		public string Text {
			get { return m_Text; }
			set { m_Text = (string)value; }
		}

		public string ImageUrl {
			get { return m_ImageURL; }
			set { m_ImageURL = (string)value; }
		}

		public HeaderControl( ) {
			this.Load += new EventHandler( Page_Load );
		}

		protected void Page_Load( object sender, EventArgs e ) {
			ImageCtrl.ImageUrl = m_ImageURL;
			HeaderText.Text = m_Text;
		}
    }
}