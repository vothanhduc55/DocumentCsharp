namespace EmployeeBrowser
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Data.ADO;

	using System.Drawing;
    using System.Web;
    using System.Web.SessionState;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using System.Web.UI.HtmlControls;
	
	

	using Stingray.Data;

    /// <summary>
    ///    Summary description for default.
    /// </summary>
    public class MainPage : System.Web.UI.Page
    {
		
		public MainPage()
		{
			Page.Init += new System.EventHandler(Page_Init);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
			if( !this.IsPostBack ) {
				this.Navigate("EmployeeSearch.aspx");
			}
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP+ Windows Form Designer.
            //
            InitializeComponent();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.Load += new System.EventHandler (this.Page_Load);
		}

		
    }
}
