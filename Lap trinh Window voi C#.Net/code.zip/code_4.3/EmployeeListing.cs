namespace EmployeeBrowser
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Web;
    using System.Web.SessionState;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using System.Web.UI.HtmlControls;

	using Stingray.Data;



	class ViewerState {
		public static string VIEW_STATE_SESSION_KEY = "EMPLOYEE_VIEWER_STATE";
		public DataSet	m_EmployeeCache;
		public int		m_RowCount = 0;
		public int		m_MaxPerPage = 5;
		public int		m_CurrentIndex = 0;
		public Stack	m_IdxStack = new Stack( );
	}

    /// <summary>
    ///    Summary description for EmployeeViewer.
    /// </summary>
    public class EmployeeListing : System.Web.UI.Page
    {
		protected System.Web.UI.WebControls.Button		btnNext;
		protected System.Web.UI.WebControls.Button		btnPrev;
		protected System.Web.UI.WebControls.Repeater	EmployeeRepeater;
		private ArrayList								m_EmployeeList;
		private ViewerState								m_ViewerState;
	
		public EmployeeListing()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		protected void Page_Load(object sender, EventArgs e)
		{
           if (!IsPostBack)
           {
				int		DeptId = 0;
				string	FirstName;
				string  LastName;

				
			    m_ViewerState = new ViewerState( );
				this.Session.Add(ViewerState.VIEW_STATE_SESSION_KEY,m_ViewerState);

				GetParams( out FirstName, out LastName, ref DeptId, ref m_ViewerState.m_MaxPerPage );

				LoadDataSet( FirstName, LastName, DeptId );
			   
				
				//save current index
				m_ViewerState.m_IdxStack.Push( 0 );
				int Index = this.CalcNextIndex(  );
				m_ViewerState.m_CurrentIndex = Index;
			    this.DisplayData( 0, m_ViewerState.m_CurrentIndex );
			    UpdateNavigationButtons( );

		   } else {
			   m_ViewerState = (ViewerState)this.Session[ViewerState.VIEW_STATE_SESSION_KEY];
		   }
						
        }

		
        protected void Page_Init(object sender, EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP+ Windows Form Designer.
            //
            InitializeComponent();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.Load += new System.EventHandler (this.Page_Load);
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="FirstName"> </param>
		/// <param name="LastName"> </param>
		/// <param name="DeptId"> </param>
		protected void GetParams(out string FirstName, out string LastName, ref int DeptId, ref int MaxPerPage ) {
			DeptId		 = this.Request.QueryString["DeptId"] == null ? -1 : Int32.FromString(this.Request.QueryString["DeptId"].ToString( ));
			FirstName	 = this.Request.QueryString["FirstName"] == null ? "" : this.Request.QueryString["FirstName"].ToString();
			LastName	 = this.Request.QueryString["LastName"] == null ? "" : this.Request.QueryString["LastName"].ToString();
			MaxPerPage	 = this.Request.QueryString["MaxPerPage"] == null ? 5 : Int32.FromString(this.Request.QueryString["MaxPerPage"].ToString( ));
		}

		/// <summary>
		/// 
		/// </summary>
		protected void LoadDataSet(string FName, string LName, int DeptId ) {
			if( DeptId != -1 ) {
				m_ViewerState.m_EmployeeCache = Search.Find( DBAccess.AquireConnection( ), DeptId, FName, LName);
			} else {
				m_ViewerState.m_EmployeeCache = Search.Find( DBAccess.AquireConnection( ), FName, LName);
			}
			m_ViewerState.m_RowCount = m_ViewerState.m_EmployeeCache.Tables["EMPLOYEE"].Rows.Count;
		}


		protected void DisplayData( int StartIndex, int StopIndex ) {
			m_EmployeeList = new ArrayList( );

			for(int i = StartIndex; i < StopIndex; i++) {
				Employee e = new Employee( );
				e.FromDataRow( m_ViewerState.m_EmployeeCache.Tables["EMPLOYEE"].Rows[i] );
				m_EmployeeList.Add( e );
			}
			
			//Bind the data
			EmployeeRepeater.DataSource= m_EmployeeList;
			EmployeeRepeater.DataBind( );

			//navigate button
			
		}

		protected void OnNext_Click( object sender, EventArgs e ) {
			//save current index
			int nLast =  m_ViewerState.m_CurrentIndex;
			m_ViewerState.m_IdxStack.Push( nLast);
			m_ViewerState.m_CurrentIndex = CalcNextIndex( );
			DisplayData( nLast, m_ViewerState.m_CurrentIndex );
			UpdateNavigationButtons( );
			
		}

		protected void OnPrev_Click( object sender, EventArgs e ) {
			int nStop  = (int)m_ViewerState.m_IdxStack.Pop( );
			int nStart = (int)m_ViewerState.m_IdxStack.Peek( );
			DisplayData( nStart, nStop );
			m_ViewerState.m_CurrentIndex = nStop;
			UpdateNavigationButtons( );
		}
		
		/// <summary>
		/// 
		/// </summary>
		protected int CalcNextIndex( ) {
			return (m_ViewerState.m_CurrentIndex + m_ViewerState.m_MaxPerPage) > m_ViewerState.m_RowCount
				? m_ViewerState.m_RowCount : (m_ViewerState.m_CurrentIndex + m_ViewerState.m_MaxPerPage);
			
		}

		protected void UpdateNavigationButtons( ) {
			this.btnNext.Visible = m_ViewerState.m_CurrentIndex < m_ViewerState.m_RowCount;
			this.btnPrev.Visible = (int)m_ViewerState.m_IdxStack.Peek( ) != 0;
		}

	
    }
}
