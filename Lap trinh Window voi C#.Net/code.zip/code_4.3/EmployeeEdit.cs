namespace EmployeeBrowser
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
	using System.Data.ADO;
	using System.Drawing;
    using System.Web;
    using System.Web.SessionState;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using System.Web.UI.HtmlControls;


	using Stingray.Data;

    /// <summary>
    ///    Summary description for EmployeeEdit.
    /// </summary>
    public class EmployeeEdit : System.Web.UI.Page
    {
		protected System.Web.UI.WebControls.Button btnUpdate;
		protected System.Web.UI.WebControls.DropDownList lbDepartment;
		protected System.Web.UI.WebControls.TextBox txtLastName;
		protected System.Web.UI.WebControls.TextBox txtFirstName;
		protected System.Web.UI.WebControls.Label EmployeeId;
		protected System.Web.UI.HtmlControls.HtmlInputFile EmpImageFile;
		protected System.Web.UI.WebControls.Image EmployeeImage;
		

	public EmployeeEdit()
	{
	    Page.Init += new System.EventHandler(Page_Init);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PopulateForm( );
            } else {
				UpdateEmployee( );
			}
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP+ Windows Form Designer.
            //
            InitializeComponent();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.Load += new System.EventHandler (this.Page_Load);
		}

		/// <summary>
		/// 
		/// </summary>
		private void PopulateForm( ) {
			
			string EmpId = this.Request.QueryString["EmpId"].ToString( );
			ADOConnection dbCon = DBAccess.AquireConnection( );
			ADODataSetCommand cmd = new ADODataSetCommand(string.Format("SELECT * FROM EMPLOYEE WHERE EMP_ID = {0}", EmpId),dbCon);
			DataSet dsResult = new DataSet( );
			Employee emp = new Employee( );

			cmd.FillDataSet( dsResult, "EMPLOYEE" );
			if( dsResult.Tables["EMPLOYEE"] != null)
				emp.FromDataRow( dsResult.Tables["EMPLOYEE"].Rows[0] );
			

			//Set the values for stuff
			this.EmployeeId.Text = emp.Id;
			this.txtFirstName.Text = emp.FirstName;
			this.txtLastName.Text  = emp.LastName;
			this.EmployeeImage.ImageUrl = string.Format("images/employees/{0}.jpg",emp.PictureId.ToString( ));

			//Populate the Department list
			cmd.SelectCommand.CommandText = "SELECT * FROM DEPARTMENT";
			cmd.FillDataSet( dsResult, "DEPARTMENT" );
			Hashtable ht = new Hashtable( );

			foreach( DataRow row in dsResult.Tables["DEPARTMENT"].Rows) {
				int nValue = (int)row["DEPT_ID"];
				string Name = (string)row["NAME"];
				ht.Add( Name, nValue );
				this.lbDepartment.Items.Add( Name );
			}
			this.Session["DEPT_MAPPING"] = ht;
			this.Session["CACHE:EMP"] = emp;		//save the employee

		}

		/// <summary>
		/// 
		/// </summary>
		private void UpdateEmployee( ) {
			
			Employee emp = (Employee)Session["CACHE:EMP"];
			emp.FirstName = this.txtFirstName.Text;
			emp.LastName = this.txtLastName.Text;

			
			//get new department
			Hashtable ht = (Hashtable)Session["DEPT_MAPPING"];
			int DeptId = (int)ht[ this.lbDepartment.SelectedItem.Text ];
			emp.DeptId = DeptId;
			
			
			
			//Get the Photo
			if( this.EmpImageFile.PostedFile != null && this.EmpImageFile.PostedFile.FileName.Length > 0 ) {
				//Remove the Old Photo
				string strFileName = string.Format("D:/SHARE_POINT/SAMS/C# and the .NET framework/Part 4/Code/EmployeeBrowser/images/employees/{0}.jpg",emp.PictureId.ToString( ));
				System.IO.File file = new System.IO.File( strFileName );
				file.Delete( );
				
				emp.PictureId =  System.Guid.NewGuid( );
				strFileName = string.Format("D:/SHARE_POINT/SAMS/C# and the .NET framework/Part 4/Code/EmployeeBrowser/images/employees/{0}.jpg",emp.PictureId.ToString( ));
				this.EmpImageFile.PostedFile.SaveAs( strFileName );
			}

			//Update the Employee
			DBAccess.Save( DBAccess.AquireConnection( ), emp );

			string strUrl = string.Format("EmployeeListing.aspx?DeptId={0}&FirstName={1}&LastName={2}",emp.DeptId,emp.FirstName,emp.LastName);
			this.Navigate( strUrl );
			
		}
    }
}
