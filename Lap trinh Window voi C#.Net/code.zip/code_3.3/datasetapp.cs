namespace Sams
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.Data;
    using System.ComponentModel;
    using System.Windows.Forms;

    //This application shows simple data binding to a 
    //programatically created dataset.
    public class datasetapp : System.Windows.Forms.Form
    {
        private System.ComponentModel.Container components;

        //Component declarations
        private Label lbl_first,lbl_name,lbl_title,lbl_company,lbl_phone;
        private TextBox FirstName,SurName,Title,Company,Phone;
        private Button btnNext, btnPrev, btnNew, btnEnd;

        //The dataset used to store the table
        private DataSet dataset;

        //Button handler to navigate backwards through the table records
        private void OnPrev(Object sender,EventArgs e)
        {
			this.BindingContext[dataset.Tables["Contacts"]].Position--;
        }

        //Button handler to navigate forward through the table records
        private void OnNext(Object sender,EventArgs e)
        {
			this.BindingContext[dataset.Tables["Contacts"]].Position++;
        }

        //Button handler to create a new row
        private void OnNew(Object sender, EventArgs e)
        {
            NewEntry();
        }

    //Button handler to exit the application
    private void OnEnd(Object sender, EventArgs e)
    {
        Application.Exit();
    }

        //Method to move to the last record. Used when adding a row.
        private void MoveToEnd()
        {
			this.BindingContext[dataset.Tables["Contacts"]].Position=
				dataset.Tables["Contacts"].Rows.Count-1;
        }

        //Method to add a new row to the table. Called at initialization
        //and by the "New" button handler.
        private void NewEntry()
        {
            DataRow row = dataset.Tables["Contacts"].NewRow();
            //set up row data with new entries of your choice
            row["First"]="Blank";
            row["Name"]="";
            row["Company"]="";
            row["Title"]="";
            row["Phone"]="";
            dataset.Tables[0].Rows.Add(row);
            dataset.AcceptChanges();
            MoveToEnd();
        }

        //Called at creation to initialize the
        //dataset and create an empty table
        private void InitDataSet()
        {
            dataset = new DataSet("ContactData");

            DataTable t=new DataTable("Contacts");

            t.Columns.Add("First",typeof(System.String));
            t.Columns.Add("Name",typeof(System.String));
            t.Columns.Add("Company",typeof(System.String));
            t.Columns.Add("Title",typeof(System.String));
            t.Columns.Add("Phone",typeof(System.String));

            t.MinimumCapacity=100;

            dataset.Tables.Add(t);
        }

        //Called at initialization to do simple binding of the edit
        //controls on the form to the dataset's "Contacts" table entries
        private void BindControls()
        {
            FirstName.DataBindings.Add("Text",dataset.Tables["Contacts"],"First");
            SurName.DataBindings.Add("Text",dataset.Tables["Contacts"],"Name");
            Title.DataBindings.Add("Text",dataset.Tables["Contacts"],"Title");
            Company.DataBindings.Add("Text",dataset.Tables["Contacts"],"Company");
            Phone.DataBindings.Add("Text",dataset.Tables["Contacts"],"Phone");
        }

        //Constructor. Positions the form controls,
        //Ininitializes the dataset, binds the controls and
        //wires up the handlers. 
        public datasetapp()
        {
			this.components = new System.ComponentModel.Container ();
			this.Text = "datasetapp";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.ClientSize = new System.Drawing.Size (250, 200);
			this.FormBorderStyle = FormBorderStyle.Fixed3D;

            lbl_first = new Label();
            lbl_first.Text="First name";
            lbl_first.Location = new Point(5,5);
            lbl_first.Size = new Size(120,28);
            lbl_first.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(lbl_first);

            FirstName = new TextBox();
            FirstName.Location = new Point(125,5);
            FirstName.Size = new Size(120,28);
            FirstName.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(FirstName);

            lbl_name = new Label();
            lbl_name.Text="Surname";
            lbl_name.Location = new Point(5,35);
            lbl_name.Size = new Size(120,28);
            lbl_name.Anchor = AnchorStyles.Left|AnchorStyles.Right;
            Controls.Add(lbl_name);

            SurName = new TextBox();
            SurName.Location = new Point(125,35);
            SurName.Size = new Size(120,28);
            SurName.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(SurName);

            lbl_company = new Label();
            lbl_company.Text="Company";
            lbl_company.Location = new Point(5,65);
            lbl_company.Size = new Size(120,28);
            Controls.Add(lbl_company);

            Company = new TextBox();
            Company.Location = new Point(125,65);
            Company.Size = new Size(120,28);
            Controls.Add(Company);

            lbl_title = new Label();
            lbl_title.Text="Title";
            lbl_title.Location = new Point(5,95);
            lbl_title.Size = new Size(120,28);
            Controls.Add(lbl_title);

            Title = new TextBox();
            Title.Location = new Point(125,95);
            Title.Size = new Size(120,28);
            Controls.Add(Title);

            lbl_phone = new Label();
            lbl_phone.Text="Telephone";
            lbl_phone.Location = new Point(5,125);
            lbl_phone.Size = new Size(120,28);
            Controls.Add(lbl_phone);

            Phone = new TextBox();
            Phone.Location = new Point(125,125);
            Phone.Size = new Size(120,28);
            Controls.Add(Phone);

            btnNew = new Button();
            btnNew.Location = new Point(5,155);
            btnNew.Size = new Size(70,28);
            btnNew.Text="New";
            btnNew.Click+=new EventHandler(OnNew);
            Controls.Add(btnNew);

            btnPrev = new Button();
            btnPrev.Location = new Point(80,155);
            btnPrev.Size = new Size(35,28);
            btnPrev.Text="<<";
            btnPrev.Click += new EventHandler(OnPrev);
            Controls.Add(btnPrev);

            btnEnd = new Button();
            btnEnd.Location = new Point(120,155);
            btnEnd.Size = new Size(70,28);
            btnEnd.Text="End";
            btnEnd.Click += new EventHandler(OnEnd);
            Controls.Add(btnEnd);

            btnNext = new Button();
            btnNext.Location = new Point(200,155);
            btnNext.Size = new Size(35,28);
            btnNext.Text=">>";
            btnNext.Click += new EventHandler(OnNext);
            Controls.Add(btnNext);

            InitDataSet();

            NewEntry();

            BindControls();

        }

        //Cleans up the Form
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        //Main method to instantiate and run the application.
        static void Main()
        {
            Application.Run(new datasetapp());
        }
    }
}
