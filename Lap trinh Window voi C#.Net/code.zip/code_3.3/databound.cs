namespace Sams
{
    using System;
    using System.Drawing;
    using System.Collections;
	using System.Collections.Specialized;
    using System.ComponentModel;
    using System.Windows.Forms;

    /// <summary>
    ///    Summary description for databound.
    /// </summary>
    public class databound : System.Windows.Forms.Form
    {
		private Button RightButton;
		private Button LeftButton;
		private TextBox textBox2;
		private TextBox textBox1;
		private Button DoneButton;

		private StringCollection sa;

        public databound()
        {
			this.textBox2 = new TextBox();
			this.RightButton = new Button();
			this.textBox1 = new TextBox();
			this.DoneButton = new Button();
			this.LeftButton = new Button();
			this.SuspendLayout();
			// 
			// textBox2
			// 
			this.textBox2.Location = new Point(184, 16);
			this.textBox2.Name = "textBox2";
			this.textBox2.TabIndex = 2;
			this.textBox2.Text = "textBox2";
			// 
			// RightButton
			// 
			this.RightButton.Location = new Point(192, 64);
			this.RightButton.Name = "RightButton";
			this.RightButton.TabIndex = 4;
			this.RightButton.Text = ">>";
			this.RightButton.Click += new EventHandler(this.RightButton_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new Point(8, 16);
			this.textBox1.Name = "textBox1";
			this.textBox1.TabIndex = 1;
			this.textBox1.Text = "textBox1";
			// 
			// DoneButton
			// 
			this.DoneButton.Location = new Point(104, 64);
			this.DoneButton.Name = "DoneButton";
			this.DoneButton.TabIndex = 0;
			this.DoneButton.Text = "Done";
			this.DoneButton.Click += new EventHandler(this.DoneButton_Click);
			// 
			// LeftButton
			// 
			this.LeftButton.Location = new Point(16, 64);
			this.LeftButton.Name = "LeftButton";
			this.LeftButton.TabIndex = 3;
			this.LeftButton.Text = "<<";
			this.LeftButton.Click += new EventHandler(this.LeftButton_Click);
			// 
			// databound
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(294, 111);
			this.ControlBox = false;
			this.Controls.AddRange(new Control[] {
									  this.RightButton,
									  this.LeftButton,
									  this.textBox2,
									  this.textBox1,
									  this.DoneButton});
			this.FormBorderStyle = FormBorderStyle.FixedDialog;
			this.Name = "databound";
			this.ShowInTaskbar = false;
			this.Text = "databound";
			this.ResumeLayout(false);

			//This is the setup code for the simple binding example
			//We have bound two text controls to the same StringCollection

			// This is setting up the "database" (an IList thing)
            sa=new StringCollection();
			sa.Add("Hello databinding");
			sa.Add("Sams publishing");
			sa.Add("C# example");
			sa.Add("By Bob Powell");

			//This binds the controls to that database.
			this.textBox1.DataBindings.Add("Text",sa,"");
			this.textBox2.DataBindings.Add("Text",sa,"");
			//See the button handlers below for details
			//on how to move through the data.
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
        }


		//Very simply increments the Position property of the CurrencyManager
		protected void RightButton_Click (object sender, System.EventArgs e)
		{
			//Note how updating one position affects all 
			//controls bound to this data
			this.BindingContext[sa].Position++;
		}

		//Very simply decrements the Position property of the CurrencyManager
		protected void LeftButton_Click (object sender, System.EventArgs e)
		{
			//Note how updating one position affects all 
			//controls bound to this data
			this.BindingContext[sa].Position--;
		}

		protected void DoneButton_Click (object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		public static void Main()
		{
			Application.Run(new databound());
		}
    }
}
