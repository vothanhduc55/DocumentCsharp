namespace Sams
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.Data;
    using System.ComponentModel;
    using System.Windows.Forms;

    //This application shows simple data binding to a 
    //programatically created dataset.
    public class GridBind : System.Windows.Forms.Form
    {
        private System.ComponentModel.Container components;
        private System.Windows.Forms.DataGrid dataGrid1;

        //The dataset used to store the table
        private DataSet dataset;

        //Called at creation to initialize the
        //dataset and create an empty table
        private void InitDataSet()
        {
            dataset = new DataSet("ContactData");

            DataTable t=new DataTable("Contacts");

            t.Columns.Add("First",typeof(System.String));
            t.Columns.Add("Name",typeof(System.String));
            t.Columns.Add("Company",typeof(System.String));
            t.Columns.Add("Title",typeof(System.String));
            t.Columns.Add("Phone",typeof(System.String));

            t.MinimumCapacity=100;

            dataset.Tables.Add(t);
        }

        //Called at initialization to do complex binding of the DataGrid
        //to the dataset's "Contacts" table entries
        private void BindGrid()
        {
            this.dataGrid1.SetDataBinding(dataset.Tables["Contacts"],"");
        }

        //Constructor. Positions the form controls,
        //Ininitializes the dataset, binds the controls and
        //wires up the handlers. 
        public GridBind()
        {
            InitializeComponent();

            InitDataSet();

            BindGrid();

        }

        //Cleans up the Form
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        //Method added by the form designer
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container ();
            this.dataGrid1 = new System.Windows.Forms.DataGrid ();
            dataGrid1.BeginInit ();
            dataGrid1.Location = new System.Drawing.Point (8, 16);
            dataGrid1.Size = new System.Drawing.Size (472, 224);
            dataGrid1.DataMember = "";
            dataGrid1.TabIndex = 0;
            this.Text = "GridBind";
            this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.ClientSize = new System.Drawing.Size (486, 251);
            this.Controls.Add (this.dataGrid1);
            dataGrid1.EndInit ();
        }



        //Main method to instantiate and run the application.
        static void Main()
        {
            Application.Run(new GridBind());
        }
    }
}
