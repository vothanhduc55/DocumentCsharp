namespace EchoService
{
     using System;
     using System.Collections;
     using System.Configuration;
     using System.ComponentModel;
     using System.Diagnostics;
     using System.Web;
     using System.Web.Services;
 
     /// <summary>
     ///    Summary description for EchoService.
     /// </summary>
     /// 
     public class EchoService : System.Web.Services.WebService
     {
         public EchoService()
         {
             //CODEGEN: This call is required by the ASP+ Web Services Designer
             InitializeComponent();
         }
 
         /// <summary>
         ///    Required method for Designer support - do not modify
         ///    the contents of this method with the code editor.
         /// </summary>
         private void InitializeComponent()
         {
         }
 
         /// <summary>
         ///    Clean up any resources being used.
         /// </summary>
         public override void Dispose()
         {
         }
 
	/// <summary>
	/// Echo Method
	/// </summary>
	[WebMethod]
	public string Echo( string Message ) 
	{
		return Message;
	}
 
         
   }
}

