namespace XML
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.Web;
    using System.Web.Services;

    /// <summary>
    ///    Summary description for Service1.
    /// </summary>
    public class Service1 : System.Web.Services.WebService
    {
        public Service1()
        {
            //CODEGEN: This call is required by the ASP.NET Web Services Designer
            InitializeComponent();
        }

		#region Component Designer generated code
        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        }
		#endregion

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
        }

		[WebMethod]
		public Employee GetEmployee( ) 
		{
			//Create an Employee and return it
			Employee emp = new Employee( );
			Address  add = new Address(  );
			Department dept;

			dept.name = "Development";
			dept.building_number = 20;

			add.Line1	= "123 Anywhere Lane";
			add.City	= "Cary";
			add.State	= "North Carolina";
			add.Zip		= "27513";

			emp.FirstName = "John";
			emp.LastName = "Doe";
			emp.Address = add;
			emp.Department = dept;

			return emp;
		}
    }
}
