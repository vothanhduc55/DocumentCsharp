namespace XML
{
	using System;
	using System.Xml;
	using System.Xml.Serialization;

	
	[XmlRoot("employee")]
	public class Employee 
	{

		private string		m_FirstName;
		private string		m_LastName;
		private Address		m_Address;
		private Department	m_Dept;

		//Properties
		[XmlAttribute("first_name")]
		public string FirstName 
		{
			get{ return m_FirstName; }
			set { m_FirstName = value; }
		}

		[XmlAttribute("last_name")]
		public string LastName 
		{
			get { return m_LastName; }
			set { m_LastName = value; }
		}


		[XmlElement("address")]
		public Address Address 
		{
			get { return m_Address; }
			set { m_Address = value; }
		}

		[XmlElement("department")]
		public Department Department 
		{
			get { return m_Dept; }
			set { m_Dept = value; }
		}
	}

		
	public class Address 
	{

		//Use Public Fields with XmlAttributes
		[XmlAttribute("line1")]
		public string Line1;

		[XmlAttribute("city")]
		public string City;

		[XmlAttribute("state")]
		public string State;

		[XmlAttribute("zip")]
		public string Zip;
	}

	//Use a simple struct
	public struct Department 
	{
		//Fields with no XML attributes
		public string name;
		public int	  building_number;
	}


}
