namespace ProxyFactory
{
    using System;

    
    ///<summary>
    /// Generalize the WebService as an interface to be implemented by each proxy
    ///</summary>
    public interface IEchoService 
    {
        string Echo( string Message );
    }


    ///<summary>
    ///Enumerate the Various Bindings
    ///</summary>
    public enum ProxyProtocol 
    {
		SOAP,
		HttpGet,
		HttpPost
    }


    ///<summary>
    ///The Factory pattern can be used to construct a proxy for the requested binding.
    ///The Factory will then return a well known interface to the web service
    ///</summary>
    public class ProxyFactory
    {
        public static IEchoService ConstructProxy( ProxyProtocol protocol ) 
	{
	
             switch( protocol )
	     {
                 case ProxyProtocol.SOAP:
                     return (IEchoService)new EchoServiceSoapProxy();
                 break;
			
                 case ProxyProtocol.HttpGet:
                     return (IEchoService)new EchoServiceHttpGetProxy();
                 break;
				
                 case ProxyProtocol.HttpPost:
                     return (IEchoService)new EchoServiceHttpPostProxy();
                 break;

                 default:
                     throw new System.Exception( "Invalid Argument" );
                 break;
             }
        }
    }
}
