namespace EchoServiceClient
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.Windows.Forms;
    

	using ProxyFactory;

    /// <summary>
    ///    Summary description for Form1.
    /// </summary>
    public class Form1 : System.Windows.Forms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.Windows.Forms.Label lblResponse;
		private System.Windows.Forms.Button btnInvoke;
		private System.Windows.Forms.TextBox txtMessage;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.RadioButton optSOAP;
		private System.Windows.Forms.RadioButton optHttpGet;
		private System.Windows.Forms.RadioButton optHttpPost;
		private System.Windows.Forms.GroupBox groupBox1;

		private ProxyProtocol	SelectedProtocol=ProxyProtocol.SOAP;
        public Form1()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.groupBox1 = new System.Windows.Forms.GroupBox ();
			this.btnInvoke = new System.Windows.Forms.Button ();
			this.label2 = new System.Windows.Forms.Label ();
			this.label1 = new System.Windows.Forms.Label ();
			this.lblResponse = new System.Windows.Forms.Label ();
			this.optSOAP = new System.Windows.Forms.RadioButton ();
			this.optHttpGet = new System.Windows.Forms.RadioButton ();
			this.txtMessage = new System.Windows.Forms.TextBox ();
			this.optHttpPost = new System.Windows.Forms.RadioButton ();
			//@this.TrayHeight = 0;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			groupBox1.Location = new System.Drawing.Point (0, 8);
			groupBox1.TabIndex = 0;
			groupBox1.TabStop = false;
			groupBox1.Text = "Protocol";
			groupBox1.Size = new System.Drawing.Size (128, 112);
			btnInvoke.Location = new System.Drawing.Point (360, 32);
			btnInvoke.Size = new System.Drawing.Size (75, 23);
			btnInvoke.TabIndex = 4;
			btnInvoke.Text = "Invoke";
			btnInvoke.Click += new System.EventHandler (this.btnInvoke_Click);
			label2.Location = new System.Drawing.Point (136, 72);
			label2.Text = "Response";
			label2.Size = new System.Drawing.Size (64, 23);
			label2.TabIndex = 2;
			label1.Location = new System.Drawing.Point (136, 8);
			label1.Text = "Message";
			label1.Size = new System.Drawing.Size (64, 23);
			label1.TabIndex = 1;
			lblResponse.Location = new System.Drawing.Point (208, 72);
			lblResponse.Size = new System.Drawing.Size (224, 23);
			lblResponse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			lblResponse.TabIndex = 5;
			optSOAP.Location = new System.Drawing.Point (16, 16);
			optSOAP.Text = "SOAP";
			optSOAP.Size = new System.Drawing.Size (100, 23);
			optSOAP.TabIndex = 2;
			optSOAP.Click += new System.EventHandler (this.OnOpt_Click);
			optHttpGet.Location = new System.Drawing.Point (16, 80);
			optHttpGet.Text = "Http Get";
			optHttpGet.Size = new System.Drawing.Size (100, 23);
			optHttpGet.TabIndex = 1;
			optHttpGet.Click += new System.EventHandler (this.OnOpt_Click);
			txtMessage.Location = new System.Drawing.Point (208, 8);
			txtMessage.TabIndex = 3;
			txtMessage.Size = new System.Drawing.Size (224, 20);
			optHttpPost.Location = new System.Drawing.Point (16, 48);
			optHttpPost.Text = "Http Post";
			optHttpPost.Size = new System.Drawing.Size (100, 23);
			optHttpPost.TabIndex = 0;
			optHttpPost.Click += new System.EventHandler (this.OnOpt_Click);
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.ClientSize = new System.Drawing.Size (440, 125);
			groupBox1.Controls.Add (this.optSOAP);
			groupBox1.Controls.Add (this.optHttpGet);
			groupBox1.Controls.Add (this.optHttpPost);
			this.Controls.Add (this.lblResponse);
			this.Controls.Add (this.btnInvoke);
			this.Controls.Add (this.txtMessage);
			this.Controls.Add (this.label2);
			this.Controls.Add (this.label1);
			this.Controls.Add (this.groupBox1);
		}

		protected void btnInvoke_Click (object sender, System.EventArgs e)
		{
			//Get an IEchoService interface
			IEchoService echo = ProxyFactory.ConstructProxy( this.SelectedProtocol );
			this.lblResponse.Text = echo.Echo( this.txtMessage.Text );
			this.txtMessage.Text = "";
		}

		protected void OnOpt_Click( object sender, EventArgs e ) 
		{
			if( sender == optSOAP)
				this.SelectedProtocol = ProxyProtocol.SOAP;
			else if( sender == optHttpPost )
				this.SelectedProtocol = ProxyProtocol.HttpPost;
			else
				this.SelectedProtocol = ProxyProtocol.HttpGet;
		}

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args) 
        {
            Application.Run(new Form1());
        }
    }
}
