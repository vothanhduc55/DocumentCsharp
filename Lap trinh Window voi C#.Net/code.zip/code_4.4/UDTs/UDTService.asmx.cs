namespace UDTWebService
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.Web;
    using System.Web.Services;

    /// <summary>
    ///    Summary description for UDTService.
    /// </summary>
    public class UDTService : System.Web.Services.WebService
    {
		//Create a Hashtable to hold some People
		private System.Collections.Hashtable	htPeople = new Hashtable( );

        public UDTService()
        {
            //CODEGEN: This call is required by the ASP.NET Web Services Designer
            InitializeComponent();

			//Add some people to the hashtable
			htPeople.Add( "Powell", new UDTPerson( "Bob", "Powell" ) );
			htPeople.Add( "Weeks", new UDTPerson( "Richard", "Weeks" ) );
			htPeople.Add( "Martschenko", new UDTPerson( "Bill", "Martschenko" ) );
			htPeople.Add( "Schumacher", new UDTPerson( "Greg", "Schumacher" ) );
			htPeople.Add( "Pitzer", new UDTPerson( "Jay", "Pitzer" ) );

        }

		#region Component Designer generated code
        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        }
		#endregion

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
        }

		[WebMethod]
		public UDTPerson LocatePerson( string LastName ) 
		{
			try 
			{
				UDTPerson p = (UDTPerson)htPeople[ LastName ];
				return p;
			} 
			catch( Exception ) 
			{
				//something went wrong	
			}
			return null;
		}
    }
}
