﻿
using System.Xml.Serialization;
using System;
using System.Web.Services.Protocols;
using System.Web.Services;


[
System.Web.Services.WebServiceBindingAttribute(Name="UDTServiceSoap", 
                                                     Namespace="http://tempuri.org/")
]

public class UDTService : System.Web.Services.Protocols.SoapHttpClientProtocol {
    
    public UDTService() {
        this.Url = "http://localhost/UDTWebService/UDTService.asmx";
    }
    
    [
    System.Web.Services.Protocols.SoapMethodAttribute("http://tempuri.org/LocatePerson", 
                       MessageStyle=System.Web.Services.Protocols.SoapMessageStyle.ParametersInDocument)
    ]
    public UDTPerson LocatePerson(string LastName) {
        object[] results = this.Invoke("LocatePerson", new object[] {LastName});
        return ((UDTPerson)(results[0]));
    }
    
    public System.IAsyncResult BeginLocatePerson(string LastName, System.AsyncCallback callback, object asyncState) {
        return this.BeginInvoke("LocatePerson", new object[] {LastName}, callback, asyncState);
    }
    
    public UDTPerson EndLocatePerson(System.IAsyncResult asyncResult) {
        object[] results = this.EndInvoke(asyncResult);
        return ((UDTPerson)(results[0]));
    }
}


public class UDTPerson {
    
    public string FirstName;
    
    public string LastName;
}
