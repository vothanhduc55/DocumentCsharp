namespace UDTWebService
{
	using System;

	/// <summary>
	///  The Person Class represents a basic UDT( User Defined Type )
	/// </summary>
	public class UDTPerson
	{
		///Private Fields
		private string	m_FirstName;
		private string	m_LastName;

		//Public Properties
		public string FirstName 
		{
			get { return m_FirstName; }
			set { m_FirstName = value; }
		}

		public string LastName 
		{
			get { return m_LastName; }
			set { m_LastName = value; }
		}


		//Constructor(s)
		public UDTPerson( ) 
		{
			//Default Constructor
		}

		public UDTPerson( string FName, string LName ) 
		{
			m_FirstName = FName;
			m_LastName = LName;
		}
	}
}
