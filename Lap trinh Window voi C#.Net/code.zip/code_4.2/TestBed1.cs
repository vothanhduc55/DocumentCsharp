namespace TestBed
{
    using System;
	using System.Data;
	using Stingray.Data;
	using System.Reflection;

	
	
	/// <summary>
    ///    Summary description for Class1.
    /// </summary>
    public class DBTest
    {
      
        public static int Main(string[] args)
        {
            System.Data.ADO.ADOConnection dbCon = new System.Data.ADO.ADOConnection("Provider=SQLOLEDB.1;Persist Security Info=False;User ID=sa;Initial Catalog=Stingray;Data Source=localhost;");
			
			Department[] Departments = new Department[5];
			string[] names = { "Development","Tech Support","Sales","Consulting","Marketing" };

			for(int i = 0; i < 5; i++) {
				Departments[i] = new Department( );
				Departments[i].IsNew = true;
				Departments[i].Id = (i+1);
				Departments[i].Name = names[i];
			}

			dbCon.Open( );

			//Save the Departments
			foreach( Department dept in Departments ) {
				DBAccess.Save( dbCon, dept );
			}
			
			//Do a select and display the results
			System.Data.ADO.ADODataSetCommand dsCmd = new System.Data.ADO.ADODataSetCommand( "SELECT * FROM DEPARTMENT", dbCon );
			System.Data.DataSet dataSet = new System.Data.DataSet(  );
			dsCmd.FillDataSet( dataSet,"DEPARTMENT" );

			//display the records
			foreach( System.Data.DataRow row in dataSet.Tables["DEPARTMENT"].Rows ) {
				Console.WriteLine("{0} : {1}", row[dataSet.Tables["DEPARTMENT"].Columns["DEPT_ID"]],row[dataSet.Tables["DEPARTMENT"].Columns["NAME"]]);
			}

			return 0;
        }
    }
}
