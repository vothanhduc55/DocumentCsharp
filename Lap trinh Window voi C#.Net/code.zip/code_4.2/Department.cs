namespace Stingray.Data
{
    using System;
	using System.Data;
	using System.Data.ADO;

    /// <summary>
    ///  Simple class for a Department
    /// </summary>
    [
		Stingray.Data.DBTableAttribute("DEPARTMENT",
									   InsertCommand="sp_InsertDept",
									   UpdateCommand="sp_UpdateDept")
	]
	public class Department : Stingray.Data.DBEntity {


		/*****[Department Implementation]*****/
		private int		m_Id;
		private string	m_Name;
		
		/// <summary>
		/// Department Id Property
		/// </summary>
		[Stingray.Data.DBFieldAttribute("@DEPT_ID",DataType=System.Data.ADO.ADODBType.Integer)]
		public int Id {
			get { return m_Id; }
			set { 
				if( m_Id != (int)value) {
					m_Id = value;
					IsDirty = true;
				}
			}
		}

		/// <summary>
		/// Department Name property
		/// </summary>
		[Stingray.Data.DBFieldAttribute("@NAME",DataType=System.Data.ADO.ADODBType.VarChar)]
		public string Name {
			get { return m_Name; }
			set { 
				if( m_Name != (string)value) {
					m_Name = value; 
					IsDirty = true;
				}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="data"> </param>
		public override bool FromDataRow( DataRow data ) {
			this.m_Id = (int)data["DEPT_ID"];
			this.m_Name = (string)data["NAME"];
			return true;
		}
		
	}
}
