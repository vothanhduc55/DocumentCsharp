namespace Stingray.Data
{
    using System;
	using System.Reflection;
	using System.Data;
	using System.Data.ADO;

    /// <summary>
    ///    Summary description for DBAccess.
    /// </summary>
    public class DBAccess
    {
		
		/// <summary>
		/// Get an active connection to the stingray database
		/// </summary>
		public static ADOConnection AquireConnection( ) {
			ADOConnection dbCon = new ADOConnection("Provider=SQLOLEDB.1;Persist Security Info=False;User ID=sa;Initial Catalog=Stingray;Data Source=localhost;");
			try {
				dbCon.Open( );
			} catch( Exception ) {
				dbCon.Dispose( );
				dbCon = null;
			}
			return dbCon;
		}
		
       
		/// <summary>
		/// Save a DBEntity into the Stingray Database
		/// </summary>
		/// <param name="ActiveConnection"> Active Database Connection</param>
		/// <param name="entity"> The Entity to be saved</param>
		public static bool Save( ADOConnection ActiveConnection, DBEntity entity ) {

			//Is there anyting to save?
			if( !entity.IsDirty )
				return true;

			object[] Attributes = entity.GetType( ).GetCustomAttributes( typeof(Stingray.Data.DBTableAttribute) );
			
			if(Attributes.Length != 1 )
				return false;

			System.Data.ADO.ADOCommand cmd = new ADOCommand( );
			cmd.ActiveConnection = ActiveConnection;
			cmd.CommandType = System.Data.CommandType.StoredProcedure;
		
			///
			///Do we insert or Update?
			///
			DBTableAttribute TableAttribute = (DBTableAttribute)Attributes[0];
			
			if( entity.IsNew ) {
				cmd.CommandText = TableAttribute.InsertCommand;
			} else {
				cmd.CommandText = TableAttribute.UpdateCommand;
			}

			AddCmdParam( cmd, entity );
			try {
				
				System.Data.ADO.ADODataReader dataReader;
				cmd.Execute( out dataReader );
				return true;

			} catch( Exception ) {
				//Do something for Heavens sake!!
			}

			//Should not make it to here unless it go BOOM!
			return false;
		}

		/// <summary>
		/// Create the ADOParameter(s) for the DBEnity object
		/// </summary>
		/// <param name="cmd"> The ADOCommand object to add the Prameters to</param>
		/// <param name="entity">The DBEnity to scrape </param>
		protected static void AddCmdParam( ADOCommand cmd, DBEntity entity ) {
			///
			///Get the Public properties and create the ADO Parameters
			///
			Type T =entity.GetType( );
			PropertyInfo[] Properties = T.GetProperties( BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public );
			
			foreach( PropertyInfo pi in Properties) {
				object[] Attributes = pi.GetCustomAttributes( typeof(Stingray.Data.DBFieldAttribute) );
				if(Attributes.Length == 1) {
					DBFieldAttribute Field = (DBFieldAttribute)Attributes[0];
					MethodInfo mi = pi.GetGetMethod( false );
					
					object result = mi.Invoke( entity, null );

					//Add the ADOParameter
					cmd.Parameters.Add( new System.Data.ADO.ADOParameter(Field.ParameterName,Field.DataType) );
					cmd.Parameters[Field.ParameterName].Value = result;
					if( Field.Length > 0 ) {
						cmd.Parameters[Field.ParameterName].Size = Field.Length;
					}
				}
			}
			
		}
	}
}