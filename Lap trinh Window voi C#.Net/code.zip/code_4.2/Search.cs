namespace Stingray.Data
{
    using System;
	using System.Data;
	using System.Data.ADO;

    /// <summary>
    ///  Basic search class
    /// </summary>
    public class Search
    {
        
		/// <summary>
		/// Try and locate an employee
		/// </summary>
		/// <param name="ActiveConnection"> </param>
		/// <param name="FirstName"> </param>
		/// <param name="LastName"> </param>
		public static DataSet Find( ADOConnection ActiveConnection,
			                        string FirstName,
			                        string LastName ) {
			string SelectStmt = 
				string.Format("SELECT * FROM EMPLOYEE WHERE FIRST_NAME LIKE '{0}%' and LAST_NAME LIKE '{1}%'",
				               FirstName,LastName);
			return Execute( ActiveConnection, SelectStmt, "EMPLOYEE" );
			
		}
		
		/// <summary>
		/// Try and locate an employee within a department
		/// </summary>
		/// <param name="ActiveConnection"> </param>
		/// <param name="DepartmentId"> </param>
		/// <param name="FirstName"> </param>
		/// <param name="LastName"> </param>
		public static DataSet Find( ADOConnection ActiveConnection,
								    int DepartmentId,
			                        string FirstName,
			                        string LastName ) {

			object[] args = { FirstName, LastName, DepartmentId };
			
			string SelectStmt = 
				string.Format("SELECT * FROM EMPLOYEE WHERE FIRST_NAME LIKE '{0}%' and LAST_NAME LIKE '{1}%' and DEPT_ID = {2}",
				               args);
			return Execute( ActiveConnection, SelectStmt, "EMPLOYEE" );
		}

		/// <summary>
		/// Retrieve a list of employees for a given department
		/// </summary>
		/// <param name="ActiveConnection"> </param>
		/// <param name="DepartmentId"> </param>
		public static DataSet Retrieve( ADOConnection ActiveConnection,
			                            int DepartmentId ) {
			string SelectStmt = string.Format("SELECT * FROM EMPLOYEE WHERE DEPT_ID = {0}", DepartmentId );
			return Execute( ActiveConnection, SelectStmt, "EMPLOYEE" );
		}

		/// <summary>
		/// Nice and tidy.  Do the grunt work in one place
		/// </summary>
		/// <param name="ActiveConnection"> </param>
		/// <param name="Stmt"> </param>
		/// <param name="TableName"> </param>
		private static DataSet Execute( ADOConnection ActiveConnection, 
			                            string SelectStmt, 
			                            string TableName ) {

			ADODataSetCommand cmd = new ADODataSetCommand( SelectStmt, ActiveConnection );
			DataSet dsResult = new DataSet( );
			
			try {
				cmd.FillDataSet( dsResult, TableName );
			} catch( Exception ) {
				//Do some magic here
			}
			return dsResult;
		}
    }
}
