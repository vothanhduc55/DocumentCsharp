namespace Stingray.Data
{
    using System;
	
	//The dependance on ADO should be factored out.  However, I'm working on a dead-line. rlw
	using System.Data;
	using System.Data.ADO;

    /// <summary>
    ///    Summary description for DBAttribute.
    /// </summary>
    /// 
	[attributeusage(AttributeTargets.Class)]
    public class DBTableAttribute : System.Attribute {

		/*****[Fields ]*****/
		
		private string	m_TableName;
		private string	m_SPInsertCommand;
		private string	m_SPUpdateCommand;
		

		/*****[Properties ]*****/

		public string TableName {
			get { return m_TableName; }
			set { m_TableName = value; }
		}
		public string InsertCommand {
			get { return m_SPInsertCommand; }
			set { m_SPInsertCommand = value; }
		}
		public string UpdateCommand {
			get { return m_SPUpdateCommand; }
			set { m_SPUpdateCommand = value; }
		}

		/*****[Constructor(s)]*****/
		public DBTableAttribute( string TableName ) {
			m_TableName = TableName;
		}
	}

	[attributeusage(AttributeTargets.Property)]
	public class DBFieldAttribute : System.Attribute {

		/*****[Fields]*****/

		private string						m_ParamName;
		private System.Data.ADO.ADODBType	m_DataType;
		private int							m_Length = 0;
		

		/*****[Properties]*****/
		public string ParameterName {
			get { return m_ParamName; }
			set { m_ParamName = value; }
		}

		public ADODBType DataType {
			get { return m_DataType; }
			set { m_DataType = value; }
		}

		public int Length {
			get { return m_Length; }
			set { m_Length = value; }
		}
		
		/*****[Constructor(s)]*****/
		public DBFieldAttribute( string ParameterName ) {
			m_ParamName = ParameterName;
		}
	}
}
