///<summary>
///	DBEntity defines a basic database entity and serves as the
///	base class of all entities with a database
///</summary>


namespace Stingray.Data
{
    using System;
	using System.Data;
	using System.Data.ADO;


	/// <summary>
	/// The DBEntity abstract base class
	/// </summary>
	public abstract class DBEntity 	{
		
		private bool m_bIsDirty = false;
		private bool m_bIsNew = true;

		public virtual bool IsDirty { 
			get { return m_bIsDirty; }
			set { m_bIsDirty = value;}
		}

		public virtual bool IsNew {
			get { return m_bIsNew; }
			set { m_bIsNew = value; }
		}

		public abstract bool FromDataRow( System.Data.DataRow data );
	}
    
}
