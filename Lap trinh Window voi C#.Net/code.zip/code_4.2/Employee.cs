namespace Stingray.Data
{
    using System;
	using System.Data;
	using System.Data.ADO;

    /// <summary>
    ///	The Employee Class
    /// </summary>
    /// 
	[
		Stingray.Data.DBTableAttribute("EMPLOYEE",
								       InsertCommand="sp_InsertEmployee",
									   UpdateCommand="sp_UpdateEmployee")
	]
    public class Employee : DBEntity
    {
		/*****[Data Members]*****/
		private string	m_EmpId;		//SSN
		private int		m_DeptId;
		private string	m_FirstName;
		private string	m_LastName;
		private Guid	m_PicId;
       
		/*****[Properties]*****/
		[
			Stingray.Data.DBFieldAttribute("@EMP_ID",DataType=ADODBType.Char,Length=9)
		]
		public string Id {
			get { return m_EmpId; }
			set { 
				if(m_EmpId != (string)value) {
					m_EmpId = (string)value;
					IsDirty = true;
				}
			}
		}

		[
			Stingray.Data.DBFieldAttribute("@DEPT_ID",DataType=ADODBType.Integer)
		]
		public int DeptId {
			get { return m_DeptId; }
			set { 
				if( m_DeptId != (int)value ) {
					m_DeptId = (int)value;
					IsDirty = true;
				}
			}
		}

		[
			Stingray.Data.DBFieldAttribute("@FIRST_NAME",DataType=ADODBType.VarChar)
		]
		public string FirstName {
			get { return m_FirstName; }
			set { 
				if(m_FirstName != (string)value) {
					m_FirstName = (string)value;
					IsDirty = true;
				}
			}
		}


		[
			Stingray.Data.DBFieldAttribute("@LAST_NAME",DataType=ADODBType.VarChar)
		]
		public string LastName {
			get { return m_LastName; }
			set { 
				if( m_LastName != (string)value) {
					m_LastName = (string)value;
					IsDirty = true;
				}
			}
		}

		[
			Stingray.Data.DBFieldAttribute("@PIC_ID",DataType=ADODBType.Guid)
		]
		public Guid PictureId {
			get { return m_PicId; }
			set {
				if( m_PicId != (Guid)value) {
					m_PicId = new Guid( ((Guid)value).ToString( ) );
					IsDirty = true;
				}
			}
		}

		/// <summary>
		/// Create from a row of data
		/// </summary>
		/// <param name="data"> </param>
		public override bool FromDataRow( DataRow data ) {
			this.Id = (string)data["EMP_ID"];
			this.DeptId = (int)data["DEPT_ID"];
			this.FirstName = (string)data["FIRST_NAME"];
			this.LastName = (string)data["LAST_NAME"];
			if( data["PIC_ID"].ToString() != "")
				this.m_PicId = new Guid( data["PIC_ID"].ToString( ) );
			
			this.IsNew = false;
			return true;
		}


		/*****[Constructor(s)]*****/
		public Employee() {
			//What to do??
			IsNew = true;
			IsDirty = false;
        }

    }
}
