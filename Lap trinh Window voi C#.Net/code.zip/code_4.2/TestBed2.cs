namespace TestBed
{
    using System;

	using System.Data;
	using System.Data.ADO;

	using Stingray.Data;

    /// <summary>
    ///    Summary description for TestBed2.
    /// </summary>
    public class TestBed2
    {
       public static void Main( )
        {
            System.Data.ADO.ADOConnection dbCon = new System.Data.ADO.ADOConnection("Provider=SQLOLEDB.1;Persist Security Info=False;User ID=sa;Initial Catalog=Stingray;Data Source=localhost;");
			dbCon.Open( );
			//Find me
			DataSet dsResult = Search.Find( dbCon, "Richard", "Weeks" );
			if( dsResult != null && dsResult.Tables["EMPLOYEE"] != null) {
				foreach( DataColumn c in dsResult.Tables["EMPLOYEE"].Columns) {
					Console.WriteLine( dsResult.Tables["EMPLOYEE"].Rows[0][c]);
				}
			}

			//Get Development
			dsResult = Search.Retrieve( dbCon, 1 );
		    if( dsResult != null) {
				foreach( DataRow row in dsResult.Tables["EMPLOYEE"].Rows) {
					Console.WriteLine("**********************************");
					foreach( DataColumn col in dsResult.Tables["EMPLOYEE"].Columns ) {
						Console.WriteLine( row[col] );
					}
				}
			}
        }

		
    }
}
