// SourceObject.h : Declaration of the CSourceObject

#pragma once
#include "resource.h"       // main symbols


// ISourceObject
[
	object,
	uuid("552BCB0E-0FE2-4089-90AE-CB2ED66A134A"),
	dual,	helpstring("ISourceObject Interface"),
	pointer_default(unique)
]
__interface ISourceObject : IDispatch
{

	[id(1), helpstring("method MakeEventFire")] HRESULT MakeEventFire([in] BSTR Message);
};


// _ISourceObjectEvents
[
	dispinterface,
	uuid("F0507830-BD45-479D-849F-35E422A5C7FA"),
	hidden,
	helpstring("_ISourceObjectEvents Interface")
]
__interface _ISourceObjectEvents
{

	[id(1), helpstring("method OnSomeEvent")] void OnSomeEvent([in] BSTR Message);
};


// CSourceObject

[
	coclass,
	threading("apartment"),
	event_source("com"),
	aggregatable("never"),
	vi_progid("ATLSource.SourceObject"),
	progid("ATLSource.SourceObject.1"),
	version(1.0),
	uuid("3CBDA477-0939-4D29-8C6B-063F158E5ECB"),
	helpstring("SourceObject Class")
]
class ATL_NO_VTABLE CSourceObject : 
	public ISourceObject
{
public:
	CSourceObject()
	{
	}

	__event __interface _ISourceObjectEvents;

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease() 
	{
	}

public:

	STDMETHOD(MakeEventFire)(BSTR Message);
};

