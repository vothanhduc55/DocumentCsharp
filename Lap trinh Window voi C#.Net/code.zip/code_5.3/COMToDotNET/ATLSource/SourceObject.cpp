// SourceObject.cpp : Implementation of CSourceObject

#include "stdafx.h"
#include "SourceObject.h"


// CSourceObject


STDMETHODIMP CSourceObject::MakeEventFire(BSTR Message)
{
	// TODO: Add your implementation code here
	this->OnSomeEvent( Message );
	return S_OK;
}
