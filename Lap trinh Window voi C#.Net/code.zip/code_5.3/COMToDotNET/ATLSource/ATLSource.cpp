// ATLSource.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{6643A3D1-ED6B-4FFE-806D-0A3D09F352E1}", 
		 name = "ATLSource", 
		 helpstring = "ATLSource 1.0 Type Library",
		 resource_name = "IDR_ATLSOURCE") ];
