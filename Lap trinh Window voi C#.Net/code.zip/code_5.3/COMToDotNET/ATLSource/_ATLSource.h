
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0342 */
/* at Fri Mar 09 19:30:41 2001
 */
/* Compiler settings for _ATLSource.idl:
    Os, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef ___ATLSource_h__
#define ___ATLSource_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ISourceObject_FWD_DEFINED__
#define __ISourceObject_FWD_DEFINED__
typedef interface ISourceObject ISourceObject;
#endif 	/* __ISourceObject_FWD_DEFINED__ */


#ifndef ___ISourceObjectEvents_FWD_DEFINED__
#define ___ISourceObjectEvents_FWD_DEFINED__
typedef interface _ISourceObjectEvents _ISourceObjectEvents;
#endif 	/* ___ISourceObjectEvents_FWD_DEFINED__ */


#ifndef __CSourceObject_FWD_DEFINED__
#define __CSourceObject_FWD_DEFINED__

#ifdef __cplusplus
typedef class CSourceObject CSourceObject;
#else
typedef struct CSourceObject CSourceObject;
#endif /* __cplusplus */

#endif 	/* __CSourceObject_FWD_DEFINED__ */


/* header files for imported files */
#include "mshtml.h"
#include "mshtmhst.h"
#include "objsafe.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __ISourceObject_INTERFACE_DEFINED__
#define __ISourceObject_INTERFACE_DEFINED__

/* interface ISourceObject */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISourceObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("552BCB0E-0FE2-4089-90AE-CB2ED66A134A")
    ISourceObject : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MakeEventFire( 
            /* [in] */ BSTR Message) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISourceObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISourceObject * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISourceObject * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISourceObject * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISourceObject * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISourceObject * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISourceObject * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISourceObject * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *MakeEventFire )( 
            ISourceObject * This,
            /* [in] */ BSTR Message);
        
        END_INTERFACE
    } ISourceObjectVtbl;

    interface ISourceObject
    {
        CONST_VTBL struct ISourceObjectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISourceObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISourceObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISourceObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISourceObject_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISourceObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISourceObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISourceObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISourceObject_MakeEventFire(This,Message)	\
    (This)->lpVtbl -> MakeEventFire(This,Message)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISourceObject_MakeEventFire_Proxy( 
    ISourceObject * This,
    /* [in] */ BSTR Message);


void __RPC_STUB ISourceObject_MakeEventFire_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISourceObject_INTERFACE_DEFINED__ */



#ifndef __ATLSource_LIBRARY_DEFINED__
#define __ATLSource_LIBRARY_DEFINED__

/* library ATLSource */
/* [helpstring][uuid][version] */ 


EXTERN_C const IID LIBID_ATLSource;

#ifndef ___ISourceObjectEvents_DISPINTERFACE_DEFINED__
#define ___ISourceObjectEvents_DISPINTERFACE_DEFINED__

/* dispinterface _ISourceObjectEvents */
/* [helpstring][hidden][uuid] */ 


EXTERN_C const IID DIID__ISourceObjectEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("F0507830-BD45-479D-849F-35E422A5C7FA")
    _ISourceObjectEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _ISourceObjectEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _ISourceObjectEvents * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _ISourceObjectEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _ISourceObjectEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _ISourceObjectEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _ISourceObjectEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _ISourceObjectEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _ISourceObjectEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _ISourceObjectEventsVtbl;

    interface _ISourceObjectEvents
    {
        CONST_VTBL struct _ISourceObjectEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _ISourceObjectEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _ISourceObjectEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _ISourceObjectEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _ISourceObjectEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _ISourceObjectEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _ISourceObjectEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _ISourceObjectEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___ISourceObjectEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_CSourceObject;

#ifdef __cplusplus

class DECLSPEC_UUID("3CBDA477-0939-4D29-8C6B-063F158E5ECB")
CSourceObject;
#endif
#endif /* __ATLSource_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


