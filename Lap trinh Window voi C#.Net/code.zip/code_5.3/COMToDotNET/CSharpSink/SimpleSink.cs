namespace CSharpSink
{
	using System;
	using ATLSourceImp;

	/// <summary>
	///		Summary description for Class1.
	/// </summary>
	class SimpleSink
	{
		static void Main(string[] args)
		{
		
			ATLSourceImp.CSourceObject source = new ATLSourceImp.CSourceObject( );
			source.OnSomeEvent += new _ISourceObjectEvents_OnSomeEventEventHandler(OnSomeEvent);

			source.MakeEventFire( "Hello" );
		}

		public static void OnSomeEvent( string Message ) 
		{
			Console.WriteLine("Have Event: {0}", Message );
		}
	}
}
