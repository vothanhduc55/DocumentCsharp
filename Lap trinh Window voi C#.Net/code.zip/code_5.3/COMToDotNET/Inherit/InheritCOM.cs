namespace Inherit
{
	using System;
	
	/// <summary>
	/// Use the CSimpleObject coclass as the base class
	/// </summary>
	public class SimpleInherit : SimpleATLImp.CSimpleObject 
	{

		/// <summary>
		/// Extend the functionality of CSimpleObject
		/// </summary>
		public void NewMethod( ) 
		{
			Console.WriteLine("Cool, derived from COM coclass");
		}
	}
	

	class COMdotNETStyle
	{
		static void Main(string[] args)
		{
			//Create new derived class.
			SimpleInherit simpleInherit = new SimpleInherit( );

			//Invoke COM SayHelloMethod
			string s = simpleInherit.SayHello("Me");
			Console.WriteLine(s);

			//Invoke derived class method
			simpleInherit.NewMethod( );
		}
	}
}
