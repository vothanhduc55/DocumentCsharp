namespace EarlyBinding
{
	using System;

	/// <summary>
	///		Summary description for Class1.
	/// </summary>
	class Early
	{
		static void Main(string[] args)
		{
			SimpleATLImp.CSimpleObject o = new SimpleATLImp.CSimpleObject( );
			Console.WriteLine(o.SayHello( "Richard" ));
		}
	}
}
