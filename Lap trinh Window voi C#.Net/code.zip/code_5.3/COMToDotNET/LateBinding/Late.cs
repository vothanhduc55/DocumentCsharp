namespace LateBinding
{
	using System;
	using System.Reflection;
	using System.Runtime.InteropServices;

	class Late
	{
		static void Main(string[] args)
		{
			try 
			{
				Type SimpleObjectType = Type.GetTypeFromProgID("SimpleATL.SimpleObject");
				object SimpleObjectInstance = Activator.CreateInstance( SimpleObjectType );

				Console.WriteLine("SimpleObjectType = {0}", SimpleObjectType.ToString( ) );
				Console.WriteLine("SimpleObjectInstance Type = {0}",SimpleObjectInstance.GetType( ).ToString( ) );

				//Invoke the SayHello Instance Method
				string Message = (string)SimpleObjectType.InvokeMember("SayHello",
					BindingFlags.Default | BindingFlags.InvokeMethod, 
					null, 
					SimpleObjectInstance, 
					new object[] { "Richard" } );
				//Did it work?
				Console.WriteLine(Message);
			} 
			catch( COMException e ) 
			{
				Console.WriteLine("What up? {0} : {1}", e.ErrorCode, e.Message );
			}
		}
	}
}
