// SimpleObject.h : Declaration of the CSimpleObject

#pragma once
#include "resource.h"       // main symbols


// ISimpleObject
[
	object,
	uuid("6D854C55-4549-44FB-9CDF-6079F56B232E"),
	dual,	helpstring("ISimpleObject Interface"),
	pointer_default(unique)
]
__interface ISimpleObject : IDispatch
{


	[id(1), helpstring("method SayHello")] HRESULT SayHello([in] BSTR Name, [out,retval] BSTR* Message);
};



// CSimpleObject

[
	coclass,
	threading("apartment"),
	aggregatable("never"),
	vi_progid("SimpleATL.SimpleObject"),
	progid("SimpleATL.SimpleObject.1"),
	version(1.0),
	uuid("D82A38B8-5392-4D3D-ADEC-516C18E6A092"),
	helpstring("SimpleObject Class")
]
class ATL_NO_VTABLE CSimpleObject : 
	public ISimpleObject
{
public:
	CSimpleObject()
	{
	}


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	
	STDMETHOD(SayHello)(BSTR Name, BSTR* Message);
};

