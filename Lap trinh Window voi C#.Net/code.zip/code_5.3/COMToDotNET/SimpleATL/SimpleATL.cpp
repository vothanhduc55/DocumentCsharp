// SimpleATL.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{50DE5022-2D86-4586-B25F-5B44C08A8266}", 
		 name = "SimpleATL", 
		 helpstring = "SimpleATL 1.0 Type Library",
		 resource_name = "IDR_SIMPLEATL") ];
