// SimpleObject.cpp : Implementation of CSimpleObject

#include "stdafx.h"
#include "SimpleObject.h"


// CSimpleObject




STDMETHODIMP CSimpleObject::SayHello(BSTR Name, BSTR* Message)
{
	// TODO: Add your implementation code here
	CComBSTR Msg( "Hello " ); Msg += Name;
	*Message = ::SysAllocString( Msg.m_str );
	
	return S_OK;
}
